"""
============================================================================
STEP 02: EXPLORE DATA — Understand the Accessory Forecast Dataset
============================================================================

WHAT THIS DOES:
  1. Connects to SAP HANA Cloud HDI container and reads ACCESSORY_FORECAST
  2. Shows data dimensions: date range, classes, models, locations
  3. Analyzes ACCCODE distribution (which accessories are most common)
  4. Shows monthly volume patterns per ACCCODE
  5. Identifies which ACCCODEs have enough data for time series forecasting

HDI CONTEXT:
  The ACCESSORY_FORECAST table is created by the HDI deployer from the
  db/src/ACCESSORY_FORECAST.hdbtable artifact and optionally auto-loaded
  via db/src/data/ACCESSORY_FORECAST.hdbtabledata.
  This script connects using the HDI container runtime user credentials.

WHY:
  Before forecasting, we need to understand which ACCCODEs have sufficient
  history (at least 12 monthly data points) and meaningful volumes.

RUN:
  python 02_explore_data.py

PREREQUISITES:
  pip install hana-ml pandas python-dotenv
============================================================================
"""

import os
from dotenv import load_dotenv
load_dotenv()
import pandas as pd
from hana_ml.dataframe import ConnectionContext

# ─── Connect to HANA Cloud ───
print("Connecting to HANA Cloud...")
conn = ConnectionContext(
    address=os.environ['HANA_HOST'],
    port=int(os.environ['HANA_PORT']),
    user=os.environ['HANA_USER'],
    password=os.environ['HANA_PASSWORD'],
    encrypt=True
)
# Set schema to HDI container schema (RT user's default schema differs)
if os.environ.get('HANA_SCHEMA'):
    conn.connection.cursor().execute(f"SET SCHEMA {os.environ['HANA_SCHEMA']}")
print(f"Connected. HANA version: {conn.hana_version()}")
print(f"Schema: {os.environ.get('HANA_SCHEMA', 'default')}\n")

# ─── Load data ───
df = conn.table('ACCESSORY_FORECAST').collect()
print(f"Total rows: {len(df):,}")
print(f"Columns: {list(df.columns)}\n")

# ═══════════════════════════════════════════════════════════════════
# 1. DATE RANGE
# ═══════════════════════════════════════════════════════════════════
print("═" * 65)
print("  1. DATA DATE RANGE")
print("═" * 65)
df['PERIOD'] = df['PRODYEAR'].astype(str) + '-' + df['PRODMONTH'].str.zfill(2)
print(f"  Earliest: {df['PERIOD'].min()}")
print(f"  Latest:   {df['PERIOD'].max()}")
print(f"  Distinct months: {df['PERIOD'].nunique()}")

# ═══════════════════════════════════════════════════════════════════
# 2. VEHICLE CLASSES AND MODELS
# ═══════════════════════════════════════════════════════════════════
print(f"\n{'═' * 65}")
print("  2. VEHICLE CLASSES")
print("═" * 65)
class_summary = (
    df.groupby('CLASS')
    .agg(ROWS=('VEHICLECOUNT', 'count'),
         MODELS=('MODEL', 'nunique'),
         TOTAL_VEHICLES=('VEHICLECOUNT', 'sum'))
    .sort_values('TOTAL_VEHICLES', ascending=False)
)
print(class_summary.to_string())

# ═══════════════════════════════════════════════════════════════════
# 3. ACCESSORY CODE (ACCCODE) ANALYSIS — THIS IS OUR FORECAST TARGET
# ═══════════════════════════════════════════════════════════════════
print(f"\n{'═' * 65}")
print("  3. ACCESSORY CODES (ACCCODE) — Forecast Target")
print("═" * 65)

acc_summary = (
    df.groupby('ACCCODE')
    .agg(
        ROWS=('VEHICLECOUNT', 'count'),
        TOTAL_VEHICLES=('VEHICLECOUNT', 'sum'),
        AVG_MONTHLY=('VEHICLECOUNT', 'mean'),
        MONTHS_PRESENT=('PERIOD', 'nunique')
    )
    .sort_values('TOTAL_VEHICLES', ascending=False)
)
print(f"\n  Total distinct ACCCODEs: {len(acc_summary)}")
print(f"\n  Top 20 ACCCODEs by volume:")
print(acc_summary.head(20).to_string())

# Mark which ACCCODEs are forecastable (12+ months of data)
acc_summary['FORECASTABLE'] = acc_summary['MONTHS_PRESENT'] >= 12
forecastable = acc_summary[acc_summary['FORECASTABLE']]
print(f"\n  ACCCODEs with 12+ months of data (suitable for forecasting): {len(forecastable)}")
print(f"  ACCCODEs with < 12 months (too few for seasonal models): {len(acc_summary) - len(forecastable)}")

# ═══════════════════════════════════════════════════════════════════
# 4. MONTHLY VOLUME PER ACCCODE (Time Series Preview)
# ═══════════════════════════════════════════════════════════════════
print(f"\n{'═' * 65}")
print("  4. MONTHLY VOLUME PER ACCCODE (Top 10)")
print("═" * 65)

# Aggregate: total vehicles per ACCCODE per month
monthly_acc = (
    df.groupby(['ACCCODE', 'PRODYEAR', 'PRODMONTH'])
    ['VEHICLECOUNT'].sum()
    .reset_index()
)
monthly_acc['PERIOD'] = (
    monthly_acc['PRODYEAR'].astype(str) + '-' +
    monthly_acc['PRODMONTH'].str.zfill(2)
)

# Show top 10 ACCCODEs
top10 = acc_summary.head(10).index.tolist()
for acccode in top10:
    acc_data = monthly_acc[monthly_acc['ACCCODE'] == acccode].sort_values('PERIOD')
    print(f"\n  ACCCODE: {acccode}  (Total: {acc_summary.loc[acccode, 'TOTAL_VEHICLES']:,})")
    print(f"  {'Period':<10} {'Count':>8}")
    print(f"  {'─' * 20}")
    for _, row in acc_data.iterrows():
        bar = '█' * max(1, int(row['VEHICLECOUNT'] / acc_data['VEHICLECOUNT'].max() * 30))
        print(f"  {row['PERIOD']:<10} {row['VEHICLECOUNT']:>8,}  {bar}")

# ═══════════════════════════════════════════════════════════════════
# 5. SUMMARY — READY FOR FORECASTING
# ═══════════════════════════════════════════════════════════════════
print(f"\n{'═' * 65}")
print("  5. FORECASTING READINESS SUMMARY")
print("═" * 65)
print(f"""
  Dataset:        {len(df):,} rows
  Date range:     {df['PERIOD'].min()} to {df['PERIOD'].max()}
  Vehicle classes: {df['CLASS'].nunique()}
  Models:         {df['MODEL'].nunique()}
  ACCCODEs:       {df['ACCCODE'].nunique()}

  Forecastable ACCCODEs (12+ months): {len(forecastable)}
  Top ACCCODEs by volume:
""")
for acccode in forecastable.head(15).index:
    row = acc_summary.loc[acccode]
    print(f"    {acccode}:  {row['TOTAL_VEHICLES']:>10,} vehicles  ({int(row['MONTHS_PRESENT'])} months)")

print(f"""
  NEXT STEP:
    Run 03_prepare_timeseries.py to create per-ACCCODE monthly
    time series data suitable for PAL forecasting algorithms.
""")

conn.close()
