# Mercedes-Benz Accessory Demand Forecasting — Functional Demo Guide

> **Document Type:** Functional / Business Overview  
> **Audience:** Business stakeholders, demo presenters, functional team members  
> **Last Updated:** March 19, 2026

---

## What Does This Application Do?

This application **predicts how many of each vehicle accessory Mercedes-Benz USA will need over the next 12 months**.

```
┌───────────────────────────────────────────────────────────────────────────┐
│                                                                           │
│     Question we answer:                                                   │
│                                                                           │
│     "How many units of accessory D07 will be needed in August 2026?"      │
│                                                                           │
│     Answer:   ~1,423 units  (predicted by our best-performing model)      │
│                                                                           │
└───────────────────────────────────────────────────────────────────────────┘
```

Instead of relying on guesswork or simple averages, the system uses **three different AI forecasting models** and automatically picks the most accurate one for each accessory.

---

## The Business Problem

Mercedes-Benz USA installs accessories (navigation packages, wheel upgrades, roof racks, towing packages, etc.) at Vehicle Processing Centers. Planning the right inventory means:

- **Too much stock** → wasted warehouse space, tied-up capital
- **Too little stock** → delayed vehicle deliveries, customer dissatisfaction
- **Right amount** → efficient operations, happy customers ✅

This application gives supply-chain planners a **data-driven, 12-month forecast** to plan smart.

---

## What Data Goes In?

We start with **33,674 production records** from Mercedes-Benz USA:

| What | Example | Why It Matters |
|------|---------|---------------|
| Accessory Code | D07, D49, D52 | Which accessory |
| Vehicle Model | C300W, GLC300X4 | Which car it goes on |
| VPC Location | 12, 22, 32, 52 | Which processing center |
| Production Month | January 2024 | When it was installed |
| Vehicle Count | 1,557 | How many vehicles got this accessory |

**Data range:** January 2024 through May 2026 (~29 months of history)

---

## How Does the AI Work? (Simple Explanation)

The system runs **three different forecasting methods** for every accessory and automatically picks the winner:

```
┌────────────────────────────────────────────────────────────────────────┐
│                                                                        │
│                      THREE COMPETING MODELS                            │
│                                                                        │
│   ┌──────────────────┐  ┌──────────────────┐  ┌──────────────────┐    │
│   │   Model 1: SES   │  │  Model 2: SARIMA │  │  Model 3: BSTS  │    │
│   │   (Simple)       │  │  (Seasonal)      │  │  (Bayesian AI)  │    │
│   │                  │  │                  │  │                  │    │
│   │   Like using a   │  │   Like knowing   │  │   Like a smart  │    │
│   │   weighted       │  │   "December is   │  │   analyst who   │    │
│   │   average of     │  │   always high    │  │   separates     │    │
│   │   recent months  │  │   and July is    │  │   the trend,    │    │
│   │                  │  │   always low"    │  │   the seasonal  │    │
│   │                  │  │                  │  │   pattern, and  │    │
│   │                  │  │                  │  │   the noise     │    │
│   └──────────────────┘  └──────────────────┘  └──────────────────┘    │
│             │                     │                     │              │
│             └─────────────────────┴─────────────────────┘              │
│                                   │                                    │
│                                   ▼                                    │
│                    ┌──────────────────────────────┐                    │
│                    │   AUTOMATIC COMPARISON        │                    │
│                    │   Test all 3 against the last │                    │
│                    │   5 months of known data      │                    │
│                    │   → Pick the most accurate    │                    │
│                    └──────────────────────────────┘                    │
│                                   │                                    │
│                                   ▼                                    │
│                    ┌──────────────────────────────┐                    │
│                    │   WINNER produces the         │                    │
│                    │   12-month forecast            │                    │
│                    └──────────────────────────────┘                    │
│                                                                        │
└────────────────────────────────────────────────────────────────────────┘
```

### The Three Models in Plain Language

| Model | Think of It As... | Best When... |
|-------|--------------------|-------------|
| **SES** (Simple Exponential Smoothing) | A running average that pays more attention to recent months | Demand is fairly steady without strong seasonal patterns |
| **SARIMA** (Seasonal ARIMA) | A pattern matcher that learns "every December goes up, every summer dips" | There's a clear repeating yearly cycle |
| **BSTS** (Bayesian Structural Time Series) | An intelligent analyst who separates the overall trend from the seasonal swings from random noise | Demand has both a changing trend AND seasonal patterns |

### How the Winner Is Chosen

We hold back the last **5 months of known data** and use the rest for training. Then each model tries to predict those 5 months. The model whose predictions are closest to reality wins.

```
  Training (24 months)        Test (5 months)      Future (12 months)
  ┌──────────────────────┐  ┌─────────────┐      ┌─────────────────────┐
  │ Jan 2024 – Dec 2025  │  │ Jan–May 2026│      │ Jun 2026 – May 2027 │
  │ "Learn from this"    │  │ "Score here"│      │ "Predict this"      │
  └──────────────────────┘  └─────────────┘      └─────────────────────┘
```

---

## How We Built and Improved This — Our Journey

### Iteration 1: Starting Simple

We began with two basic models:
- **SES** (Simple Exponential Smoothing) — the simplest possible forecast
- **Holt-Winters** — adds seasonal awareness

These gave us a working baseline, but accuracy was limited.

### Iteration 2: Adding Sophistication

We added:
- **SARIMA** — a more powerful seasonal model
- **Outlier detection** — automatically finds and fixes abnormal data spikes (production shutdowns, one-time events)
- **Data quality checks** — detects months where data may be incomplete

This improved accuracy significantly, especially for seasonal accessories.

### Iteration 3: Trying SAP's AutoML (Automatic Machine Learning)

We asked SAP HANA's built-in AutoML to automatically find the best algorithm:

```
┌──────────────────────────────────────────────────────────────────────┐
│                      AutoML INVESTIGATION                            │
│                                                                      │
│   We asked SAP HANA: "Which AI model works best for our data?"       │
│                                                                      │
│   AutoML ran its analysis and returned:                              │
│                                                                      │
│        ╔══════════════════════════════════════════════════════╗       │
│        ║  RECOMMENDATION: BSTS (Bayesian Structural          ║       │
│        ║  Time Series) is the best model for this data       ║       │
│        ╚══════════════════════════════════════════════════════╝       │
│                                                                      │
│   However, AutoML's prediction function had a technical bug          │
│   that prevented us from using it as a turnkey solution.             │
│                                                                      │
│   So we implemented BSTS directly — using AutoML's                   │
│   recommendation as our guide.                                       │
│                                                                      │
│   This way we got the BEST MODEL that AutoML identified,             │
│   without being limited by AutoML's prediction bug.                  │
└──────────────────────────────────────────────────────────────────────┘
```

We ran **9 separate experiments** with AutoML and **4 experiments** implementing BSTS directly before arriving at the final working solution. This thorough testing process ensures we're using the best possible approach.

### Iteration 4: Final Production System

Our final system combines:
- **SES** as a reliable baseline
- **SARIMA** for seasonal patterns
- **BSTS** (recommended by AutoML) for capturing complex trend + seasonal patterns
- Extended forecast from **6 months to 12 months** per business requirements
- Added **composite key forecasting** (by accessory + location + vehicle model)
- All running inside **SAP HANA Cloud** — no data leaves the database

---

## What the Dashboard Shows

### Predictions Page (Landing Page)

The main page lets you search for any accessory code and see predictions at a glance.

- **Search bar** — Type an accessory code (e.g., "D07") to filter
- **Results cards** — For each accessory: code, best model name, predicted total for the next 12 months

### Detail Page (Per Accessory)

Clicking any accessory card opens:

1. **📈 Line Chart**
   - Blue line = actual historical data
   - Orange line = model's prediction
   - Clearly shows where actuals end and predictions begin

2. **📊 12-Month Predictions Table**
   - Each future month with the predicted quantity
   - Uses the best-performing model automatically

3. **🔍 Model Explanation Section**
   - Which model won and why
   - How the three models compared (RMSE error metric)
   - Training, testing, and prediction period breakdown

4. **📋 Detailed Data (expandable)**
   - All three models' numbers side-by-side
   - Training data, test data, and future predictions in separate tabs
   - The best model's column highlighted in green

### Composite Predictions Page

Same features but at finer granularity — filtered by accessory + processing center + vehicle model. This answers questions like:

> "How many D07 do we need at VPC location 12 specifically for the C300W?"

---

## Key Numbers

| Metric | Value |
|--------|-------|
| Total accessory codes forecasted | **40** |
| Composite key combinations forecasted | **594** |
| Forecast horizon | **12 months** (Jun 2026 – May 2027) |
| AI models compared per accessory | **3** |
| Historical data used | **29 months** (Jan 2024 – May 2026) |

### Which Model Wins Most Often?

```
  BSTS (Bayesian)   ████████████████████  19 out of 40 accessories  (47.5%)
  SARIMA (Seasonal)  █████████████  13 out of 40 accessories  (32.5%)
  SES (Simple)       ████████  8 out of 40 accessories  (20.0%)
```

**BSTS wins nearly half the time** — confirming AutoML's recommendation that it's the best overall approach for this data. But having all three models ensures we always pick the best one for each individual accessory.

---

## Technology Used

| Component | What It Does |
|-----------|-------------|
| **SAP HANA Cloud** | Stores all data and runs the AI models directly inside the database |
| **SAP PAL** (Predictive Analysis Library) | The AI engine — SES, SARIMA, and BSTS models all run inside HANA |
| **SAP BTP** (Business Technology Platform) | Hosts the web application in the cloud |
| **Flask** (Python) | Web framework powering the dashboard |
| **Chart.js** | Creates the interactive charts |

**Key advantage:** All machine learning runs **inside SAP HANA Cloud**. The data never leaves the database — Python just sends instructions and reads results. This is fast, secure, and enterprise-grade.

---

## How to Use the Application

### For Demo Presenters

1. **Open the URL** in any web browser:  
   `https://daimler-ag---cpea-tst-mbusa-voisv-swt-devspace-sapai-pl-app.cfapps.us10.hana.ondemand.com`

2. **Show the Predictions page** — Explain that every accessory code has been forecasted
3. **Click on any accessory** — Show the chart, predictions table, and model explanation
4. **Expand "Detailed Data"** — Show how all three models competed
5. **Navigate to Composite Predictions** — Show granular breakdowns by VPC and model
6. **Key talking points:**
   - We tested AutoML and it recommended BSTS — confirming our approach
   - Three models compete; the most accurate one is automatically selected
   - 12-month forecast gives full-year visibility for planning
   - All AI runs inside SAP HANA — enterprise security, no data exposure

### For Planners

- Use the ACCCODE predictions for high-level accessory demand planning
- Use the Composite predictions for location-specific and vehicle-specific planning
- The "best model" is automatically chosen — no manual tuning needed
- Forecasts should be refreshed when new production data becomes available

---

## Frequently Asked Questions

**Q: How accurate are the predictions?**  
A: Accuracy varies by accessory. The system automatically picks the most accurate model for each one. The dashboard shows the error metric (RMSE) for transparency.

**Q: Why three models instead of just one?**  
A: Different accessories have different demand patterns. Some are steady (SES works best), some are highly seasonal (SARIMA wins), some have complex trends (BSTS wins). Using three ensures we always pick the best fit.

**Q: What is AutoML and how does it relate?**  
A: AutoML is SAP HANA's automated machine learning feature. We used it during development to analyze our data — it recommended BSTS as the best algorithm. We then implemented BSTS directly in our pipeline, alongside SES and SARIMA, for a robust three-model competition.

**Q: How often should forecasts be updated?**  
A: Whenever new monthly production data is available. The pipeline re-trains all models and re-selects the best one automatically.

**Q: Can we add new accessory codes?**  
A: Yes. Any new ACCCODE with at least 12 months of data will be automatically picked up by the pipeline.

**Q: What happens if demand changes dramatically?**  
A: The models will gradually adapt — BSTS is particularly good at this because it uses Bayesian learning. However, a major structural change (new product launch, discontinuation) should be accompanied by a pipeline re-run with the latest data.
