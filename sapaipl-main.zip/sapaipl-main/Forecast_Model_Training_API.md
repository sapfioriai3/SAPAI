# Forecast Model Training API — Service Documentation

**App URL:** `https://daimler-ag---cpea-tst-mbusa-voisv-swt-devspace-sapai-pl-app.cfapps.us10.hana.ondemand.com`

---

## Overview

The Accessory Forecast app exposes REST API endpoints for:

1. **Listing model parameters** — see what each forecast model uses
2. **Viewing model comparison** — accuracy metrics for a specific ACCCODE
3. **Re-training with custom parameters** — fine-tune models for any ACCCODE on-demand

All endpoints return JSON. The retrain endpoint runs SAP PAL procedures in real-time against HANA Cloud.

---

## API Endpoints

### 1. `GET /api/models` — List All Models & Default Parameters

Returns the full parameter catalog for all three forecast models plus global settings.

**Request:**
```
GET /api/models
```

**Response:**
```json
{
  "global": {
    "FORECAST_HORIZON": 12,
    "TEST_MONTHS": 3,
    "SEASONAL_PERIOD": 12
  },
  "SES": {
    "description": "Simple Exponential Smoothing (PAL_BROWN_EXPSMOOTH)",
    "pal_procedure": "_SYS_AFL.PAL_BROWN_EXPSMOOTH",
    "sql_call": "CALL _SYS_AFL.PAL_BROWN_EXPSMOOTH(#PAL_DATA, #SES_PARAM, #SES_OUT, #SES_STATS)",
    "params": {
      "FORECAST_NUM": {
        "value": "auto",
        "type": "int",
        "description": "Number of periods to forecast (test + future). Auto = TEST_MONTHS + FORECAST_HORIZON."
      },
      "ALPHA": {
        "value": "auto",
        "type": "double",
        "description": "Smoothing constant (0.0-1.0). Lower = smoother/stable, Higher = reactive/volatile. Default: auto-optimized by PAL."
      }
    }
  },
  "SARIMA": {
    "description": "Seasonal AutoARIMA (PAL_AUTOARIMA + PAL_ARIMA_FORECAST)",
    "pal_procedure": "_SYS_AFL.PAL_AUTOARIMA → _SYS_AFL.PAL_ARIMA_FORECAST",
    "sql_calls": [
      "CALL _SYS_AFL.PAL_AUTOARIMA(:lt_data, :lt_param, lt_model, lt_fit)",
      "CALL _SYS_AFL.PAL_ARIMA_FORECAST(:lt_data, :lt_model, :lt_param, lt_result)"
    ],
    "params": {
      "SEASONAL_PERIOD": {"value": 12, "type": "int", "description": "Seasonal cycle length. Capped at train_cutoff-1 per series."},
      "METHOD": {"value": 1, "type": "int", "description": "Information criterion. 0=AIC, 1=AICc (default), 2=BIC."},
      "THREAD_RATIO": {"value": 1.0, "type": "double", "description": "Thread usage ratio (0-1). 1.0 = all threads."},
      "FORECAST_LENGTH": {"value": "auto", "type": "int", "description": "Periods to forecast."},
      "FORECAST_METHOD": {"value": 1, "type": "int", "description": "1 = innovations algorithm."},
      "MAX_P": {"value": "auto", "type": "int", "description": "Maximum AR order p. Limits model complexity. Default: unlimited."},
      "MAX_Q": {"value": "auto", "type": "int", "description": "Maximum MA order q. Limits model complexity. Default: unlimited."}
    }
  },
  "BSTS": {
    "description": "Bayesian Structural Time Series (hana_ml BSTS class)",
    "pal_procedure": "hana_ml.algorithms.pal.tsa.bsts.BSTS",
    "sql_call": "BSTS(burn, niter, seasonal_period, seed, local_linear_trend, damped).fit(data, key, endog).predict(horizon)",
    "params": {
      "burn": {"value": 0.5, "type": "double", "description": "Fraction of MCMC iterations to discard as burn-in (0-1)."},
      "niter": {"value": 2000, "type": "int", "description": "Total MCMC iterations. Higher = better accuracy, slower."},
      "seasonal_period": {"value": 12, "type": "int", "description": "Seasonal cycle length."},
      "seed": {"value": 1, "type": "int", "description": "Random seed for reproducibility."},
      "local_linear_trend": {"value": true, "type": "bool", "description": "True = level + trend (default). False = level only for flat/stable series."},
      "damped": {"value": false, "type": "bool", "description": "Damped trend. True = prevents forecast diverging on long horizons."}
    }
  }
}
```

---

### 2. `GET /api/models/<MODEL_NAME>` — Single Model Parameters

Get parameters for one model: `SES`, `SARIMA`, or `BSTS`.

**Examples:**
```
GET /api/models/SARIMA
GET /api/models/BSTS
GET /api/models/SES
```

---

### 3. `GET /api/models/acccode/<CODE>` — Model Comparison for an ACCCODE

Returns stored accuracy metrics from the last training run.

**Request:**
```
GET /api/models/acccode/D49
```

**Response:**
```json
{
  "acccode": "D49",
  "models": [
    {"model": "BSTS",   "mape": 8.42, "rmse": 156.3, "total_volume": 45230, "data_points": 50, "is_best": true},
    {"model": "SARIMA", "mape": 12.1, "rmse": 201.5, "total_volume": 45230, "data_points": 50, "is_best": false},
    {"model": "SES",    "mape": 15.7, "rmse": 245.8, "total_volume": 45230, "data_points": 50, "is_best": false}
  ]
}
```

---

### 4. `POST /api/retrain/acccode/<CODE>` — Re-train with Custom Parameters

**This is the fine-tuning endpoint.** Runs SES/SARIMA/BSTS models in real-time on HANA Cloud for any ACCCODE, with custom parameter overrides.

**Request:**
```
POST /api/retrain/acccode/D49
Content-Type: application/json

{
  "models": ["SARIMA", "BSTS"],
  "FORECAST_HORIZON": 12,
  "TEST_MONTHS": 3,
  "SEASONAL_PERIOD": 12,
  "SARIMA": {
    "METHOD": 1,
    "THREAD_RATIO": 1.0,
    "MAX_P": 5,
    "MAX_Q": 5
  },
  "BSTS": {
    "burn": 0.5,
    "niter": 3000,
    "seed": 42,
    "local_linear_trend": true,
    "damped": false
  }
}
```

**All fields are optional.** Omitted values use defaults.

**Response:**
```json
{
  "acccode": "D49",
  "train_cutoff": 47,
  "test_months": 3,
  "effective_end": 50,
  "forecast_horizon": 12,
  "params_used": {
    "SARIMA": {
      "SEASONAL_PERIOD": 12,
      "METHOD": 1,
      "THREAD_RATIO": 1.0,
      "FORECAST_LENGTH": 15,
      "FORECAST_METHOD": 1,
      "MAX_P": 5,
      "MAX_Q": 5
    },
    "BSTS": {
      "burn": 0.5,
      "niter": 3000,
      "seasonal_period": 12,
      "seed": 42,
      "local_linear_trend": true,
      "damped": false
    }
  },
  "seasonal_indices": {
    "01": 1.0523,
    "02": 0.9812,
    "12": 0.7341
  },
  "test_actual": [1250, 1180, 890],
  "models": {
    "SARIMA": {
      "mape": 11.5,
      "rmse": 198.3,
      "test_forecast": [1310.2, 1095.1, 845.6],
      "future_forecast": [1280.0, 1305.5, 1198.2, ...]
    },
    "BSTS": {
      "mape": 7.8,
      "rmse": 142.1,
      "test_forecast": [1220.5, 1150.3, 920.1],
      "future_forecast": [1265.0, 1290.8, 1175.4, ...]
    }
  },
  "best_model": "BSTS"
}
```

---

## Parameter Tuning Journey — How We Got Here

### The Iteration Story

We didn't start with these parameters. The model pipeline went through **4 major iterations and 13 experimental scripts** before landing on the current production configuration. Here's what changed, why, and what we learned.

```
┌──────────────────────────────────────────────────────────────────────────┐
│              PARAMETER TUNING ITERATIONS                                  │
│                                                                          │
│  ITERATION 1 (Initial)           ITERATION 2 (Improved)                  │
│  ─────────────────────           ─────────────────────────                │
│  Models: SES + Holt-Winters      Models: SES + HW + SARIMA              │
│  Forecast: 6 months              Forecast: 6 months                      │
│  HW: PAL_TRIPLE_EXPSMOOTH        SARIMA: PAL_AUTOARIMA (auto-search)     │
│  No outlier detection             + Outlier detection (PAL)              │
│  No data cliff detection          + Data cliff detection                  │
│  1 PAL param: FORECAST_NUM        + Seasonal Naive baseline              │
│                                                                          │
│  ITERATION 3 (AutoML Test)       ITERATION 4 (Production + API)          │
│  ─────────────────────           ──────────────────────────               │
│  Tried PAL_AUTOML_FIT            Models: SES + SARIMA + BSTS            │
│  9 test scripts executed         Forecast: 12 months                     │
│  AutoML recommends BSTS          BSTS: burn=0.5, niter=2000, seed=1     │
│  4 BSTS test iterations          + 5 new tunable params via API          │
│  → conn.sql() breakthrough       + Composite key forecasting             │
│                                   + Non-negative clamping                 │
│  TOTAL: 13 experimental scripts before final pipeline                    │
└──────────────────────────────────────────────────────────────────────────┘
```

### What Changed at Each Iteration

| Parameter | Iteration 1 | Iteration 2 | Iteration 3 | Iteration 4 (Current) | Why Changed |
|-----------|-------------|-------------|-------------|----------------------|-------------|
| **Models** | SES + Holt-Winters | SES + HW + SARIMA | AutoML tested all | **SES + SARIMA + BSTS** | AutoML recommended BSTS; HW dropped |
| **Forecast Horizon** | 6 months | 6 months | 6 months | **12 months** | Business needed full-year planning |
| **Test Holdout** | 5 months | 5 months | 5 months | **3 months** (API default) | More training data for BSTS |
| **SES ALPHA** | Auto (PAL) | Auto (PAL) | — | **Auto (PAL), now user-tunable** | Added to API so users can override |
| **SARIMA type** | — | PAL_AUTOARIMA | Auto | **PAL_AUTOARIMA (auto-search)** | Let PAL pick best order |
| **SARIMA METHOD** | — | Default (AICc) | — | **1 = AICc, user can set 0/2** | AICc balances fit vs complexity |
| **SARIMA MAX_P/MAX_Q** | — | Unlimited | — | **User-tunable (new)** | Constrain search to prevent overfitting |
| **BSTS niter** | — | — | 1000 (test) | **2000 (default), user-tunable** | 1000 insufficient for convergence |
| **BSTS burn** | — | — | 0.5 | **0.5 (default), user-tunable** | Standard 50% burn-in for MCMC |
| **BSTS seed** | — | — | 1 | **1 (default), user-tunable** | Reproducible results across runs |
| **BSTS local_linear_trend** | — | — | True | **True (default), now user-tunable** | Some series are flat — level-only works better |
| **BSTS damped** | — | — | Not available | **False (default), now user-tunable** | Prevents divergence on long horizons |
| **Negative Clamping** | None | Partial | Partial | **`max(0, forecast)` all models** | SARIMA can produce negative counts |
| **Seasonal Adjustment** | None | None | None | **Multiplicative post-adjustment** | Historical monthly indices improve accuracy |

### Key Decisions & Lessons Learned

1. **Why BSTS over Holt-Winters?** AutoML (PAL_AUTOML_FIT) tested all available algorithms and BSTS consistently won. BSTS handles both trend and seasonality with Bayesian inference — more robust than triple exponential smoothing on short series.

2. **Why expose ALPHA for SES?** PAL auto-optimizes ALPHA by default. But some users want direct control — a low alpha (0.2–0.3) smooths out noise for stable series; a high alpha (0.7–0.9) tracks recent demand changes for volatile series.

3. **Why add MAX_P and MAX_Q?** With only ~24 months of data, unrestricted ARIMA order search can pick complex models like (3,1,3)(2,1,2)[12] that overfit. Setting MAX_P=3 and MAX_Q=2 constrains the search to simpler, more generalizable models.

4. **Why local_linear_trend and damped for BSTS?** Not all accessories have a growth trend. Setting `local_linear_trend=false` for flat/stable series (e.g., mature accessories with constant demand) removes the trend component entirely. Setting `damped=true` for long horizons (24+ months) prevents the trend from extrapolating forever.

---

## Complete Parameter Matrix — All Models at a Glance

### How to Read This Matrix

- **Default** = what the API uses if you don't pass the parameter
- **Tunable** = can be overridden via the POST `/api/retrain/acccode/<code>` endpoint
- **SQL/Call** = the actual HANA procedure or Python call where this parameter is sent

### Master Parameter Matrix

| Model | Parameter | Default | Type | Range | Tunable via API? | Passed To (SQL/Call) | Effect |
|-------|-----------|---------|------|-------|-----------------|---------------------|--------|
| **Global** | `FORECAST_HORIZON` | 12 | int | 1–24 | Yes | Computed → `total_forecast` | How many future months to predict |
| **Global** | `TEST_MONTHS` | 3 | int | 1–6 | Yes | Computed → `train_cutoff` | Months held out for MAPE testing |
| **Global** | `SEASONAL_PERIOD` | 12 | int | 4–12 | Yes | Capped → `eff_seasonal` | Seasonal cycle (12=yearly, 6=semi-annual) |
| | | | | | | | |
| **SES** | `FORECAST_NUM` | auto | int | — | No (auto) | `INSERT INTO #SES_PARAM ('FORECAST_NUM', N)` → `CALL _SYS_AFL.PAL_BROWN_EXPSMOOTH()` | Total periods to forecast (test + future) |
| **SES** | `ALPHA` | auto | double | 0.0–1.0 | **Yes** | `INSERT INTO #SES_PARAM ('ALPHA', NULL, val, NULL)` → `CALL _SYS_AFL.PAL_BROWN_EXPSMOOTH()` | Smoothing constant. Low=stable, High=reactive |
| | | | | | | | |
| **SARIMA** | `SEASONAL_PERIOD` | 12 | int | 4–12 | Yes (global) | `INSERT INTO #ARIMA_PARAM ('SEASONAL_PERIOD', N)` → `CALL _SYS_AFL.PAL_AUTOARIMA()` | Seasonal cycle for order search |
| **SARIMA** | `METHOD` | 1 | int | 0, 1, 2 | **Yes** | `INSERT INTO #ARIMA_PARAM ('METHOD', N)` → `CALL _SYS_AFL.PAL_AUTOARIMA()` | 0=AIC, 1=AICc, 2=BIC |
| **SARIMA** | `THREAD_RATIO` | 1.0 | double | 0.0–1.0 | **Yes** | `INSERT INTO #ARIMA_PARAM ('THREAD_RATIO', NULL, val)` → `CALL _SYS_AFL.PAL_AUTOARIMA()` | CPU thread utilization |
| **SARIMA** | `MAX_P` | auto | int | 1–10 | **Yes** | `INSERT INTO #ARIMA_PARAM ('MAX_P', N)` → `CALL _SYS_AFL.PAL_AUTOARIMA()` | Cap AR order — prevents complex models |
| **SARIMA** | `MAX_Q` | auto | int | 1–10 | **Yes** | `INSERT INTO #ARIMA_PARAM ('MAX_Q', N)` → `CALL _SYS_AFL.PAL_AUTOARIMA()` | Cap MA order — prevents complex models |
| **SARIMA** | `FORECAST_LENGTH` | auto | int | — | No (auto) | `INSERT INTO #FC_PARAM ('FORECAST_LENGTH', N)` → `CALL _SYS_AFL.PAL_ARIMA_FORECAST()` | Total periods to forecast |
| **SARIMA** | `FORECAST_METHOD` | 1 | int | 1 | **Yes** | `INSERT INTO #FC_PARAM ('FORECAST_METHOD', N)` → `CALL _SYS_AFL.PAL_ARIMA_FORECAST()` | 1 = innovations algorithm |
| | | | | | | | |
| **BSTS** | `burn` | 0.5 | double | 0.1–0.8 | **Yes** | `BSTS(burn=0.5, ...)` → hana_ml → HANA Script Server | MCMC burn-in fraction |
| **BSTS** | `niter` | 2000 | int | 500–10000 | **Yes** | `BSTS(niter=2000, ...)` → hana_ml → HANA Script Server | MCMC iterations (accuracy vs speed) |
| **BSTS** | `seasonal_period` | 12 | int | 4–12 | Yes (global) | `BSTS(seasonal_period=12, ...)` → hana_ml → HANA Script Server | Seasonal cycle length |
| **BSTS** | `seed` | 1 | int | any | **Yes** | `BSTS(seed=1, ...)` → hana_ml → HANA Script Server | Random seed for reproducibility |
| **BSTS** | `local_linear_trend` | true | bool | true/false | **Yes** | `BSTS(local_linear_trend=True, ...)` → hana_ml → HANA Script Server | True=level+trend, False=level-only |
| **BSTS** | `damped` | false | bool | true/false | **Yes** | `BSTS(damped=False, ...)` → hana_ml → HANA Script Server | Damped trend (prevents divergence) |

### Quick Reference: Which Parameters Matter Most?

```
┌──────────────────────────────────────────────────────────────────────────┐
│  HIGH IMPACT (try these first)                                            │
│  ─────────────────────────────                                            │
│  SES:     ALPHA          → directly controls smoothing behavior          │
│  SARIMA:  METHOD (0/1/2) → changes which ARIMA order gets picked         │
│  BSTS:    niter          → more iterations = more precise MCMC           │
│  BSTS:    local_linear_trend → removes/adds trend component              │
│                                                                          │
│  MEDIUM IMPACT (refinement)                                               │
│  ──────────────────────────                                               │
│  SARIMA:  MAX_P, MAX_Q   → constrains overfitting on short series        │
│  BSTS:    damped         → prevents runaway forecasts on 24+ months      │
│  BSTS:    burn           → 0.2 keeps more MCMC samples (noisier)         │
│  Global:  SEASONAL_PERIOD → try 6 for semi-annual patterns               │
│                                                                          │
│  LOW IMPACT (rarely changed)                                              │
│  ────────────────────────                                                 │
│  SARIMA:  THREAD_RATIO   → only affects speed, not accuracy              │
│  SARIMA:  FORECAST_METHOD → only 1 option (innovations)                  │
│  BSTS:    seed           → only changes if you want different MCMC run   │
│  Global:  FORECAST_HORIZON → usually stays at 12 (business requirement)  │
└──────────────────────────────────────────────────────────────────────────┘
```

### Recommended Tuning Recipes

| Scenario | Recipe |
|----------|--------|
| **Volatile series (demand swings)** | `SES: {"ALPHA": 0.8}` + `BSTS: {"niter": 3000}` |
| **Stable/flat demand** | `SES: {"ALPHA": 0.2}` + `BSTS: {"local_linear_trend": false}` |
| **Short history (<18 months)** | `SEASONAL_PERIOD: 6` + `SARIMA: {"MAX_P": 2, "MAX_Q": 2}` |
| **Long horizon (24 months)** | `FORECAST_HORIZON: 24` + `BSTS: {"damped": true, "niter": 3000}` |
| **SARIMA overfitting** | `SARIMA: {"METHOD": 2, "MAX_P": 3, "MAX_Q": 2}` |
| **BSTS noisy results** | `BSTS: {"niter": 5000, "burn": 0.6}` |

---

## Fine-Tuning Guide

### When to Fine-Tune

| Symptom | Likely Cause | Parameter to Adjust |
|---------|-------------|-------------------|
| December predictions too high | Model misses seasonal dip | Check `seasonal_indices` in response. If `"12"` index is < 0.8, the seasonal correction is working. Try `SEASONAL_PERIOD: 12`. |
| Predictions flat / no trend | SES can't capture trends | Switch to `"models": ["SARIMA", "BSTS"]` |
| BSTS results noisy | Not enough MCMC iterations | Increase `BSTS.niter` to 3000-5000 |
| SARIMA picks wrong order | AICc may overfit | Try `SARIMA.METHOD: 2` (BIC penalizes complexity more) |
| New ACCCODE has short history | Not enough seasonal data | Reduce `SEASONAL_PERIOD` to 6 |

### Step-by-Step: Fine-Tune a Single ACCCODE

**1. Check current performance:**
```bash
curl https://<APP_URL>/api/models/acccode/D49
```

**2. Re-train with adjusted BSTS parameters (more iterations):**
```bash
curl -X POST https://<APP_URL>/api/retrain/acccode/D49 \
  -H "Content-Type: application/json" \
  -d '{
    "models": ["SARIMA", "BSTS"],
    "BSTS": {"niter": 4000, "burn": 0.3}
  }'
```

**3. Compare MAPE/RMSE in the response to decide if the new parameters are better.**

**4. Try BIC for SARIMA order selection:**
```bash
curl -X POST https://<APP_URL>/api/retrain/acccode/D49 \
  -H "Content-Type: application/json" \
  -d '{
    "models": ["SARIMA"],
    "SARIMA": {"METHOD": 2}
  }'
```

### Parameter Reference

#### Global Parameters

| Parameter | Default | Range | Description |
|-----------|---------|-------|-------------|
| `FORECAST_HORIZON` | 12 | 1-24 | Future months to predict |
| `TEST_MONTHS` | 3 | 1-6 | Months held out for accuracy testing |
| `SEASONAL_PERIOD` | 12 | 4-12 | Seasonal cycle length |

#### SES (Simple Exponential Smoothing)

**SQL Procedure:** `CALL _SYS_AFL.PAL_BROWN_EXPSMOOTH(#PAL_DATA, #SES_PARAM, #SES_OUT, #SES_STATS)`

| Parameter | Default | Range | Description |
|-----------|---------|-------|-------------|
| `FORECAST_NUM` | auto | - | Set automatically. Typically no tuning needed. |
| `ALPHA` | auto | 0.0-1.0 | Smoothing constant. Lower = smoother (stable forecasts), Higher = more reactive (follows recent data). Default: PAL auto-optimizes. |

SES is a baseline model. It cannot capture trends or seasonality natively (seasonal post-adjustment is applied). Best for stable, non-seasonal series.

#### SARIMA (AutoARIMA)

**SQL Procedures (two-step):**
1. `CALL _SYS_AFL.PAL_AUTOARIMA(:lt_data, :lt_param, lt_model, lt_fit)` — auto-selects best (p,d,q)(P,D,Q) order
2. `CALL _SYS_AFL.PAL_ARIMA_FORECAST(:lt_data, :lt_model, :lt_param, lt_result)` — generates forecast

| Parameter | Default | Options | Description |
|-----------|---------|---------|-------------|
| `METHOD` | 1 | 0=AIC, 1=AICc, 2=BIC | Model selection criterion. BIC (2) prefers simpler models. |
| `THREAD_RATIO` | 1.0 | 0.0-1.0 | Thread utilization |
| `FORECAST_METHOD` | 1 | 1 | Innovations algorithm |
| `MAX_P` | auto | 1-10 | Maximum AR order p. Caps model complexity. Default: PAL searches all. |
| `MAX_Q` | auto | 1-10 | Maximum MA order q. Caps model complexity. Default: PAL searches all. |

AutoARIMA auto-selects the best (p,d,q)(P,D,Q) orders. The `METHOD` parameter controls how it balances model complexity vs fit. Use `MAX_P`/`MAX_Q` to constrain the search space.

#### BSTS (Bayesian Structural Time Series)

**Python Call:** `BSTS(burn, niter, seasonal_period, seed, local_linear_trend, damped).fit(data, key, endog).predict(horizon)`

*(Delegates to SAP HANA PAL Script Server via hana_ml SDK)*

| Parameter | Default | Range | Description |
|-----------|---------|-------|-------------|
| `burn` | 0.5 | 0.1-0.8 | Burn-in fraction. Lower = use more samples (noisier). Higher = more conservative. |
| `niter` | 2000 | 500-10000 | MCMC iterations. More = better but slower (~5-15 sec per ACCCODE at 2000). |
| `seed` | 1 | any int | Random seed. Change to get different sampling runs. |
| `seasonal_period` | 12 | 4-12 | Auto-capped at train_cutoff-1 |
| `local_linear_trend` | true | true/false | True = level + trend component (default). False = level only — use for flat/stable series with no growth. |
| `damped` | false | true/false | Damped trend. True = forecast trend flattens over time, preventing divergence. Recommended for 24+ month horizons. |

BSTS decomposes the series into trend + seasonal + regression components using Bayesian inference. It's often the best model for series with clear seasonality.

---

## Architecture Notes

- All models run **server-side on SAP HANA Cloud** via PAL (Predictive Analysis Library)
- BSTS uses the `hana_ml` Python SDK which delegates computation to HANA's Script Server
- The retrain endpoint does **NOT** overwrite stored results — it returns fresh predictions for comparison
- To persist new results, use the batch scripts (`04_forecast_models.py` or `04c_composite_forecast_models.py`)
- Seasonal post-adjustment is applied automatically: historical monthly averages create multiplicative indices

---

## cURL Examples

```bash
# Base URL
BASE="https://daimler-ag---cpea-tst-mbusa-voisv-swt-devspace-sapai-pl-app.cfapps.us10.hana.ondemand.com"

# List all model parameters
curl "$BASE/api/models"

# Get BSTS parameters only
curl "$BASE/api/models/BSTS"

# Check D49 model accuracy
curl "$BASE/api/models/acccode/D49"

# Retrain D49 with all 3 models (defaults)
curl -X POST "$BASE/api/retrain/acccode/D49" \
  -H "Content-Type: application/json" \
  -d '{}'

# Retrain D49 with only BSTS, more iterations
curl -X POST "$BASE/api/retrain/acccode/D49" \
  -H "Content-Type: application/json" \
  -d '{"models": ["BSTS"], "BSTS": {"niter": 5000}}'

# Retrain D43 with SARIMA using BIC criterion
curl -X POST "$BASE/api/retrain/acccode/D43" \
  -H "Content-Type: application/json" \
  -d '{"models": ["SARIMA"], "SARIMA": {"METHOD": 2}}'
```
