"""
04c_composite_forecast_models.py
─────────────────────────────────
Runs SES, SARIMA, and BSTS forecasts via SAP PAL for each
COMPOSITE_KEY (ACCCODE|VPC_LOCATION|MODEL).

Flow:
  1. Connect to HANA Cloud HDI container
  2. Load monthly time series (COMPOSITE_TIMESERIES)
  3. Detect reliable data range per composite key
  4. For each composite key, run 3 forecast models:
     a. PAL_BROWN_EXPSMOOTH   (SES baseline)
     b. PAL_AUTOARIMA + PAL_ARIMA_FORECAST (SARIMA)
     c. BSTS via hana_ml Python API
  5. Clamp all predictions >= 0
  6. Compute MAPE/RMSE on the held-out test period
  7. Pick the best model per composite key (lowest MAPE)
  8. Store results in COMPOSITE_FORECAST_RESULTS and COMPOSITE_MODEL_COMPARISON

Prerequisites:
  - AFL__SYS_AFL_AFLPAL_EXECUTE role granted to the HDI RT user
  - Script Server enabled on the HANA Cloud instance
  - pip install hana-ml pandas python-dotenv numpy
"""

import os, json
from dotenv import load_dotenv
load_dotenv()
import pandas as pd
import numpy as np
from hana_ml.dataframe import ConnectionContext
from hana_ml.algorithms.pal.tsa.bsts import BSTS

# ─── Configuration ───
FORECAST_HORIZON = 12     # Predict 12 future months
TEST_MONTHS = 3            # Last 3 months for model evaluation (Dec 2025, Jan-Feb 2026)
SEASONAL_PERIOD = 12       # Monthly data with yearly seasonality


def _hana_creds():
    if os.environ.get('HANA_HOST'):
        return {
            'host': os.environ['HANA_HOST'],
            'port': int(os.environ['HANA_PORT']),
            'user': os.environ['HANA_USER'],
            'password': os.environ['HANA_PASSWORD'],
            'schema': os.environ.get('HANA_SCHEMA', ''),
        }
    vcap = os.environ.get('VCAP_SERVICES')
    if vcap:
        svc = json.loads(vcap)
        hana = svc.get('hana', [{}])[0].get('credentials', {})
        return {
            'host': hana['host'],
            'port': int(hana['port']),
            'user': hana['user'],
            'password': hana['password'],
            'schema': hana.get('schema', ''),
        }
    raise RuntimeError('No HANA credentials found')


# ─── Connect to HANA Cloud ───
creds = _hana_creds()
conn = ConnectionContext(
    address=creds['host'],
    port=creds['port'],
    user=creds['user'],
    password=creds['password'],
    encrypt=True
)
cursor = conn.connection.cursor()
if creds['schema']:
    cursor.execute('SET SCHEMA "{}"'.format(creds['schema'].replace('"', '""')))

# ─── Helper: execute SQL, return rows if SELECT ───
def sql(stmt):
    cursor.execute(stmt)
    if stmt.strip().upper().startswith('SELECT') or stmt.strip().upper().startswith('CALL'):
        try:
            return cursor.fetchall()
        except:
            return []
    return []

def drop_temp(name):
    try:
        cursor.execute(f"DROP TABLE {name}")
    except:
        pass

# ─── Load time series info ───
ts_df = conn.table('COMPOSITE_TIMESERIES').collect()
ts_df['PROD_DATE'] = pd.to_datetime(ts_df['PROD_DATE'])
composite_keys = sorted(ts_df['COMPOSITE_KEY'].unique())
n_periods = int(ts_df.groupby('COMPOSITE_KEY')['TIME_ID'].max().iloc[0])

print(f"Loaded {len(ts_df):,} rows for {len(composite_keys)} composite keys")
print(f"Time periods: {n_periods} months\n")

# ─── Detect per-key reliable data range ─────────────────────
def find_effective_end(key_ts):
    nonzero = key_ts[key_ts['VEHICLECOUNT'] > 0]['VEHICLECOUNT']
    if len(nonzero) == 0:
        return 12
    avg = nonzero.mean()
    threshold = max(avg * 0.10, 1)
    sorted_ts = key_ts.sort_values('TIME_ID', ascending=False)
    for _, row in sorted_ts.iterrows():
        if row['VEHICLECOUNT'] >= threshold:
            return int(row['TIME_ID'])
    return 12

key_splits = {}
for key in composite_keys:
    key_ts = ts_df[ts_df['COMPOSITE_KEY'] == key].sort_values('TIME_ID')
    eff_end = find_effective_end(key_ts)
    min_needed = 12 + TEST_MONTHS
    if eff_end < min_needed:
        eff_train_cutoff = max(eff_end - 2, 10)
        eff_test_months = eff_end - eff_train_cutoff
    else:
        eff_train_cutoff = eff_end - TEST_MONTHS
        eff_test_months = TEST_MONTHS
    key_splits[key] = {
        'effective_end': eff_end,
        'train_cutoff': eff_train_cutoff,
        'test_months': eff_test_months,
    }

# ── MAPE / RMSE helpers ─────────────────────────────────────────
def calc_mape(actual, forecast):
    actual, forecast = np.array(actual, dtype=float), np.array(forecast, dtype=float)
    mask = actual > 0
    if mask.sum() == 0:
        return float('inf')
    return float(np.mean(np.abs((actual[mask] - forecast[mask]) / actual[mask])) * 100)

def calc_wmape(actual, forecast):
    """Time-weighted MAPE: recent months weighted more heavily (exponential decay)."""
    actual, forecast = np.array(actual, dtype=float), np.array(forecast, dtype=float)
    mask = actual > 0
    if mask.sum() == 0:
        return float('inf')
    n = len(actual)
    weights = np.array([2.0 ** (i / n) for i in range(n)])
    weights = weights[mask]
    weights = weights / weights.sum()
    return float(np.sum(weights * np.abs((actual[mask] - forecast[mask]) / actual[mask])) * 100)

def calc_rmse(actual, forecast):
    return float(np.sqrt(np.mean((np.array(actual, dtype=float) - np.array(forecast, dtype=float)) ** 2)))

def calc_smape(actual, forecast):
    """Symmetric MAPE: handles zero actuals better than MAPE."""
    actual, forecast = np.array(actual, dtype=float), np.array(forecast, dtype=float)
    denom = (np.abs(actual) + np.abs(forecast))
    mask = denom > 0
    if mask.sum() == 0:
        return float('inf')
    return float(np.mean(2.0 * np.abs(actual[mask] - forecast[mask]) / denom[mask]) * 100)

def calc_mad(actual, forecast):
    """Mean Absolute Deviation."""
    return float(np.mean(np.abs(np.array(actual, dtype=float) - np.array(forecast, dtype=float))))

# ═══════════════════════════════════════════════════════════════════
#  RUN PAL FORECASTS FOR EACH COMPOSITE KEY
# ═══════════════════════════════════════════════════════════════════
all_results = []
all_comparisons = []

for idx, comp_key in enumerate(composite_keys):
    key_ts = ts_df[ts_df['COMPOSITE_KEY'] == comp_key].sort_values('TIME_ID')
    total_volume = int(key_ts['VEHICLECOUNT'].sum())

    parts = comp_key.split('|', 2)
    acccode = parts[0]
    vpc_location = int(parts[1])
    model = parts[2]

    split = key_splits[comp_key]
    train_cutoff = split['train_cutoff']
    eff_test_months = split['test_months']
    effective_end = split['effective_end']
    total_forecast = eff_test_months + FORECAST_HORIZON

    test_actual = key_ts[(key_ts['TIME_ID'] > train_cutoff) &
                         (key_ts['TIME_ID'] <= effective_end)]['VEHICLECOUNT'].values.tolist()

    forecasts = {
        'COMPOSITE_KEY': comp_key,
        'ACCCODE': acccode,
        'VPC_LOCATION': vpc_location,
        'MODEL': model,
        'TEST_ACTUAL': test_actual,
    }

    if (idx + 1) % 50 == 0 or idx == 0:
        print(f"  [{idx+1}/{len(composite_keys)}] {comp_key} "
              f"(train={train_cutoff}, test={eff_test_months}, vol={total_volume:,})")

    # ── Insert training data into temp table ──────────────────────
    drop_temp('#PAL_DATA')
    sql("CREATE LOCAL TEMPORARY COLUMN TABLE #PAL_DATA (TIME_ID INT, VEHICLECOUNT DOUBLE)")
    cursor.execute(
        f"INSERT INTO #PAL_DATA SELECT TIME_ID, CAST(VEHICLECOUNT AS DOUBLE) "
        f"FROM COMPOSITE_TIMESERIES WHERE COMPOSITE_KEY = ? AND TIME_ID <= ?",
        (comp_key, train_cutoff)
    )

    # ══════════════════════════════════════════════════════════════
    #  MODEL 1: PAL_BROWN_EXPSMOOTH (SES)
    # ══════════════════════════════════════════════════════════════
    try:
        drop_temp('#SES_PARAM')
        drop_temp('#SES_OUT')
        drop_temp('#SES_STATS')
        sql("CREATE LOCAL TEMPORARY COLUMN TABLE #SES_PARAM "
            "(PARAM_NAME NVARCHAR(256), INT_VALUE INT, DOUBLE_VALUE DOUBLE, STRING_VALUE NVARCHAR(256))")
        cursor.execute("INSERT INTO #SES_PARAM VALUES (?, ?, NULL, NULL)", ('FORECAST_NUM', total_forecast))
        sql("CREATE LOCAL TEMPORARY COLUMN TABLE #SES_OUT (TIME_ID INT, FORECAST DOUBLE)")
        sql("CREATE LOCAL TEMPORARY COLUMN TABLE #SES_STATS (STAT_NAME NVARCHAR(256), STAT_VALUE DOUBLE)")

        sql("CALL _SYS_AFL.PAL_BROWN_EXPSMOOTH(#PAL_DATA, #SES_PARAM, #SES_OUT, #SES_STATS)")

        cursor.execute(f"SELECT TIME_ID, FORECAST FROM #SES_OUT "
                       f"WHERE TIME_ID > {train_cutoff} ORDER BY TIME_ID")
        ses_rows = cursor.fetchall()

        if ses_rows:
            ses_test = [max(0.0, float(r[1])) for r in ses_rows[:eff_test_months]]
            ses_future = [max(0.0, float(r[1])) for r in ses_rows[eff_test_months:eff_test_months + FORECAST_HORIZON]]
            forecasts['SES_TEST'] = ses_test
            forecasts['SES_FUTURE'] = ses_future
    except Exception as e:
        print(f"  SES failed for {comp_key}: {e}")

    # ══════════════════════════════════════════════════════════════
    #  MODEL 2: PAL_AUTOARIMA + PAL_ARIMA_FORECAST  (SARIMA)
    #  AutoARIMA auto-selects best (P,D,Q)(SP,SD,SQ) orders
    # ══════════════════════════════════════════════════════════════
    eff_seasonal = min(SEASONAL_PERIOD, train_cutoff - 1)
    try:
        drop_temp('#ARIMA_PARAM')
        drop_temp('#ARIMA_MODEL')
        drop_temp('#ARIMA_FIT')
        sql("CREATE LOCAL TEMPORARY COLUMN TABLE #ARIMA_PARAM "
            "(PARAM_NAME NVARCHAR(256), INT_VALUE INT, DOUBLE_VALUE DOUBLE, STRING_VALUE NVARCHAR(256))")
        cursor.execute("INSERT INTO #ARIMA_PARAM VALUES (?, ?, NULL, NULL)", ('SEASONAL_PERIOD', eff_seasonal))
        cursor.execute("INSERT INTO #ARIMA_PARAM VALUES (?, ?, NULL, NULL)", ('METHOD', 1))
        cursor.execute("INSERT INTO #ARIMA_PARAM VALUES (?, NULL, ?, NULL)", ('THREAD_RATIO', 1.0))
        sql("CREATE LOCAL TEMPORARY COLUMN TABLE #ARIMA_MODEL (KEY NVARCHAR(256), VALUE NVARCHAR(5000))")
        sql("CREATE LOCAL TEMPORARY COLUMN TABLE #ARIMA_FIT (TIME_ID INT, FITTED DOUBLE, RESIDUALS DOUBLE)")

        cursor.execute("""
DO BEGIN
    lt_data = SELECT TIME_ID, VEHICLECOUNT FROM #PAL_DATA;
    lt_param = SELECT PARAM_NAME, INT_VALUE, DOUBLE_VALUE, STRING_VALUE FROM #ARIMA_PARAM;
    CALL _SYS_AFL.PAL_AUTOARIMA(:lt_data, :lt_param, lt_model, lt_fit);
    INSERT INTO #ARIMA_MODEL SELECT * FROM :lt_model;
    INSERT INTO #ARIMA_FIT SELECT * FROM :lt_fit;
END;
""")

        drop_temp('#FC_DATA')
        drop_temp('#FC_PARAM')
        drop_temp('#FC_OUT')
        sql("CREATE LOCAL TEMPORARY COLUMN TABLE #FC_DATA (TIME_ID INT, VEHICLECOUNT DOUBLE)")
        sql("CREATE LOCAL TEMPORARY COLUMN TABLE #FC_PARAM "
            "(PARAM_NAME NVARCHAR(256), INT_VALUE INT, DOUBLE_VALUE DOUBLE, STRING_VALUE NVARCHAR(256))")
        cursor.execute("INSERT INTO #FC_PARAM VALUES (?, ?, NULL, NULL)", ('FORECAST_LENGTH', total_forecast))
        cursor.execute("INSERT INTO #FC_PARAM VALUES (?, ?, NULL, NULL)", ('FORECAST_METHOD', 1))
        sql("CREATE LOCAL TEMPORARY COLUMN TABLE #FC_OUT "
            "(TIME_ID INT, FORECAST DOUBLE, SE DOUBLE, LO80 DOUBLE, HI80 DOUBLE, "
            "LO95 DOUBLE, HI95 DOUBLE)")

        cursor.execute("""
DO BEGIN
    lt_data = SELECT TIME_ID, VEHICLECOUNT FROM #FC_DATA;
    lt_model = SELECT KEY, VALUE FROM #ARIMA_MODEL;
    lt_param = SELECT PARAM_NAME, INT_VALUE, DOUBLE_VALUE, STRING_VALUE FROM #FC_PARAM;
    CALL _SYS_AFL.PAL_ARIMA_FORECAST(:lt_data, :lt_model, :lt_param, lt_result);
    INSERT INTO #FC_OUT SELECT * FROM :lt_result;
END;
""")

        cursor.execute("SELECT TIME_ID, FORECAST FROM #FC_OUT ORDER BY TIME_ID")
        arima_rows = cursor.fetchall()

        if arima_rows:
            arima_test = [max(0.0, float(r[1])) for r in arima_rows[:eff_test_months]]
            arima_future = [max(0.0, float(r[1])) for r in arima_rows[eff_test_months:eff_test_months + FORECAST_HORIZON]]
            forecasts['SARIMA_TEST'] = arima_test
            forecasts['SARIMA_FUTURE'] = arima_future
    except Exception as e:
        print(f"  SARIMA failed for {comp_key}: {e}")

    # ══════════════════════════════════════════════════════════════
    #  MODEL 3: BSTS (Bayesian Structural Time Series)
    #  Uses hana_ml Python API: BSTS class.
    #  burn=0.5, niter=2000, seasonal_period=dynamic, seed=1
    # ══════════════════════════════════════════════════════════════
    try:
        if train_cutoff <= eff_seasonal:
            raise ValueError(f"Only {train_cutoff} training points, need > {eff_seasonal}")

        schema = creds['schema']
        safe_key = comp_key.replace("'", "''")
        hana_train = conn.sql(f"""
            SELECT TIME_ID AS "TIME_STAMP", CAST(VEHICLECOUNT AS DOUBLE) AS "TARGET"
            FROM "{schema}"."COMPOSITE_TIMESERIES"
            WHERE COMPOSITE_KEY='{safe_key}' AND TIME_ID<={train_cutoff}
            ORDER BY TIME_ID
        """)

        bsts_model = BSTS(burn=0.5, niter=2000, seasonal_period=eff_seasonal, seed=1)
        bsts_model.fit(data=hana_train, key='TIME_STAMP', endog='TARGET')
        bsts_result = bsts_model.predict(horizon=total_forecast)

        bsts_fc_df = bsts_result[0].collect()

        bsts_all = []
        for _, row in bsts_fc_df.iterrows():
            offset = int(row['TIME_STAMP'])
            real_tid = train_cutoff + 1 + offset
            val = max(0.0, float(row['FORECAST']))
            bsts_all.append((real_tid, val))

        bsts_all.sort(key=lambda x: x[0])

        bsts_test = [v for tid, v in bsts_all if tid <= effective_end][:eff_test_months]
        bsts_future = [v for tid, v in bsts_all if tid > effective_end][:FORECAST_HORIZON]

        if bsts_test:
            forecasts['BSTS_TEST'] = bsts_test
        if bsts_future:
            forecasts['BSTS_FUTURE'] = bsts_future

    except BaseException as e:
        print(f"  BSTS failed for {comp_key}: {e}")

    # ══════════════════════════════════════════════════════════════
    #  SEASONAL POST-ADJUSTMENT
    #  ────────────────────────────────────────────────────────────
    #  SES (Brown) is non-seasonal; SARIMA/BSTS may under-capture
    #  seasonal dips (e.g. December). Apply historical monthly
    #  seasonal indices as a multiplicative correction.
    # ══════════════════════════════════════════════════════════════
    train_data = key_ts[key_ts['TIME_ID'] <= train_cutoff]
    monthly_means = train_data.groupby('PRODMONTH')['VEHICLECOUNT'].mean()
    overall_mean = train_data['VEHICLECOUNT'].mean()

    if overall_mean > 0 and len(monthly_means) >= 6:
        seasonal_indices = (monthly_means / overall_mean).to_dict()

        # PRODMONTH for test rows
        test_months_list = key_ts[
            (key_ts['TIME_ID'] > train_cutoff) &
            (key_ts['TIME_ID'] <= effective_end)
        ]['PRODMONTH'].tolist()

        # PRODMONTH for future rows
        _lr = key_ts[key_ts['TIME_ID'] == effective_end]
        if len(_lr) > 0:
            _fs = _lr.iloc[0]['PROD_DATE'] + pd.DateOffset(months=1)
        else:
            _fs = key_ts['PROD_DATE'].max() + pd.DateOffset(months=1)
        future_months_list = [
            str((_fs + pd.DateOffset(months=i)).month).zfill(2)
            for i in range(FORECAST_HORIZON)
        ]

        for mp in ['SES', 'SARIMA', 'BSTS']:
            tk, fk = f'{mp}_TEST', f'{mp}_FUTURE'
            if tk in forecasts:
                forecasts[tk] = [
                    max(0.0, v * seasonal_indices.get(
                        test_months_list[i] if i < len(test_months_list) else '01', 1.0))
                    for i, v in enumerate(forecasts[tk])
                ]
            if fk in forecasts:
                forecasts[fk] = [
                    max(0.0, v * seasonal_indices.get(
                        future_months_list[i] if i < len(future_months_list) else '01', 1.0))
                    for i, v in enumerate(forecasts[fk])
                ]

    # ══════════════════════════════════════════════════════════════
    #  ACCURACY: Compute MAPE/RMSE for each model
    # ══════════════════════════════════════════════════════════════
    for model_key, test_key in [('SES', 'SES_TEST'), ('SARIMA', 'SARIMA_TEST'), ('BSTS', 'BSTS_TEST')]:
        if test_key not in forecasts:
            forecasts[f'{model_key}_MAPE'] = float('inf')
            forecasts[f'{model_key}_RMSE'] = float('inf')
            forecasts[f'{model_key}_WMAPE'] = float('inf')
            forecasts[f'{model_key}_SMAPE'] = float('inf')
            forecasts[f'{model_key}_MAD'] = float('inf')
            continue
        forecasts[f'{model_key}_MAPE'] = calc_mape(test_actual, forecasts[test_key])
        forecasts[f'{model_key}_WMAPE'] = calc_wmape(test_actual, forecasts[test_key])
        forecasts[f'{model_key}_RMSE'] = calc_rmse(test_actual, forecasts[test_key])
        forecasts[f'{model_key}_SMAPE'] = calc_smape(test_actual, forecasts[test_key])
        forecasts[f'{model_key}_MAD'] = calc_mad(test_actual, forecasts[test_key])

    # ── Determine the best model (lowest MAPE) ─────────────────
    mapes = {
        'SES': forecasts.get('SES_MAPE', float('inf')),
        'SARIMA': forecasts.get('SARIMA_MAPE', float('inf')),
        'BSTS': forecasts.get('BSTS_MAPE', float('inf')),
    }
    winner = min(mapes, key=mapes.get)

    all_results.append(forecasts)
    all_comparisons.append({
        'COMPOSITE_KEY': comp_key,
        'ACCCODE': acccode,
        'VPC_LOCATION': vpc_location,
        'MODEL': model,
        'TOTAL_VOLUME': total_volume,
        'DATA_POINTS': effective_end,
        'TRAIN_CUTOFF': train_cutoff,
        'TEST_MONTHS': eff_test_months,
        'SES_MAPE': forecasts.get('SES_MAPE', float('inf')),
        'SES_RMSE': forecasts.get('SES_RMSE', float('inf')),
        'SES_WMAPE': forecasts.get('SES_WMAPE', float('inf')),
        'SES_SMAPE': forecasts.get('SES_SMAPE', float('inf')),
        'SES_MAD': forecasts.get('SES_MAD', float('inf')),
        'SARIMA_MAPE': forecasts.get('SARIMA_MAPE', float('inf')),
        'SARIMA_RMSE': forecasts.get('SARIMA_RMSE', float('inf')),
        'SARIMA_WMAPE': forecasts.get('SARIMA_WMAPE', float('inf')),
        'SARIMA_SMAPE': forecasts.get('SARIMA_SMAPE', float('inf')),
        'SARIMA_MAD': forecasts.get('SARIMA_MAD', float('inf')),
        'BSTS_MAPE': forecasts.get('BSTS_MAPE', float('inf')),
        'BSTS_RMSE': forecasts.get('BSTS_RMSE', float('inf')),
        'BSTS_WMAPE': forecasts.get('BSTS_WMAPE', float('inf')),
        'BSTS_SMAPE': forecasts.get('BSTS_SMAPE', float('inf')),
        'BSTS_MAD': forecasts.get('BSTS_MAD', float('inf')),
        'BEST_MODEL': winner,
    })

    # Clean up temp tables
    for t in ['#PAL_DATA', '#SES_PARAM', '#SES_OUT', '#SES_STATS',
              '#ARIMA_PARAM', '#ARIMA_MODEL', '#ARIMA_FIT',
              '#FC_DATA', '#FC_PARAM', '#FC_OUT']:
        drop_temp(t)


# ═══════════════════════════════════════════════════════════════════
#  STORE RESULTS IN HANA
# ═══════════════════════════════════════════════════════════════════
print(f"\n{'═' * 65}")
print("  Storing composite forecast results in HANA")
print("═" * 65)

# ── Keep existing table schema (HW_FORECAST column stores BSTS values) ──
cursor.execute('TRUNCATE TABLE COMPOSITE_FORECAST_RESULTS')

last_date = ts_df['PROD_DATE'].max()

def clamp(v):
    if v is None:
        return None
    return max(0, min(2147483647, int(round(v))))

for res in all_results:
    comp_key = res['COMPOSITE_KEY']
    acccode = res['ACCCODE']
    vpc_location = res['VPC_LOCATION']
    model_name = res['MODEL']
    key_ts = ts_df[ts_df['COMPOSITE_KEY'] == comp_key].sort_values('TIME_ID')
    split = key_splits[comp_key]
    tc = split['train_cutoff']
    ee = split['effective_end']

    # Test rows
    test_rows = key_ts[(key_ts['TIME_ID'] > tc) & (key_ts['TIME_ID'] <= ee)]

    for i, (_, row) in enumerate(test_rows.iterrows()):
        ses_val = clamp(res['SES_TEST'][i]) if 'SES_TEST' in res and i < len(res.get('SES_TEST', [])) else None
        bsts_val = clamp(res['BSTS_TEST'][i]) if 'BSTS_TEST' in res and i < len(res.get('BSTS_TEST', [])) else None
        sar_val = clamp(res['SARIMA_TEST'][i]) if 'SARIMA_TEST' in res and i < len(res.get('SARIMA_TEST', [])) else None
        cursor.execute(
            "INSERT INTO COMPOSITE_FORECAST_RESULTS (COMPOSITE_KEY, ACCCODE, VPC_LOCATION, MODEL, PROD_DATE, PRODYEAR, PRODMONTH, ACTUAL, SES_FORECAST, HW_FORECAST, SARIMA_FORECAST, IS_FUTURE) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (comp_key, acccode, vpc_location, model_name,
             row['PROD_DATE'].strftime('%Y-%m-%d'),
             int(row['PRODYEAR']), row['PRODMONTH'],
             int(row['VEHICLECOUNT']), ses_val, bsts_val, sar_val, 'N'))

    # Future rows
    last_reliable_row = key_ts[key_ts['TIME_ID'] == ee]
    if len(last_reliable_row) > 0:
        future_start = last_reliable_row.iloc[0]['PROD_DATE'] + pd.DateOffset(months=1)
    else:
        future_start = last_date + pd.DateOffset(months=1)
    future_dates = pd.date_range(start=future_start, periods=FORECAST_HORIZON, freq='MS')

    for i, fdate in enumerate(future_dates):
        ses_val = clamp(res['SES_FUTURE'][i]) if 'SES_FUTURE' in res and i < len(res.get('SES_FUTURE', [])) else None
        bsts_val = clamp(res['BSTS_FUTURE'][i]) if 'BSTS_FUTURE' in res and i < len(res.get('BSTS_FUTURE', [])) else None
        sar_val = clamp(res['SARIMA_FUTURE'][i]) if 'SARIMA_FUTURE' in res and i < len(res.get('SARIMA_FUTURE', [])) else None
        cursor.execute(
            "INSERT INTO COMPOSITE_FORECAST_RESULTS (COMPOSITE_KEY, ACCCODE, VPC_LOCATION, MODEL, PROD_DATE, PRODYEAR, PRODMONTH, ACTUAL, SES_FORECAST, HW_FORECAST, SARIMA_FORECAST, IS_FUTURE) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (comp_key, acccode, vpc_location, model_name,
             fdate.strftime('%Y-%m-%d'),
             fdate.year, str(fdate.month).zfill(2),
             None, ses_val, bsts_val, sar_val, 'Y'))

print(f"  Inserted forecast results for {len(all_results)} composite keys")

# ── Store model accuracy comparison ──────────────────────────
try:
    cursor.execute('TRUNCATE TABLE COMPOSITE_MODEL_COMPARISON')
except:
    cursor.execute("""
        CREATE COLUMN TABLE COMPOSITE_MODEL_COMPARISON (
            COMPOSITE_KEY    NVARCHAR(50)  NOT NULL,
            ACCCODE          NVARCHAR(10)  NOT NULL,
            VPC_LOCATION     INTEGER       NOT NULL,
            MODEL            NVARCHAR(20)  NOT NULL,
            MODEL_NAME       NVARCHAR(30)  NOT NULL,
            MAPE             DOUBLE,
            RMSE             DOUBLE,
            TOTAL_VOLUME     INTEGER,
            DATA_POINTS      INTEGER,
            BEST_MODEL       NVARCHAR(1)   DEFAULT 'N',
            PRIMARY KEY (COMPOSITE_KEY, MODEL_NAME)
        )
    """)

def safe_val(v):
    if v is None or v == float('inf') or (isinstance(v, float) and np.isnan(v)):
        return None
    return v

for comp in all_comparisons:
    for m_name, mape_key, rmse_key in [
        ('SES', 'SES_MAPE', 'SES_RMSE'),
        ('SARIMA', 'SARIMA_MAPE', 'SARIMA_RMSE'),
        ('BSTS', 'BSTS_MAPE', 'BSTS_RMSE'),
    ]:
        mape_val = safe_val(comp[mape_key])
        rmse_val = safe_val(comp[rmse_key])
        is_best = 'Y' if comp['BEST_MODEL'] == m_name else 'N'
        cursor.execute(
            "INSERT INTO COMPOSITE_MODEL_COMPARISON VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (comp['COMPOSITE_KEY'], comp['ACCCODE'], comp['VPC_LOCATION'],
             comp['MODEL'], m_name, mape_val, rmse_val,
             comp['TOTAL_VOLUME'], comp['DATA_POINTS'], is_best))

print(f"  Inserted model comparisons for {len(all_comparisons)} composite keys")

# ── Done ──
conn.close()
print(f"\nDone. Processed {len(composite_keys)} composite keys with 3 models (SES, SARIMA, BSTS).")
