# Composite Forecast Training API — Service Documentation

**App URL:** `https://daimler-ag---cpea-tst-mbusa-voisv-swt-devspace-sapai-pl-app.cfapps.us10.hana.ondemand.com`

---

## Overview

The Composite Forecast API provides the same model training and fine-tuning capabilities as the ACCCODE API, but at a more granular level. Instead of forecasting a single accessory code across all vehicles and locations, composite forecasts operate on a **three-part key**:

```
ACCCODE | VPC_LOCATION | MODEL
```

For example, `D49|52|GLE450W4` forecasts accessory D49 specifically for VPC location 52 and vehicle model GLE450W4.

### Composite vs ACCCODE

| Aspect | ACCCODE API | Composite API |
|--------|------------|---------------|
| **Granularity** | Single ACCCODE (all vehicles/locations) | ACCCODE + VPC + Vehicle Model |
| **Key format** | Simple string: `D49` | Pipe-delimited: `D49\|52\|GLE450W4` |
| **URL pattern** | `/api/retrain/acccode/D49` | `/api/retrain/composite/D49\|52\|GLE450W4` |
| **Data source** | `ACCCODE_TIMESERIES` | `COMPOSITE_TIMESERIES` |
| **Use case** | Broad planning across all channels | Location- and model-specific demand |

### API Endpoints

| # | Method | Endpoint | Purpose |
|---|--------|----------|---------|
| 1 | GET | `/api/models` | List all models & default parameters (shared) |
| 2 | GET | `/api/composite/search?q=<term>` | Search composite keys |
| 3 | GET | `/api/models/composite/<KEY>` | Stored model comparison for a composite key |
| 4 | POST | `/api/retrain/composite/<KEY>` | Re-train with custom parameters |

---

## API Endpoints

### 1. `GET /api/models` — List All Models & Default Parameters

Shared with the ACCCODE API. Returns parameter catalog for SES, SARIMA, BSTS.

```
GET /api/models
```

*(See [Forecast_Model_Training_API.md](Forecast_Model_Training_API.md) for full response.)*

---

### 2. `GET /api/composite/search?q=<term>` — Search Composite Keys

Find composite keys by partial match on ACCCODE, VPC location, or vehicle model.

**Request:**
```
GET /api/composite/search?q=D49
GET /api/composite/search?q=GLE450
GET /api/composite/search?q=52
```

**Response:**
```json
[
  {
    "composite_key": "D49|52|GLE450W4",
    "acccode": "D49",
    "vpc_location": 52,
    "model": "GLE450W4"
  },
  {
    "composite_key": "D49|52|GLE350W4",
    "acccode": "D49",
    "vpc_location": 52,
    "model": "GLE350W4"
  }
]
```

---

### 3. `GET /api/models/composite/<KEY>` — Model Comparison for a Composite Key

Returns stored accuracy metrics from the last batch training run.

**Request:**
```
GET /api/models/composite/D49|52|GLE450W4
```

**Response:**
```json
{
  "composite_key": "D49|52|GLE450W4",
  "acccode": "D49",
  "vpc_location": "52",
  "model": "GLE450W4",
  "models": [
    {"model": "BSTS",   "mape": 9.12, "rmse": 3.8, "total_volume": 420, "data_points": 28, "is_best": true},
    {"model": "SARIMA", "mape": 14.3, "rmse": 5.1, "total_volume": 420, "data_points": 28, "is_best": false},
    {"model": "SES",    "mape": 18.7, "rmse": 6.4, "total_volume": 420, "data_points": 28, "is_best": false}
  ]
}
```

---

### 4. `POST /api/retrain/composite/<KEY>` — Re-train with Custom Parameters

**This is the fine-tuning endpoint.** Runs SES/SARIMA/BSTS models in real-time on HANA Cloud for any composite key, with custom parameter overrides. Identical parameter schema to the ACCCODE retrain endpoint.

**Request:**
```
POST /api/retrain/composite/D49|52|GLE450W4
Content-Type: application/json

{
  "models": ["SARIMA", "BSTS"],
  "FORECAST_HORIZON": 12,
  "TEST_MONTHS": 3,
  "SEASONAL_PERIOD": 12,
  "SARIMA": {
    "METHOD": 1,
    "THREAD_RATIO": 1.0,
    "MAX_P": 5,
    "MAX_Q": 5
  },
  "BSTS": {
    "burn": 0.5,
    "niter": 3000,
    "seed": 42,
    "local_linear_trend": true,
    "damped": false
  }
}
```

**All fields are optional.** Omitted values use defaults.

**Response:**
```json
{
  "composite_key": "D49|52|GLE450W4",
  "acccode": "D49",
  "vpc_location": "52",
  "model": "GLE450W4",
  "train_cutoff": 25,
  "test_months": 3,
  "effective_end": 28,
  "forecast_horizon": 12,
  "params_used": {
    "SARIMA": {
      "SEASONAL_PERIOD": 12,
      "METHOD": 1,
      "THREAD_RATIO": 1.0,
      "FORECAST_LENGTH": 15,
      "FORECAST_METHOD": 1,
      "MAX_P": 5,
      "MAX_Q": 5
    },
    "BSTS": {
      "burn": 0.5,
      "niter": 3000,
      "seasonal_period": 12,
      "seed": 42,
      "local_linear_trend": true,
      "damped": false
    }
  },
  "seasonal_indices": {
    "01": 1.0523,
    "02": 0.9812,
    "12": 0.7341
  },
  "test_actual": [15, 12, 8],
  "models": {
    "SARIMA": {
      "mape": 14.5,
      "rmse": 5.2,
      "test_forecast": [16.2, 11.1, 7.6],
      "future_forecast": [14.0, 13.5, 12.2]
    },
    "BSTS": {
      "mape": 8.8,
      "rmse": 3.1,
      "test_forecast": [14.5, 11.8, 8.4],
      "future_forecast": [13.5, 13.0, 11.8]
    }
  },
  "best_model": "BSTS"
}
```

---

## Composite Key Format

The composite key is a pipe-delimited string with three parts:

```
<ACCCODE>|<VPC_LOCATION>|<VEHICLE_MODEL>
```

| Part | Example | Description |
|------|---------|-------------|
| ACCCODE | `D49` | Accessory code |
| VPC_LOCATION | `52` | Vehicle Preparation Center / warehouse location |
| VEHICLE_MODEL | `GLE450W4` | Specific vehicle model variant |

### URL Encoding

The pipe character (`|`) is valid in URL paths — no encoding needed. Flask uses `<path:key>` to capture the full key including pipes.

### Available ACCCODEs in Composite Data

The composite dataset includes 9 ACCCODEs: D07, D10, D11, D26, D43, D45, D49, D53, D56

### Available Vehicle Models

19 models: C300W, C300W4, E350W, E350W4, E450S4, GLE350W, GLE350W4, GLE450C4, GLE450E4, GLE450W4, GLE53C4, GLE53W4, GLE580W4, GLE63C4S, GLE63W4S, GLS450W4, GLS580W4, GLS600Z4, GLS63W4

---

## Parameter Reference

All parameters are identical to the ACCCODE API. See [Forecast_Model_Training_API.md](Forecast_Model_Training_API.md) for the complete parameter matrix.

### Quick Reference

| Model | Key Parameters | SQL Procedure |
|-------|---------------|---------------|
| **SES** | `ALPHA` (0.0–1.0) | `CALL _SYS_AFL.PAL_BROWN_EXPSMOOTH(...)` |
| **SARIMA** | `METHOD` (0/1/2), `MAX_P`, `MAX_Q` | `CALL _SYS_AFL.PAL_AUTOARIMA(...)` → `CALL _SYS_AFL.PAL_ARIMA_FORECAST(...)` |
| **BSTS** | `niter`, `burn`, `local_linear_trend`, `damped` | `BSTS(...).fit().predict()` via hana_ml |

### Composite-Specific Considerations

- **Smaller data volumes** — Composite keys typically have 15–35 data points vs 30–50 for ACCCODE. Consider:
  - `SEASONAL_PERIOD: 6` (semi-annual) if fewer than 18 months
  - `SARIMA: {"MAX_P": 2, "MAX_Q": 2}` to prevent overfitting
  - `BSTS: {"niter": 3000}` for more stable estimates on small samples
- **Location/model patterns** — Some VPC+Model combos have strong seasonal patterns that differ from the ACCCODE-level aggregate
- **Sparse series** — Some composite keys may have months with zero volume. The pipeline fills gaps and applies outlier detection before training.

---

## Architecture Notes

- The retrain endpoint reads from `COMPOSITE_TIMESERIES` (not `ACCCODE_TIMESERIES`)
- Like the ACCCODE API, retraining is **read-only** — uses temporary tables, never writes to `COMPOSITE_FORECAST_RESULTS` or `COMPOSITE_MODEL_COMPARISON`
- To persist new results, use the batch script `04c_composite_forecast_models.py`
- Seasonal post-adjustment uses per-composite-key monthly indices (not the ACCCODE-level indices)
- The composite data pipeline (`03c_prepare_composite_timeseries.py`) applies IQR outlier detection and ramp-up trimming before training

---

## Database Tables

| Table | Purpose |
|-------|---------|
| `COMPOSITE_TIMESERIES` | Monthly time series per composite key (training input) |
| `COMPOSITE_FORECAST_RESULTS` | Stored forecasts: SES, SARIMA, BSTS per composite key |
| `COMPOSITE_MODEL_COMPARISON` | Accuracy metrics (MAPE, RMSE) and best model flag |
| `PAL_COMPOSITE_TRAINING` | PAL-formatted training subset |

---

## cURL Examples

```bash
# Base URL
BASE="https://daimler-ag---cpea-tst-mbusa-voisv-swt-devspace-sapai-pl-app.cfapps.us10.hana.ondemand.com"

# Search for composite keys containing "D49"
curl "$BASE/api/composite/search?q=D49"

# Search for GLE models
curl "$BASE/api/composite/search?q=GLE450"

# Check stored model comparison for a composite key
curl "$BASE/api/models/composite/D49|52|GLE450W4"

# Retrain all 3 models with defaults
curl -X POST "$BASE/api/retrain/composite/D49|52|GLE450W4" \
  -H "Content-Type: application/json" \
  -d '{}'

# Retrain with BSTS only, more iterations (small series needs more MCMC)
curl -X POST "$BASE/api/retrain/composite/D49|52|GLE450W4" \
  -H "Content-Type: application/json" \
  -d '{"models": ["BSTS"], "BSTS": {"niter": 4000, "burn": 0.3}}'

# Retrain with constrained SARIMA (prevent overfitting on short series)
curl -X POST "$BASE/api/retrain/composite/D07|52|GLS580W4" \
  -H "Content-Type: application/json" \
  -d '{"models": ["SARIMA"], "SARIMA": {"METHOD": 2, "MAX_P": 2, "MAX_Q": 2}}'

# Retrain with half-year seasonality (for keys with <18 months)
curl -X POST "$BASE/api/retrain/composite/D49|52|GLE350W4" \
  -H "Content-Type: application/json" \
  -d '{"SEASONAL_PERIOD": 6, "models": ["SARIMA", "BSTS"]}'

# BSTS level-only (no trend) for flat demand composite
curl -X POST "$BASE/api/retrain/composite/D49|52|GLE53C4" \
  -H "Content-Type: application/json" \
  -d '{"models": ["BSTS"], "BSTS": {"local_linear_trend": false, "niter": 3000}}'
```
