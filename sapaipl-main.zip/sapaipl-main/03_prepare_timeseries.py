"""
============================================================================
STEP 03: PREPARE PER-ACCCODE TIME SERIES DATA (HDI Container)
============================================================================

WHAT THIS DOES:
  1. Aggregates raw data into monthly totals PER ACCCODE
  2. Fills missing months with 0 (important for time series continuity)
  3. Assigns sequential TIME_ID per ACCCODE
  4. Stores results in ACCCODE_TIMESERIES table in HANA
  5. Creates PAL_ACCCODE_TRAINING table (training subset for model fitting)

HDI CONTEXT:
  Tables ACCCODE_TIMESERIES and PAL_ACCCODE_TRAINING are created by the
  HDI deployer from .hdbtable artifacts in db/src/. This script only
  performs DML operations (TRUNCATE + INSERT) — it does NOT drop/create
  tables, which are managed by the HDI container.

WHY PER-ACCCODE:
  The business question is: "How many of accessory D07 do we need in
  July 2026? How many D49?" — NOT just total vehicles.

  Each ACCCODE has its own seasonal pattern. D49 might peak in March
  while D07 peaks in June. Forecasting them separately captures this.

CONCEPT — TIME SERIES REQUIREMENTS:
  - Regular intervals (every month, no gaps)
  - Sufficient history (12+ months for seasonal detection)
  - Single value per time point per series

RUN:
  python 03_prepare_timeseries.py

PREREQUISITES:
  pip install hana-ml pandas python-dotenv
============================================================================
"""

import os, json
from dotenv import load_dotenv
load_dotenv()
import pandas as pd
import numpy as np
from hana_ml.dataframe import ConnectionContext


def _hana_creds():
    if os.environ.get('HANA_HOST'):
        return {
            'host': os.environ['HANA_HOST'],
            'port': int(os.environ['HANA_PORT']),
            'user': os.environ['HANA_USER'],
            'password': os.environ['HANA_PASSWORD'],
            'schema': os.environ.get('HANA_SCHEMA', ''),
        }
    vcap = os.environ.get('VCAP_SERVICES')
    if vcap:
        svc = json.loads(vcap)
        hana = svc.get('hana', [{}])[0].get('credentials', {})
        return {
            'host': hana['host'],
            'port': int(hana['port']),
            'user': hana['user'],
            'password': hana['password'],
            'schema': hana.get('schema', ''),
        }
    raise RuntimeError('No HANA credentials found')


# ─── Connect ───
print("Connecting to HANA Cloud...")
creds = _hana_creds()
conn = ConnectionContext(
    address=creds['host'],
    port=creds['port'],
    user=creds['user'],
    password=creds['password'],
    encrypt=True
)
cursor = conn.connection.cursor()
if creds['schema']:
    cursor.execute('SET SCHEMA "{}"'.format(creds['schema'].replace('"', '""')))
print(f"Connected. Schema: {creds['schema'] or 'default'}\n")

# ─── Load raw data ───
df = conn.table('ACCESSORY_FORECAST').collect()
print(f"Raw data: {len(df):,} rows")

# ── Drop future data: only keep up to Feb 2026 ──
df['PRODMONTH'] = df['PRODMONTH'].astype(str).str.zfill(2)
df['PRODYEAR'] = df['PRODYEAR'].astype(int)
before = len(df)
df = df[~((df['PRODYEAR'] == 2026) & (df['PRODMONTH'] >= '03'))].copy()
df = df[df['PRODYEAR'] <= 2026].copy()
print(f"After dropping 2026-Mar+ data: {len(df):,} rows (removed {before - len(df):,})\n")

# ═══════════════════════════════════════════════════════════════════
# STEP 3A: AGGREGATE BY ACCCODE + MONTH
# ═══════════════════════════════════════════════════════════════════
print("═" * 65)
print("  Step 3A: Aggregate by ACCCODE + Month")
print("═" * 65)

monthly = (
    df.groupby(['ACCCODE', 'PRODYEAR', 'PRODMONTH'])
    ['VEHICLECOUNT'].sum()
    .reset_index()
)
monthly['PRODMONTH'] = monthly['PRODMONTH'].str.zfill(2)
print(f"  Aggregated to {len(monthly):,} ACCCODE-month combinations")

# ═══════════════════════════════════════════════════════════════════
# STEP 3B: BUILD COMPLETE MONTHLY GRID (fill gaps with 0)
# ═══════════════════════════════════════════════════════════════════
print(f"\n{'═' * 65}")
print("  Step 3B: Fill missing months with zero")
print("═" * 65)
print("""
  WHY: Time series models need CONTINUOUS data — no gaps.
  If ACCCODE D07 has no vehicles in Aug 2024, we still need
  a row with VEHICLECOUNT=0 for that month. Otherwise the
  model misinterprets the time sequence.
""")

# Determine full date range from data
all_periods = sorted(monthly[['PRODYEAR', 'PRODMONTH']].drop_duplicates().values.tolist())
all_acccodes = sorted(monthly['ACCCODE'].unique())

# Filter: only ACCCODEs with 12+ months of non-zero data
acc_months = monthly.groupby('ACCCODE')['PRODYEAR'].count()
forecastable_codes = acc_months[acc_months >= 12].index.tolist()
print(f"  Total ACCCODEs: {len(all_acccodes)}")
print(f"  Forecastable (12+ months of data): {len(forecastable_codes)}")
print(f"  Excluded (< 12 months): {len(all_acccodes) - len(forecastable_codes)}")

# Build complete grid for forecastable ACCCODEs
rows = []
for acccode in forecastable_codes:
    acc_data = monthly[monthly['ACCCODE'] == acccode]
    time_id = 0
    for year, month in all_periods:
        time_id += 1
        match = acc_data[(acc_data['PRODYEAR'] == year) & (acc_data['PRODMONTH'] == month)]
        count = int(match['VEHICLECOUNT'].sum()) if len(match) > 0 else 0
        prod_date = f"{year}-{month}-01"
        rows.append({
            'ACCCODE': acccode,
            'TIME_ID': time_id,
            'PROD_DATE': prod_date,
            'PRODYEAR': year,
            'PRODMONTH': month,
            'VEHICLECOUNT': count
        })

ts_df = pd.DataFrame(rows)
print(f"\n  Complete time series grid: {len(ts_df):,} rows")
print(f"  ({len(forecastable_codes)} ACCCODEs × {len(all_periods)} months)")

# ═══════════════════════════════════════════════════════════════════
# STEP 3B2: OUTLIER DETECTION & CORRECTION (PAL)
# ═══════════════════════════════════════════════════════════════════
print(f"\n{'═' * 65}")
print("  Step 3B2: Outlier Detection (PAL_OUTLIER_DETECTION_FOR_TIME_SERIES)")
print("═" * 65)
print("""
  WHY: Spikes/dips in historical data distort forecasts.
  PAL AUTO=1 mode automatically selects the best detection method.
  Outlier values are replaced with the model's fitted value.
""")

def drop_temp(name):
    try:
        cursor.execute(f"DROP TABLE {name}")
    except:
        pass

def sql_exec(stmt):
    cursor.execute(stmt)
    if stmt.strip().upper().startswith('SELECT') or stmt.strip().upper().startswith('CALL'):
        try:
            return cursor.fetchall()
        except:
            return []
    return []

total_outliers = 0
corrected_codes = 0

for acccode in forecastable_codes:
    acc_mask = ts_df['ACCCODE'] == acccode
    acc_data = ts_df[acc_mask].sort_values('TIME_ID')

    try:
        # Upload series to temp table
        drop_temp('#OD_INPUT')
        sql_exec("CREATE LOCAL TEMPORARY COLUMN TABLE #OD_INPUT (TIME_STAMP INT, VALUE DOUBLE)")
        for _, r in acc_data.iterrows():
            cursor.execute("INSERT INTO #OD_INPUT VALUES (?, ?)",
                           (int(r['TIME_ID']), float(r['VEHICLECOUNT'])))

        # Parameters: AUTO=1 (auto-select method), RESIDUAL_USAGE=1
        drop_temp('#OD_PARAM')
        sql_exec("CREATE LOCAL TEMPORARY COLUMN TABLE #OD_PARAM "
                 "(PARAM_NAME NVARCHAR(256), INT_VALUE INT, DOUBLE_VALUE DOUBLE, STRING_VALUE NVARCHAR(256))")
        cursor.execute("INSERT INTO #OD_PARAM VALUES (?, ?, NULL, NULL)", ('AUTO', 1))
        cursor.execute("INSERT INTO #OD_PARAM VALUES (?, ?, NULL, NULL)", ('RESIDUAL_USAGE', 1))

        # Output tables
        drop_temp('#OD_OUT')
        drop_temp('#OD_STATS')
        sql_exec("CREATE LOCAL TEMPORARY COLUMN TABLE #OD_OUT "
                 "(TIME_STAMP INT, RAW_DATA DOUBLE, RESIDUAL DOUBLE, OUTLIER_SCORE DOUBLE, IS_OUTLIER INT)")
        sql_exec("CREATE LOCAL TEMPORARY COLUMN TABLE #OD_STATS "
                 "(STAT_NAME NVARCHAR(256), STAT_VALUE NVARCHAR(256))")

        sql_exec("CALL _SYS_AFL.PAL_OUTLIER_DETECTION_FOR_TIME_SERIES("
                 "#OD_INPUT, #OD_PARAM, #OD_OUT, #OD_STATS)")

        cursor.execute("SELECT TIME_STAMP, RAW_DATA, RESIDUAL, IS_OUTLIER FROM #OD_OUT WHERE IS_OUTLIER = 1")
        outlier_rows = cursor.fetchall()

        if outlier_rows:
            corrected_codes += 1
            for orow in outlier_rows:
                tid = int(orow[0])
                raw_val = float(orow[1])
                residual = float(orow[2])
                fitted_val = max(0, int(round(raw_val - residual)))
                # Replace outlier in ts_df
                idx = ts_df[(ts_df['ACCCODE'] == acccode) & (ts_df['TIME_ID'] == tid)].index
                if len(idx) > 0:
                    ts_df.loc[idx[0], 'VEHICLECOUNT'] = fitted_val
                    total_outliers += 1

    except Exception as e:
        pass  # Outlier detection failed for this ACCCODE — keep original data

    # Clean up
    for t in ['#OD_INPUT', '#OD_PARAM', '#OD_OUT', '#OD_STATS']:
        drop_temp(t)

print(f"  Outliers detected and corrected: {total_outliers}")
print(f"  ACCCODEs with corrections: {corrected_codes} / {len(forecastable_codes)}")

VALIDATION_CODES = ['D10', 'D11', 'D43', 'D45', 'D56', 'D53', 'D26', 'D07']

# ═══════════════════════════════════════════════════════════════════
# STEP 3B2b: DROP LEADING ZERO MONTHS
# ═══════════════════════════════════════════════════════════════════
print(f"\n{'═' * 65}")
print("  Step 3B2b: Drop Leading Zero Months")
print("═" * 65)
print("""
  WHY: Many ACCCODEs have months of zero production at the start
  (before the accessory existed). These are not real data points —
  keeping them or interpolating them distorts the model. Simply
  drop them and re-assign sequential TIME_IDs.
""")

leading_zeros_dropped = 0
codes_with_leading_zeros = 0

for acccode in forecastable_codes:
    acc_mask = ts_df['ACCCODE'] == acccode
    acc_data = ts_df[acc_mask].sort_values('TIME_ID')
    vals = acc_data['VEHICLECOUNT'].values

    # Count leading zeros
    n_leading = 0
    for v in vals:
        if v == 0:
            n_leading += 1
        else:
            break

    if n_leading > 0:
        # Drop leading zero rows
        drop_indices = acc_data.iloc[:n_leading].index
        ts_df = ts_df.drop(drop_indices)

        # Re-assign sequential TIME_IDs
        remaining = ts_df[ts_df['ACCCODE'] == acccode].sort_values('TIME_ID').index
        for new_tid, idx in enumerate(remaining, start=1):
            ts_df.loc[idx, 'TIME_ID'] = new_tid

        leading_zeros_dropped += n_leading
        codes_with_leading_zeros += 1
        if acccode in VALIDATION_CODES:
            print(f"  {acccode}: dropped {n_leading} leading zero months")

print(f"\n  Leading zeros dropped: {leading_zeros_dropped} months across {codes_with_leading_zeros} ACCCODEs")

# ═══════════════════════════════════════════════════════════════════
# STEP 3B3: EARLY-PERIOD TRIMMING (Ramp-up Removal)
#   Run BEFORE IQR so zeros are still visible for ramp-up detection
# ═══════════════════════════════════════════════════════════════════
print(f"\n{'═' * 65}")
print("  Step 3B3: Early-Period Trimming (Ramp-up Removal)")
print("═" * 65)
print("""
  WHY: Initial months of an accessory's life may have abnormally
  low production (ramp-up). Including these distorts trend estimation.
  Months where 3-month rolling average is < 20% of series average
  are trimmed from the start of each series.
  Runs BEFORE IQR so original zeros are visible for detection.
""")

trimmed_codes = 0
total_months_trimmed = 0

for acccode in forecastable_codes:
    acc_mask = ts_df['ACCCODE'] == acccode
    acc_data = ts_df[acc_mask].sort_values('TIME_ID')
    nonzero_vals = acc_data[acc_data['VEHICLECOUNT'] > 0]['VEHICLECOUNT']

    if len(nonzero_vals) < 6:
        continue  # Not enough data to detect ramp-up

    series_avg = nonzero_vals.mean()
    threshold = series_avg * 0.20
    vals = acc_data['VEHICLECOUNT'].values

    # Find first index where 3-month rolling avg exceeds threshold
    trim_to = 0
    for i in range(len(vals) - 2):
        rolling_avg = np.mean(vals[i:i+3])
        if rolling_avg >= threshold:
            trim_to = i
            break
    else:
        trim_to = 0

    if trim_to > 0:
        # Drop the ramp-up rows from ts_df
        trim_indices = acc_data.iloc[:trim_to].index
        ts_df = ts_df.drop(trim_indices)

        # Re-assign sequential TIME_IDs for this ACCCODE
        remaining = ts_df[ts_df['ACCCODE'] == acccode].sort_values('TIME_ID').index
        for new_tid, idx in enumerate(remaining, start=1):
            ts_df.loc[idx, 'TIME_ID'] = new_tid

        trimmed_codes += 1
        total_months_trimmed += trim_to
        if acccode in VALIDATION_CODES:
            print(f"  {acccode}: trimmed first {trim_to} months "
                  f"(rolling avg < {threshold:.0f}, series avg: {series_avg:.0f})")

print(f"\n  ACCCODEs trimmed: {trimmed_codes} / {len(forecastable_codes)}")
print(f"  Total months trimmed: {total_months_trimmed}")

# ═══════════════════════════════════════════════════════════════════
# STEP 3B4: IQR-BASED OUTLIER DETECTION & SEASONAL INTERPOLATION
#   Only applied to TRAINING months (excludes last 5 per ACCCODE)
#   so test-period actuals are preserved for validation
# ═══════════════════════════════════════════════════════════════════
print(f"\n{'═' * 65}")
print("  Step 3B4: IQR Outlier Detection (training months only)")
print("═" * 65)
print("""
  WHY: PAL auto-detection may miss systematic zeros and extreme
  values in high-volume codes. IQR method flags statistical outliers.
  Flagged values are replaced with same-month seasonal averages.
  IMPORTANT: Only applied to training months — test period (last 5
  months per code) is left untouched to preserve actual values.
""")

iqr_total_outliers = 0
iqr_corrected_codes = 0

for acccode in forecastable_codes:
    acc_mask = ts_df['ACCCODE'] == acccode
    acc_data = ts_df[acc_mask].sort_values('TIME_ID').copy()
    max_tid = int(acc_data['TIME_ID'].max())
    # Protect the last 5 months (test period) from replacement
    train_limit = max_tid - 5

    if train_limit < 6:
        continue  # Not enough training data for IQR

    train_data = acc_data[acc_data['TIME_ID'] <= train_limit]
    nonzero_vals = train_data[train_data['VEHICLECOUNT'] > 0]['VEHICLECOUNT']

    if len(nonzero_vals) < 4:
        continue  # Not enough data for IQR

    avg_volume = nonzero_vals.mean()
    q1 = nonzero_vals.quantile(0.25)
    q3 = nonzero_vals.quantile(0.75)
    iqr = q3 - q1
    lower_bound = max(0, q1 - 1.5 * iqr)
    upper_bound = q3 + 1.5 * iqr

    code_outlier_count = 0
    outlier_details = []

    # Only iterate over TRAINING rows (not test period)
    for idx_row in train_data.index:
        row = ts_df.loc[idx_row]
        val = row['VEHICLECOUNT']
        tid = int(row['TIME_ID'])
        month = row['PRODMONTH']
        is_outlier = False

        # Flag zeros in high-volume codes as outliers
        if val == 0 and avg_volume > 50:
            is_outlier = True
        # Flag values outside IQR bounds
        elif val < lower_bound or val > upper_bound:
            is_outlier = True

        if is_outlier:
            # Replace with same-month seasonal average from non-outlier training values
            same_month = train_data[
                (train_data['PRODMONTH'] == month) &
                (train_data['VEHICLECOUNT'] > lower_bound) &
                (train_data['VEHICLECOUNT'] <= upper_bound)
            ]['VEHICLECOUNT']

            if len(same_month) > 0:
                replacement = int(round(same_month.mean()))
            else:
                # Fall back to linear interpolation from neighbors
                neighbors = train_data[
                    (train_data['TIME_ID'] >= tid - 2) &
                    (train_data['TIME_ID'] <= tid + 2) &
                    (train_data['TIME_ID'] != tid) &
                    (train_data['VEHICLECOUNT'] > 0)
                ]['VEHICLECOUNT']
                replacement = int(round(neighbors.mean())) if len(neighbors) > 0 else int(round(avg_volume))

            replacement = max(0, replacement)
            outlier_details.append((tid, month, int(val), replacement))
            ts_df.loc[idx_row, 'VEHICLECOUNT'] = replacement
            code_outlier_count += 1

    if code_outlier_count > 0:
        iqr_total_outliers += code_outlier_count
        iqr_corrected_codes += 1
        if acccode in VALIDATION_CODES:
            print(f"  {acccode}: {code_outlier_count} IQR outliers replaced "
                  f"(bounds: {lower_bound:.0f}–{upper_bound:.0f}, avg: {avg_volume:.0f})")
            for tid, mo, old_val, new_val in outlier_details:
                print(f"    TIME_ID={tid} month={mo}: {old_val:,} → {new_val:,}")

print(f"\n  IQR outliers detected and corrected: {iqr_total_outliers}")
print(f"  ACCCODEs with IQR corrections: {iqr_corrected_codes} / {len(forecastable_codes)}")

# ═══════════════════════════════════════════════════════════════════
# STEP 3B5: DIAGNOSTIC SUMMARY FOR VALIDATION CODES
# ═══════════════════════════════════════════════════════════════════
print(f"\n{'═' * 65}")
print("  Step 3B5: Diagnostic Summary (Validation Codes)")
print("═" * 65)

for acccode in VALIDATION_CODES:
    acc_data = ts_df[ts_df['ACCCODE'] == acccode].sort_values('TIME_ID')
    if len(acc_data) == 0:
        print(f"  {acccode}: NOT FOUND in forecastable codes")
        continue
    total = acc_data['VEHICLECOUNT'].sum()
    avg = acc_data['VEHICLECOUNT'].mean()
    std = acc_data['VEHICLECOUNT'].std()
    mn = acc_data['VEHICLECOUNT'].min()
    mx = acc_data['VEHICLECOUNT'].max()
    n_zero = (acc_data['VEHICLECOUNT'] == 0).sum()
    n_months = len(acc_data)
    print(f"  {acccode}: {n_months} months | total={total:,} avg={avg:,.0f} "
          f"std={std:,.0f} min={mn:,} max={mx:,} zeros={n_zero}")

# ═══════════════════════════════════════════════════════════════════
# STEP 3C: STORE IN HANA
# ═══════════════════════════════════════════════════════════════════
print(f"\n{'═' * 65}")
print("  Step 3C: Store time series in HANA Cloud")
print("═" * 65)

# Truncate ACCCODE_TIMESERIES (table created by HDI deployer)
try:
    cursor.execute('TRUNCATE TABLE ACCCODE_TIMESERIES')
except:
    # Fallback: create if HDI deploy hasn't run
    cursor.execute("""
        CREATE COLUMN TABLE ACCCODE_TIMESERIES (
            ACCCODE        NVARCHAR(10)  NOT NULL,
            TIME_ID        INTEGER       NOT NULL,
            PROD_DATE      DATE          NOT NULL,
            PRODYEAR       INTEGER       NOT NULL,
            PRODMONTH      NVARCHAR(2)   NOT NULL,
            VEHICLECOUNT   INTEGER       NOT NULL,
            PRIMARY KEY (ACCCODE, TIME_ID)
        )
    """)

# Batch insert using parameterized queries
BATCH = 500
for i in range(0, len(ts_df), BATCH):
    batch = ts_df.iloc[i:i+BATCH]
    for r in batch.itertuples():
        cursor.execute(
            "INSERT INTO ACCCODE_TIMESERIES VALUES (?, ?, ?, ?, ?, ?)",
            (r.ACCCODE, int(r.TIME_ID), str(r.PROD_DATE), int(r.PRODYEAR), r.PRODMONTH, int(r.VEHICLECOUNT))
        )

print(f"  Inserted {len(ts_df):,} rows into ACCCODE_TIMESERIES")

# ═══════════════════════════════════════════════════════════════════
# STEP 3D: CREATE TRAINING DATA (exclude last 5 months for testing)
# ═══════════════════════════════════════════════════════════════════
print(f"\n{'═' * 65}")
print("  Step 3D: Create training / test split")
print("═" * 65)

n_periods = len(all_periods)
# Use all months except last 5 for training (Jan-May 2026 are test)
train_cutoff = n_periods - 5
print(f"""
  CONCEPT: Train/Test Split
  ─────────────────────────────────────
  Total months:    {n_periods}
  Training months: {train_cutoff} (months 1-{train_cutoff})
  Test months:     5 (months {train_cutoff+1}-{n_periods})
  
  We train models on historical data, then check if they can
  accurately predict the last 5 months we already know.
  This gives us confidence before predicting unknown future months.
""")

# Truncate PAL_ACCCODE_TRAINING (table created by HDI deployer)
try:
    cursor.execute('TRUNCATE TABLE PAL_ACCCODE_TRAINING')
except:
    # Fallback: create if HDI deploy hasn't run
    cursor.execute("""
        CREATE COLUMN TABLE PAL_ACCCODE_TRAINING (
            ACCCODE        NVARCHAR(10)  NOT NULL,
            TIME_ID        INTEGER       NOT NULL,
            VEHICLECOUNT   DOUBLE        NOT NULL,
            PRIMARY KEY (ACCCODE, TIME_ID)
        )
    """)

cursor.execute(f"""
    INSERT INTO PAL_ACCCODE_TRAINING
    SELECT ACCCODE, TIME_ID, CAST(VEHICLECOUNT AS DOUBLE)
    FROM ACCCODE_TIMESERIES
    WHERE TIME_ID <= {train_cutoff}
""")

train_count = conn.sql('SELECT COUNT(*) AS N FROM PAL_ACCCODE_TRAINING').collect().iloc[0, 0]
print(f"  Training rows (all ACCCODEs combined): {train_count:,}")

# ═══════════════════════════════════════════════════════════════════
# STEP 3E: PREVIEW TIME SERIES FOR TOP ACCCODEs
# ═══════════════════════════════════════════════════════════════════
print(f"\n{'═' * 65}")
print("  Step 3E: Time Series Preview (Top 5 ACCCODEs)")
print("═" * 65)

top_acccodes = (
    ts_df.groupby('ACCCODE')['VEHICLECOUNT'].sum()
    .sort_values(ascending=False)
    .head(5).index.tolist()
)

for acccode in top_acccodes:
    acc_ts = ts_df[ts_df['ACCCODE'] == acccode].sort_values('TIME_ID')
    total = acc_ts['VEHICLECOUNT'].sum()
    avg = acc_ts['VEHICLECOUNT'].mean()
    print(f"\n  ACCCODE: {acccode}  (Total: {total:,}  Avg/month: {avg:,.0f})")
    print(f"  {'Month':<10} {'Count':>8}  {'':>3} {'Pattern'}")
    print(f"  {'─' * 55}")
    max_val = max(acc_ts['VEHICLECOUNT'].max(), 1)
    for _, row in acc_ts.iterrows():
        bar = '█' * max(1, int(row['VEHICLECOUNT'] / max_val * 35))
        marker = ' ◄ TEST' if row['TIME_ID'] > train_cutoff else ''
        print(f"  {row['PROD_DATE'][:7]:<10} {row['VEHICLECOUNT']:>8,}  {bar}{marker}")

print(f"""
{'═' * 65}
  ✓ Step 03 complete.
  
  Tables created:
    ACCCODE_TIMESERIES     — {len(ts_df):,} rows ({len(forecastable_codes)} ACCCODEs × {n_periods} months)
    PAL_ACCCODE_TRAINING   — {train_count:,} rows (training subset)
  
  NEXT STEP:
    Run 04_forecast_models.py to run SES, Holt-Winters, and SARIMA
    on each forecastable ACCCODE.
{'═' * 65}
""")

conn.close()
