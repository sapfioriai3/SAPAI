"""
05_compare_and_predict.py
─────────────────────────
Read-only comparison report.  Queries ACCCODE_FORECAST_RESULTS and
ACCCODE_MODEL_COMPARISON from HANA Cloud, then:

  1. Pivots MAPE per model per ACCCODE to see which model wins
  2. Ranks models overall (win count + average MAPE)
  3. Builds a future-predictions pivot (one row per ACCCODE, cols = months)
  4. Shows test-period forecast vs actual for top 10 ACCCODEs

No data is written back to HANA — this script only reads.

Prerequisites:
  - Steps 00-04 must have been run first
  - pip install hana-ml pandas python-dotenv numpy
"""

import os, json
from dotenv import load_dotenv
load_dotenv()
import pandas as pd
import numpy as np
from hana_ml.dataframe import ConnectionContext


def _hana_creds():
    if os.environ.get('HANA_HOST'):
        return {
            'host': os.environ['HANA_HOST'],
            'port': int(os.environ['HANA_PORT']),
            'user': os.environ['HANA_USER'],
            'password': os.environ['HANA_PASSWORD'],
            'schema': os.environ.get('HANA_SCHEMA', ''),
        }
    vcap = os.environ.get('VCAP_SERVICES')
    if vcap:
        svc = json.loads(vcap)
        hana = svc.get('hana', [{}])[0].get('credentials', {})
        return {
            'host': hana['host'],
            'port': int(hana['port']),
            'user': hana['user'],
            'password': hana['password'],
            'schema': hana.get('schema', ''),
        }
    raise RuntimeError('No HANA credentials found')


# ─── Connect to HANA Cloud ───
creds = _hana_creds()
conn = ConnectionContext(
    address=creds['host'],
    port=creds['port'],
    user=creds['user'],
    password=creds['password'],
    encrypt=True
)
if creds['schema']:
    conn.connection.cursor().execute('SET SCHEMA "{}"'.format(creds['schema'].replace('"', '""')))

# ─── 1. Model accuracy comparison ────────────────────────────────
# Pivot MAPE values: one row per ACCCODE, one column per model.
# Merge in total volume and best-model flag.
comp_df = conn.table('ACCCODE_MODEL_COMPARISON').collect()

pivot = comp_df.pivot(index='ACCCODE', columns='MODEL_NAME', values='MAPE')
pivot = pivot.rename(columns={
    'SES': 'SES_MAPE',
    'Holt-Winters': 'HW_MAPE',
    'SARIMA': 'SARIMA_MAPE',
})

best = comp_df[comp_df['BEST_MODEL'] == 'Y'][['ACCCODE', 'MODEL_NAME', 'TOTAL_VOLUME']].rename(
    columns={'MODEL_NAME': 'BEST'}
)
summary = pivot.merge(best, on='ACCCODE').sort_values('TOTAL_VOLUME', ascending=False)

# ─── 2. Overall model ranking ────────────────────────────────────
# Count how many ACCCODEs each model wins, and compute avg MAPE.
wins = comp_df[comp_df['BEST_MODEL'] == 'Y']['MODEL_NAME'].value_counts()
avg_mape = comp_df.groupby('MODEL_NAME')['MAPE'].mean()

# ─── 3. Future predictions pivot ─────────────────────────────────
# One row per ACCCODE, columns = future months, values = best-model forecast.
forecast_df = conn.table('ACCCODE_FORECAST_RESULTS').collect()
future = forecast_df[forecast_df['IS_FUTURE'] == 'Y'].copy()

best_models = dict(zip(summary['ACCCODE'], summary['BEST']))

if len(future) > 0:
    # Pick the forecast column that belongs to the winning model
    future['BEST_FORECAST'] = future.apply(
        lambda r: (
            r['SES_FORECAST'] if best_models.get(r['ACCCODE']) == 'SES'
            else r['HW_FORECAST'] if best_models.get(r['ACCCODE']) == 'Holt-Winters'
            else r['SARIMA_FORECAST']
        ), axis=1
    )

    future['MONTH_LABEL'] = future['PRODYEAR'].astype(str) + '-' + future['PRODMONTH']
    future_pivot = future.pivot(
        index='ACCCODE', columns='MONTH_LABEL', values='BEST_FORECAST'
    ).fillna(0).astype(int)

    future_pivot['TOTAL'] = future_pivot.sum(axis=1)
    future_pivot = future_pivot.sort_values('TOTAL', ascending=False)

# ─── 4. Test period: forecast vs actual (top 10) ─────────────────
# For the 10 highest-volume ACCCODEs, compare actual vs each model
# during the held-out test period.
test_data = forecast_df[forecast_df['IS_FUTURE'] == 'N'].copy()
top10 = summary.head(10)['ACCCODE'].tolist()

top10_test = {}
for acccode in top10:
    acc_test = test_data[test_data['ACCCODE'] == acccode].sort_values('PROD_DATE')
    if len(acc_test) > 0:
        top10_test[acccode] = acc_test

# ─── Done ────────────────────────────────────────────────────────
conn.close()
