"""
Flask Dashboard for SAP PAL Accessory Forecast
───────────────────────────────────────────────
Simplified 2-page UI:
  /                      → ACCCODE Predictions (landing page)
  /composite_predictions → Composite Predictions (free-text search)
  /acccode/<code>        → ACCCODE detail (Actual vs Forecast chart)
  /composite/<key>       → Composite detail (Actual vs Forecast chart)

Run:  python app.py
"""

import os, json
from dotenv import load_dotenv
load_dotenv()

from flask import Flask, render_template, request, jsonify, redirect, url_for, flash
from hana_ml.dataframe import ConnectionContext
from hana_ml.algorithms.pal.tsa.bsts import BSTS
import pandas as pd
import numpy as np

app = Flask(__name__)
app.secret_key = os.environ.get('FLASK_SECRET', 'sapai-pal-2026')


# ─── HANA credentials (CF VCAP_SERVICES or local .env) ─────────
def _hana_creds():
    if os.environ.get('HANA_HOST'):
        return {
            'host': os.environ['HANA_HOST'],
            'port': int(os.environ['HANA_PORT']),
            'user': os.environ['HANA_USER'],
            'password': os.environ['HANA_PASSWORD'],
            'schema': os.environ.get('HANA_SCHEMA', ''),
        }
    vcap = os.environ.get('VCAP_SERVICES')
    if vcap:
        svc = json.loads(vcap)
        hana = svc.get('hana', [{}])[0].get('credentials', {})
        return {
            'host': hana['host'],
            'port': int(hana['port']),
            'user': hana['user'],
            'password': hana['password'],
            'schema': hana.get('schema', ''),
        }
    raise RuntimeError('No HANA credentials found')


# ─── Template helpers ───────────────────────────────────────────
@app.template_global()
def fmt_mape(v):
    if v is None:
        return 'N/A'
    return f'{v:.1f}%'

@app.template_global()
def mape_class(v):
    if v is None:
        return ''
    if v < 5:
        return 'mape-excellent'
    if v < 10:
        return 'mape-good'
    if v < 20:
        return 'mape-ok'
    return 'mape-poor'


# ─── HANA Connection ────────────────────────────────────────────
def get_conn():
    creds = _hana_creds()
    return ConnectionContext(
        address=creds['host'],
        port=creds['port'],
        user=creds['user'],
        password=creds['password'],
        encrypt=True
    )

def query(sql, params=None):
    conn = get_conn()
    cursor = conn.connection.cursor()
    schema = _hana_creds()['schema']
    if schema:
        cursor.execute('SET SCHEMA "{}"'.format(schema.replace('"', '""')))
    if params:
        cursor.execute(sql, params)
    else:
        cursor.execute(sql)
    cols = [d[0] for d in cursor.description]
    rows = cursor.fetchall()
    conn.close()
    return pd.DataFrame(rows, columns=cols)


def _best_forecast_col(best_model):
    """Return the DB column name for the best model's forecast."""
    mapping = {
        'SES': 'SES_FORECAST',
        'SARIMA': 'SARIMA_FORECAST',
        'BSTS': 'HW_FORECAST',
    }
    return mapping.get(best_model, 'SES_FORECAST')


def _compute_extra_metrics(actual_list, forecast_list):
    """Compute WMAPE, SMAPE, MAD from actual vs forecast lists."""
    import numpy as _np
    pairs = [(float(a), float(f)) for a, f in zip(actual_list, forecast_list)
             if pd.notnull(a) and pd.notnull(f)]
    if not pairs:
        return None, None, None
    a = _np.array([p[0] for p in pairs])
    f = _np.array([p[1] for p in pairs])
    n = len(a)
    # WMAPE (time-weighted)
    mask = a > 0
    if mask.sum() > 0:
        w = _np.array([2.0 ** (i / n) for i in range(n)])[mask]
        w = w / w.sum()
        wmape = float(_np.sum(w * _np.abs((a[mask] - f[mask]) / a[mask])) * 100)
    else:
        wmape = None
    # SMAPE
    denom = _np.abs(a) + _np.abs(f)
    smask = denom > 0
    smape = float(_np.mean(2.0 * _np.abs(a[smask] - f[smask]) / denom[smask]) * 100) if smask.sum() > 0 else None
    # MAD
    mad = float(_np.mean(_np.abs(a - f)))
    return wmape, smape, mad


# ─── Routes ─────────────────────────────────────────────────────

@app.route('/')
def predictions_page():
    """Landing page: ACCCODE predictions — search by ACCCODE and/or month."""
    acccode_filter = request.args.get('acccode', '').strip().upper()
    month_filter = request.args.get('month', '').strip()

    where = "WHERE fr.IS_FUTURE = 'Y'"
    params = []
    if acccode_filter:
        where += " AND UPPER(fr.ACCCODE) LIKE ?"
        params.append(f'%{acccode_filter}%')
    if month_filter:
        where += " AND TO_VARCHAR(fr.PROD_DATE, 'YYYY-MM') = ?"
        params.append(month_filter)

    future = query(f"""
        SELECT fr.ACCCODE, fr.PROD_DATE,
               fr.SES_FORECAST, fr.HW_FORECAST, fr.SARIMA_FORECAST,
               mc.MODEL_NAME AS BEST_MODEL_NAME
        FROM ACCCODE_FORECAST_RESULTS fr
        JOIN ACCCODE_MODEL_COMPARISON mc
          ON fr.ACCCODE = mc.ACCCODE AND mc.BEST_MODEL = 'Y'
        {where}
        ORDER BY fr.ACCCODE, fr.PROD_DATE
    """, tuple(params) if params else None)

    summaries = []
    if not future.empty:
        best_col_map = {
            'SES': 'SES_FORECAST',
            'SARIMA': 'SARIMA_FORECAST',
            'BSTS': 'HW_FORECAST',
        }
        for acc in future['ACCCODE'].unique():
            sub = future[future['ACCCODE'] == acc]
            best = sub['BEST_MODEL_NAME'].iloc[0]
            col = best_col_map.get(best, 'SES_FORECAST')

            months = []
            for _, r in sub.iterrows():
                fdate = str(r['PROD_DATE'])[:7]
                val = int(r[col]) if col in r and pd.notnull(r.get(col)) else None
                if val is not None:
                    val = max(0, val)
                months.append({'date': fdate, 'predicted': val})

            total = sum(m['predicted'] or 0 for m in months)
            summaries.append({
                'acccode': acc,
                'total': total,
                'months': months,
            })
        summaries.sort(key=lambda x: x['total'], reverse=True)

    # Month options for dropdown
    all_months = query("""
        SELECT DISTINCT TO_VARCHAR(PROD_DATE, 'YYYY-MM') AS MONTH
        FROM ACCCODE_FORECAST_RESULTS WHERE IS_FUTURE = 'Y'
        ORDER BY MONTH
    """)
    month_options = all_months['MONTH'].tolist() if not all_months.empty else []

    return render_template('predictions.html',
        summaries=summaries, acccode_filter=acccode_filter,
        month_filter=month_filter, month_options=month_options)


@app.route('/acccode/<code>')
def acccode_detail(code):
    """Detail: Actual vs Forecast chart + future predictions table."""
    history = query("""
        SELECT TIME_ID, PROD_DATE, PRODYEAR, PRODMONTH, VEHICLECOUNT
        FROM ACCCODE_TIMESERIES
        WHERE ACCCODE = ?
        ORDER BY TIME_ID
    """, (code,))

    if history.empty:
        flash(f'No data found for ACCCODE: {code}', 'error')
        return redirect(url_for('predictions_page'))

    forecasts = query("""
        SELECT PROD_DATE, PRODYEAR, PRODMONTH, ACTUAL,
               SES_FORECAST, HW_FORECAST, SARIMA_FORECAST, IS_FUTURE
        FROM ACCCODE_FORECAST_RESULTS
        WHERE ACCCODE = ?
        ORDER BY PROD_DATE
    """, (code,))

    comparison = query("""
        SELECT MODEL_NAME, MAPE, RMSE, TOTAL_VOLUME, DATA_POINTS, BEST_MODEL
        FROM ACCCODE_MODEL_COMPARISON
        WHERE ACCCODE = ?
    """, (code,))

    best_row = comparison[comparison['BEST_MODEL'] == 'Y']
    best_model = best_row['MODEL_NAME'].iloc[0] if len(best_row) else 'N/A'
    volume = int(comparison['TOTAL_VOLUME'].iloc[0]) if len(comparison) else 0
    data_points = int(comparison['DATA_POINTS'].iloc[0]) if len(comparison) else 0
    test_months = int((forecasts['IS_FUTURE'] != 'Y').sum()) if len(forecasts) else 0
    train_cutoff = data_points - test_months

    best_col = _best_forecast_col(best_model)

    # Chart: Actual line + Forecast line (best model only)
    chart_labels = []
    chart_actual = []
    chart_forecast = []

    for _, r in history.iterrows():
        label = str(r['PROD_DATE'])[:7]
        chart_labels.append(label)
        chart_actual.append(int(r['VEHICLECOUNT']))
        chart_forecast.append(None)

    for _, r in forecasts.iterrows():
        label = str(r['PROD_DATE'])[:7]
        fval = int(r[best_col]) if best_col in r.index and pd.notnull(r.get(best_col)) else None
        if fval is not None:
            fval = max(0, fval)
        if label in chart_labels:
            idx = chart_labels.index(label)
            chart_forecast[idx] = fval
        else:
            chart_labels.append(label)
            chart_actual.append(None)
            chart_forecast.append(fval)

    # Future predictions table
    future_data = []
    for _, r in forecasts[forecasts['IS_FUTURE'] == 'Y'].iterrows():
        fdate = str(r['PROD_DATE'])[:7]
        fval = int(r[best_col]) if best_col in r.index and pd.notnull(r.get(best_col)) else None
        if fval is not None:
            fval = max(0, fval)
        future_data.append({'date': fdate, 'predicted': fval})

    # Model comparison table data (all models)
    # Compute extended metrics from test period forecast data
    test_fc = forecasts[forecasts['IS_FUTURE'] != 'Y']
    model_col_map = {'SES': 'SES_FORECAST', 'SARIMA': 'SARIMA_FORECAST', 'BSTS': 'HW_FORECAST'}
    extra_metrics = {}
    if len(test_fc) > 0:
        actuals = test_fc['ACTUAL'].tolist()
        for mname, col in model_col_map.items():
            if col in test_fc.columns:
                preds = test_fc[col].tolist()
                wmape, smape, mad = _compute_extra_metrics(actuals, preds)
                extra_metrics[mname] = {'wmape': wmape, 'smape': smape, 'mad': mad}

    models_info = []
    for _, mr in comparison.iterrows():
        mape_v = mr['MAPE']
        rmse_v = mr['RMSE']
        mname = mr['MODEL_NAME']
        ext = extra_metrics.get(mname, {})
        models_info.append({
            'name': mname,
            'mape': round(float(mape_v), 1) if pd.notnull(mape_v) else None,
            'rmse': round(float(rmse_v), 1) if pd.notnull(rmse_v) else None,
            'wmape': round(ext['wmape'], 1) if ext.get('wmape') is not None else None,
            'smape': round(ext['smape'], 1) if ext.get('smape') is not None else None,
            'mad': round(ext['mad'], 1) if ext.get('mad') is not None else None,
            'is_best': mr['BEST_MODEL'] == 'Y',
        })
    models_info.sort(key=lambda m: m['mape'] if m['mape'] is not None else 9999)

    # Detailed data: training rows, test rows (all models), future rows (all models)
    def _safe_int(val):
        if pd.notnull(val):
            return max(0, int(round(float(val))))
        return None

    train_data = []
    for _, r in history.iterrows():
        tid = int(r['TIME_ID'])
        if tid <= train_cutoff:
            train_data.append({'date': str(r['PROD_DATE'])[:7], 'actual': int(r['VEHICLECOUNT'])})

    test_data = []
    for _, r in forecasts[forecasts['IS_FUTURE'] != 'Y'].iterrows():
        test_data.append({
            'date': str(r['PROD_DATE'])[:7],
            'actual': int(r['ACTUAL']) if pd.notnull(r.get('ACTUAL')) else None,
            'ses': _safe_int(r.get('SES_FORECAST')),
            'bsts': _safe_int(r.get('HW_FORECAST')),
            'sarima': _safe_int(r.get('SARIMA_FORECAST')),
        })

    future_all = []
    for _, r in forecasts[forecasts['IS_FUTURE'] == 'Y'].iterrows():
        future_all.append({
            'date': str(r['PROD_DATE'])[:7],
            'ses': _safe_int(r.get('SES_FORECAST')),
            'bsts': _safe_int(r.get('HW_FORECAST')),
            'sarima': _safe_int(r.get('SARIMA_FORECAST')),
        })

    return render_template('detail.html',
        acccode=code, volume=volume, best_model=best_model,
        chart_labels=chart_labels, chart_actual=chart_actual,
        chart_forecast=chart_forecast,
        train_cutoff=train_cutoff,
        data_points=data_points,
        test_months=test_months,
        forecast_horizon=len(future_data),
        future_data=future_data,
        models_info=models_info,
        train_data=train_data,
        test_data=test_data,
        future_all=future_all)


@app.route('/composite_predictions')
def composite_predictions_page():
    """Composite predictions: free-text search by ACCCODE/VPC/Vehicle Model."""
    f_acccode = request.args.get('acccode', '').strip().upper()
    f_vpc = request.args.get('vpc', '').strip()
    f_model = request.args.get('model', '').strip()

    filters = {'acccode': f_acccode, 'vpc': f_vpc, 'model': f_model}
    has_search = any([f_acccode, f_vpc, f_model])
    search_results = []

    if has_search:
        where_clauses = ["cm.BEST_MODEL = 'Y'"]
        params = []
        if f_acccode:
            where_clauses.append("UPPER(cm.ACCCODE) LIKE ?")
            params.append(f'%{f_acccode}%')
        if f_vpc:
            where_clauses.append("CAST(cm.VPC_LOCATION AS VARCHAR) LIKE ?")
            params.append(f'%{f_vpc}%')
        if f_model:
            where_clauses.append("UPPER(cm.MODEL) LIKE ?")
            params.append(f'%{f_model.upper()}%')

        where_sql = " AND ".join(where_clauses)
        results_df = query(f"""
            SELECT cm.COMPOSITE_KEY, cm.ACCCODE, cm.VPC_LOCATION, cm.MODEL,
                   cm.MODEL_NAME AS BEST_MODEL
            FROM COMPOSITE_MODEL_COMPARISON cm
            WHERE {where_sql}
            ORDER BY cm.ACCCODE, cm.VPC_LOCATION, cm.MODEL
        """, tuple(params) if params else None)

        if not results_df.empty:
            keys = results_df['COMPOSITE_KEY'].tolist()
            placeholders = ','.join(['?'] * len(keys))
            future_df = query(f"""
                SELECT COMPOSITE_KEY, PROD_DATE,
                       SES_FORECAST, HW_FORECAST, SARIMA_FORECAST
                FROM COMPOSITE_FORECAST_RESULTS
                WHERE IS_FUTURE = 'Y'
                  AND COMPOSITE_KEY IN ({placeholders})
                ORDER BY COMPOSITE_KEY, PROD_DATE
            """, tuple(keys))

            best_col_map = {
                'SES': 'SES_FORECAST',
                'SARIMA': 'SARIMA_FORECAST',
                'BSTS': 'HW_FORECAST',
            }

            for _, r in results_df.iterrows():
                key = r['COMPOSITE_KEY']
                best = r['BEST_MODEL']
                col = best_col_map.get(best, 'SES_FORECAST')

                key_future = future_df[future_df['COMPOSITE_KEY'] == key] if not future_df.empty else pd.DataFrame()
                months = []
                for _, fr in key_future.iterrows():
                    fdate = str(fr['PROD_DATE'])[:7]
                    val = int(fr[col]) if col in fr.index and pd.notnull(fr.get(col)) else None
                    if val is not None:
                        val = max(0, val)
                    months.append({'date': fdate, 'predicted': val})

                total = sum(m['predicted'] or 0 for m in months)
                search_results.append({
                    'key': key,
                    'acccode': r['ACCCODE'],
                    'vpc': str(r['VPC_LOCATION']),
                    'model': r['MODEL'],
                    'total': total,
                    'months': months,
                })

    return render_template('composite_predictions.html',
        filters=filters, search_results=search_results, has_search=has_search)


@app.route('/composite/<path:key>')
def composite_detail(key):
    """Detail: Actual vs Forecast chart + future predictions for composite key."""
    history = query("""
        SELECT TIME_ID, PROD_DATE, PRODYEAR, PRODMONTH, VEHICLECOUNT
        FROM COMPOSITE_TIMESERIES
        WHERE COMPOSITE_KEY = ?
        ORDER BY TIME_ID
    """, (key,))

    if history.empty:
        flash(f'No data found for composite key: {key}', 'error')
        return redirect(url_for('composite_predictions_page'))

    forecasts = query("""
        SELECT PROD_DATE, PRODYEAR, PRODMONTH, ACTUAL,
               SES_FORECAST, HW_FORECAST, SARIMA_FORECAST, IS_FUTURE
        FROM COMPOSITE_FORECAST_RESULTS
        WHERE COMPOSITE_KEY = ?
        ORDER BY PROD_DATE
    """, (key,))

    comparison = query("""
        SELECT MODEL_NAME, MAPE, RMSE, TOTAL_VOLUME, DATA_POINTS, BEST_MODEL
        FROM COMPOSITE_MODEL_COMPARISON
        WHERE COMPOSITE_KEY = ?
    """, (key,))

    best_row = comparison[comparison['BEST_MODEL'] == 'Y']
    best_model = best_row['MODEL_NAME'].iloc[0] if len(best_row) else 'N/A'
    volume = int(comparison['TOTAL_VOLUME'].iloc[0]) if len(comparison) else 0
    data_points = int(comparison['DATA_POINTS'].iloc[0]) if len(comparison) else 0
    test_months = int((forecasts['IS_FUTURE'] != 'Y').sum()) if len(forecasts) else 0
    train_cutoff = data_points - test_months

    parts = key.split('|', 2)
    acccode = parts[0] if len(parts) > 0 else ''
    vpc = parts[1] if len(parts) > 1 else ''
    vmodel = parts[2] if len(parts) > 2 else ''

    best_col = _best_forecast_col(best_model)

    # Chart: Actual + Forecast (best model only)
    chart_labels = []
    chart_actual = []
    chart_forecast = []

    for _, r in history.iterrows():
        label = str(r['PROD_DATE'])[:7]
        chart_labels.append(label)
        chart_actual.append(int(r['VEHICLECOUNT']))
        chart_forecast.append(None)

    for _, r in forecasts.iterrows():
        label = str(r['PROD_DATE'])[:7]
        fval = int(r[best_col]) if best_col in r.index and pd.notnull(r.get(best_col)) else None
        if fval is not None:
            fval = max(0, fval)
        if label in chart_labels:
            idx = chart_labels.index(label)
            chart_forecast[idx] = fval
        else:
            chart_labels.append(label)
            chart_actual.append(None)
            chart_forecast.append(fval)

    # Future predictions table
    future_data = []
    for _, r in forecasts[forecasts['IS_FUTURE'] == 'Y'].iterrows():
        fdate = str(r['PROD_DATE'])[:7]
        fval = int(r[best_col]) if best_col in r.index and pd.notnull(r.get(best_col)) else None
        if fval is not None:
            fval = max(0, fval)
        future_data.append({'date': fdate, 'predicted': fval})

    # Model comparison table data (all models)
    # Compute extended metrics from test period forecast data
    test_fc = forecasts[forecasts['IS_FUTURE'] != 'Y']
    model_col_map = {'SES': 'SES_FORECAST', 'SARIMA': 'SARIMA_FORECAST', 'BSTS': 'HW_FORECAST'}
    extra_metrics = {}
    if len(test_fc) > 0:
        actuals = test_fc['ACTUAL'].tolist()
        for mname, col in model_col_map.items():
            if col in test_fc.columns:
                preds = test_fc[col].tolist()
                wmape, smape, mad = _compute_extra_metrics(actuals, preds)
                extra_metrics[mname] = {'wmape': wmape, 'smape': smape, 'mad': mad}

    models_info = []
    for _, mr in comparison.iterrows():
        mape_v = mr['MAPE']
        rmse_v = mr['RMSE']
        mname = mr['MODEL_NAME']
        ext = extra_metrics.get(mname, {})
        models_info.append({
            'name': mname,
            'mape': round(float(mape_v), 1) if pd.notnull(mape_v) else None,
            'rmse': round(float(rmse_v), 1) if pd.notnull(rmse_v) else None,
            'wmape': round(ext['wmape'], 1) if ext.get('wmape') is not None else None,
            'smape': round(ext['smape'], 1) if ext.get('smape') is not None else None,
            'mad': round(ext['mad'], 1) if ext.get('mad') is not None else None,
            'is_best': mr['BEST_MODEL'] == 'Y',
        })
    models_info.sort(key=lambda m: m['mape'] if m['mape'] is not None else 9999)

    # Detailed data: training rows, test rows (all models), future rows (all models)
    def _safe_int(val):
        if pd.notnull(val):
            return max(0, int(round(float(val))))
        return None

    train_data = []
    for _, r in history.iterrows():
        tid = int(r['TIME_ID'])
        if tid <= train_cutoff:
            train_data.append({'date': str(r['PROD_DATE'])[:7], 'actual': int(r['VEHICLECOUNT'])})

    test_data = []
    for _, r in forecasts[forecasts['IS_FUTURE'] != 'Y'].iterrows():
        test_data.append({
            'date': str(r['PROD_DATE'])[:7],
            'actual': int(r['ACTUAL']) if pd.notnull(r.get('ACTUAL')) else None,
            'ses': _safe_int(r.get('SES_FORECAST')),
            'bsts': _safe_int(r.get('HW_FORECAST')),
            'sarima': _safe_int(r.get('SARIMA_FORECAST')),
        })

    future_all = []
    for _, r in forecasts[forecasts['IS_FUTURE'] == 'Y'].iterrows():
        future_all.append({
            'date': str(r['PROD_DATE'])[:7],
            'ses': _safe_int(r.get('SES_FORECAST')),
            'bsts': _safe_int(r.get('HW_FORECAST')),
            'sarima': _safe_int(r.get('SARIMA_FORECAST')),
        })

    return render_template('composite_detail.html',
        composite_key=key, acccode=acccode, vpc=vpc, vmodel=vmodel,
        volume=volume, best_model=best_model,
        chart_labels=chart_labels, chart_actual=chart_actual,
        chart_forecast=chart_forecast,
        train_cutoff=train_cutoff,
        data_points=data_points,
        test_months=test_months,
        forecast_horizon=len(future_data),
        future_data=future_data,
        models_info=models_info,
        train_data=train_data,
        test_data=test_data,
        future_all=future_all)


# ─── API endpoints ──────────────────────────────────────────────

@app.route('/api/search')
def api_search():
    """ACCCODE autocomplete for shell bar search."""
    q = request.args.get('q', '').strip().upper()
    if not q:
        return jsonify([])
    df = query("""
        SELECT DISTINCT ACCCODE
        FROM ACCCODE_MODEL_COMPARISON
        WHERE UPPER(ACCCODE) LIKE ?
        ORDER BY ACCCODE
    """, (f'%{q}%',))
    return jsonify(df['ACCCODE'].tolist())


@app.route('/api/debug')
def api_debug():
    """Diagnostic endpoint to check DB connection and data."""
    info = {}
    try:
        creds = _hana_creds()
        info['user'] = creds['user'][:20] + '...'
        info['schema'] = creds['schema']
        info['host'] = creds['host'][:30] + '...'
    except Exception as e:
        info['creds_error'] = str(e)
        return jsonify(info)
    for table in ['ACCCODE_MODEL_COMPARISON', 'ACCCODE_FORECAST_RESULTS',
                   'ACCCODE_TIMESERIES', 'ACCESSORY_FORECAST']:
        try:
            df = query(f"SELECT COUNT(*) AS CNT FROM {table}")
            info[f'{table.lower()}_rows'] = int(df['CNT'].iloc[0])
        except Exception as e:
            info[f'{table.lower()}_error'] = str(e)
    return jsonify(info)


# ═══════════════════════════════════════════════════════════════════
#  MODEL TRAINING API — Parameters, Re-train, Fine-tune
# ═══════════════════════════════════════════════════════════════════

# Default model parameters (used when training)
DEFAULT_PARAMS = {
    'global': {
        'FORECAST_HORIZON': 12,
        'TEST_MONTHS': 3,
        'SEASONAL_PERIOD': 12,
    },
    'SES': {
        'description': 'Simple Exponential Smoothing (PAL_BROWN_EXPSMOOTH)',
        'pal_procedure': '_SYS_AFL.PAL_BROWN_EXPSMOOTH',
        'sql_call': 'CALL _SYS_AFL.PAL_BROWN_EXPSMOOTH(#PAL_DATA, #SES_PARAM, #SES_OUT, #SES_STATS)',
        'params': {
            'FORECAST_NUM': {'value': 'auto', 'type': 'int',
                             'description': 'Number of periods to forecast (test + future). Auto = TEST_MONTHS + FORECAST_HORIZON.'},
            'ALPHA': {'value': 'auto', 'type': 'double',
                      'description': 'Smoothing constant (0.0-1.0). Lower = smoother/stable, Higher = reactive/volatile. Default: auto-optimized by PAL.'},
        },
    },
    'SARIMA': {
        'description': 'Seasonal AutoARIMA (PAL_AUTOARIMA + PAL_ARIMA_FORECAST)',
        'pal_procedure': '_SYS_AFL.PAL_AUTOARIMA → _SYS_AFL.PAL_ARIMA_FORECAST',
        'sql_calls': [
            'CALL _SYS_AFL.PAL_AUTOARIMA(:lt_data, :lt_param, lt_model, lt_fit)',
            'CALL _SYS_AFL.PAL_ARIMA_FORECAST(:lt_data, :lt_model, :lt_param, lt_result)',
        ],
        'params': {
            'SEASONAL_PERIOD': {'value': 12, 'type': 'int',
                                'description': 'Seasonal cycle length. Capped at train_cutoff-1 per series.'},
            'METHOD': {'value': 1, 'type': 'int',
                       'description': 'Information criterion for order selection. 0=AIC, 1=AICc (default), 2=BIC.'},
            'THREAD_RATIO': {'value': 1.0, 'type': 'double',
                             'description': 'Ratio of threads (0-1). 1.0 = use all available.'},
            'FORECAST_LENGTH': {'value': 'auto', 'type': 'int',
                                'description': 'Periods to forecast. Auto = TEST_MONTHS + FORECAST_HORIZON.'},
            'FORECAST_METHOD': {'value': 1, 'type': 'int',
                                'description': '1 = innovations algorithm (default).'},
            'MAX_P': {'value': 'auto', 'type': 'int',
                      'description': 'Maximum AR order p. Limits model complexity. Default: unlimited (PAL searches all).'},
            'MAX_Q': {'value': 'auto', 'type': 'int',
                      'description': 'Maximum MA order q. Limits model complexity. Default: unlimited (PAL searches all).'},
        },
    },
    'BSTS': {
        'description': 'Bayesian Structural Time Series (hana_ml BSTS class)',
        'pal_procedure': 'hana_ml.algorithms.pal.tsa.bsts.BSTS',
        'sql_call': 'BSTS(burn, niter, seasonal_period, seed, local_linear_trend, damped).fit(data, key, endog).predict(horizon)',
        'params': {
            'burn': {'value': 0.5, 'type': 'double',
                     'description': 'Fraction of MCMC iterations to discard as burn-in (0-1).'},
            'niter': {'value': 2000, 'type': 'int',
                      'description': 'Total MCMC iterations. Higher = more accurate but slower.'},
            'seasonal_period': {'value': 12, 'type': 'int',
                                'description': 'Seasonal cycle length. Capped at train_cutoff-1 per series.'},
            'seed': {'value': 1, 'type': 'int',
                     'description': 'Random seed for reproducibility.'},
            'local_linear_trend': {'value': True, 'type': 'bool',
                                   'description': 'True = level + trend (default). False = level only. Set False for flat/stable series.'},
            'damped': {'value': False, 'type': 'bool',
                       'description': 'Damped trend. True = prevents forecast from diverging on long horizons. Recommended for 24+ month forecasts.'},
        },
    },
}


@app.route('/api/models')
def api_models():
    """List all available forecast models and their default parameters."""
    return jsonify(DEFAULT_PARAMS)


@app.route('/api/models/<model_name>')
def api_model_detail(model_name):
    """Get parameters for a specific model (SES, SARIMA, BSTS)."""
    key = model_name.upper()
    if key not in DEFAULT_PARAMS:
        if key == 'GLOBAL':
            return jsonify(DEFAULT_PARAMS['global'])
        return jsonify({'error': f'Unknown model: {model_name}. Use SES, SARIMA, or BSTS.'}), 404
    return jsonify({key: DEFAULT_PARAMS[key], 'global': DEFAULT_PARAMS['global']})


@app.route('/api/models/acccode/<code>')
def api_model_comparison(code):
    """Return stored model comparison results for an ACCCODE."""
    df = query("""
        SELECT MODEL_NAME, MAPE, RMSE, TOTAL_VOLUME, DATA_POINTS, BEST_MODEL
        FROM ACCCODE_MODEL_COMPARISON
        WHERE ACCCODE = ?
        ORDER BY MODEL_NAME
    """, (code.upper(),))
    if df.empty:
        return jsonify({'error': f'No results for ACCCODE {code}'}), 404
    rows = []
    for _, r in df.iterrows():
        rows.append({
            'model': r['MODEL_NAME'],
            'mape': round(float(r['MAPE']), 2) if pd.notnull(r['MAPE']) else None,
            'rmse': round(float(r['RMSE']), 2) if pd.notnull(r['RMSE']) else None,
            'total_volume': int(r['TOTAL_VOLUME']) if pd.notnull(r['TOTAL_VOLUME']) else None,
            'data_points': int(r['DATA_POINTS']) if pd.notnull(r['DATA_POINTS']) else None,
            'is_best': r['BEST_MODEL'] == 'Y',
        })
    return jsonify({'acccode': code.upper(), 'models': rows})


@app.route('/api/retrain/acccode/<code>', methods=['POST'])
def api_retrain_acccode(code):
    """
    Re-train forecast models for a single ACCCODE with custom parameters.

    POST JSON body (all optional — defaults used if omitted):
    {
      "models": ["SES", "SARIMA", "BSTS"],   // which models to run
      "FORECAST_HORIZON": 12,
      "TEST_MONTHS": 3,
      "SEASONAL_PERIOD": 12,
      "SES": {"ALPHA": 0.3},
      "SARIMA": {"METHOD": 1, "THREAD_RATIO": 1.0, "MAX_P": 5, "MAX_Q": 5},
      "BSTS": {"burn": 0.5, "niter": 2000, "seed": 1, "local_linear_trend": true, "damped": false}
    }
    """
    code = code.upper()
    body = request.get_json(silent=True) or {}
    models_to_run = [m.upper() for m in body.get('models', ['SES', 'SARIMA', 'BSTS'])]
    forecast_horizon = int(body.get('FORECAST_HORIZON', 12))
    test_months_cfg = int(body.get('TEST_MONTHS', 3))
    seasonal_period = int(body.get('SEASONAL_PERIOD', 12))
    ses_params = body.get('SES', {})
    sarima_params = body.get('SARIMA', {})
    bsts_params = body.get('BSTS', {})

    conn = get_conn()
    cursor = conn.connection.cursor()
    schema = _hana_creds()['schema']
    if schema:
        cursor.execute('SET SCHEMA "{}"'.format(schema.replace('"', '""')))

    def _sql(stmt):
        cursor.execute(stmt)
        if stmt.strip().upper().startswith(('SELECT', 'CALL')):
            try:
                return cursor.fetchall()
            except:
                return []
        return []

    def _drop(name):
        try:
            cursor.execute(f"DROP TABLE {name}")
        except:
            pass

    # Load time series for this ACCCODE
    cursor.execute(
        "SELECT TIME_ID, VEHICLECOUNT, PROD_DATE, PRODYEAR, PRODMONTH "
        "FROM ACCCODE_TIMESERIES WHERE ACCCODE = ? ORDER BY TIME_ID", (code,))
    rows = cursor.fetchall()
    if not rows:
        conn.close()
        return jsonify({'error': f'No timeseries data for ACCCODE {code}'}), 404

    ts_df = pd.DataFrame(rows, columns=['TIME_ID', 'VEHICLECOUNT', 'PROD_DATE', 'PRODYEAR', 'PRODMONTH'])
    ts_df['PROD_DATE'] = pd.to_datetime(ts_df['PROD_DATE'])

    nonzero = ts_df[ts_df['VEHICLECOUNT'] > 0]['VEHICLECOUNT']
    if len(nonzero) == 0:
        conn.close()
        return jsonify({'error': f'ACCCODE {code} has no non-zero data'}), 400

    avg = nonzero.mean()
    threshold = max(avg * 0.10, 1)
    eff_end = int(ts_df['TIME_ID'].max())
    for _, r in ts_df.sort_values('TIME_ID', ascending=False).iterrows():
        if r['VEHICLECOUNT'] >= threshold:
            eff_end = int(r['TIME_ID'])
            break

    min_needed = 12 + test_months_cfg
    if eff_end < min_needed:
        train_cutoff = max(eff_end - 2, 10)
        eff_test_months = eff_end - train_cutoff
    else:
        train_cutoff = eff_end - test_months_cfg
        eff_test_months = test_months_cfg

    total_forecast = eff_test_months + forecast_horizon
    eff_seasonal = min(seasonal_period, train_cutoff - 1)

    test_actual = ts_df[(ts_df['TIME_ID'] > train_cutoff) &
                        (ts_df['TIME_ID'] <= eff_end)]['VEHICLECOUNT'].values.tolist()

    # Insert training data
    _drop('#PAL_DATA')
    _sql("CREATE LOCAL TEMPORARY COLUMN TABLE #PAL_DATA (TIME_ID INT, VEHICLECOUNT DOUBLE)")
    cursor.execute(
        "INSERT INTO #PAL_DATA SELECT TIME_ID, CAST(VEHICLECOUNT AS DOUBLE) "
        "FROM ACCCODE_TIMESERIES WHERE ACCCODE = ? AND TIME_ID <= ?",
        (code, train_cutoff))

    results = {'acccode': code, 'train_cutoff': train_cutoff,
               'test_months': eff_test_months, 'effective_end': eff_end,
               'forecast_horizon': forecast_horizon, 'params_used': {}}
    forecasts = {}

    # ── SES ──
    if 'SES' in models_to_run:
        ses_alpha = ses_params.get('ALPHA', None)
        params_info = {'FORECAST_NUM': total_forecast}
        if ses_alpha is not None:
            params_info['ALPHA'] = float(ses_alpha)
        results['params_used']['SES'] = params_info
        try:
            _drop('#SES_PARAM'); _drop('#SES_OUT'); _drop('#SES_STATS')
            _sql("CREATE LOCAL TEMPORARY COLUMN TABLE #SES_PARAM "
                 "(PARAM_NAME NVARCHAR(256), INT_VALUE INT, DOUBLE_VALUE DOUBLE, STRING_VALUE NVARCHAR(256))")
            cursor.execute("INSERT INTO #SES_PARAM VALUES (?, ?, NULL, NULL)", ('FORECAST_NUM', total_forecast))
            if ses_alpha is not None:
                cursor.execute("INSERT INTO #SES_PARAM VALUES (?, NULL, ?, NULL)", ('ALPHA', float(ses_alpha)))
            _sql("CREATE LOCAL TEMPORARY COLUMN TABLE #SES_OUT (TIME_ID INT, FORECAST DOUBLE)")
            _sql("CREATE LOCAL TEMPORARY COLUMN TABLE #SES_STATS (STAT_NAME NVARCHAR(256), STAT_VALUE DOUBLE)")
            _sql("CALL _SYS_AFL.PAL_BROWN_EXPSMOOTH(#PAL_DATA, #SES_PARAM, #SES_OUT, #SES_STATS)")
            cursor.execute(f"SELECT TIME_ID, FORECAST FROM #SES_OUT WHERE TIME_ID > {train_cutoff} ORDER BY TIME_ID")
            ses_rows = cursor.fetchall()
            if ses_rows:
                forecasts['SES_TEST'] = [max(0.0, float(r[1])) for r in ses_rows[:eff_test_months]]
                forecasts['SES_FUTURE'] = [max(0.0, float(r[1])) for r in ses_rows[eff_test_months:eff_test_months + forecast_horizon]]
        except Exception as e:
            results['SES_error'] = str(e)

    # ── SARIMA ──
    if 'SARIMA' in models_to_run:
        method = int(sarima_params.get('METHOD', 1))
        thread_ratio = float(sarima_params.get('THREAD_RATIO', 1.0))
        fc_method = int(sarima_params.get('FORECAST_METHOD', 1))
        max_p = sarima_params.get('MAX_P', None)
        max_q = sarima_params.get('MAX_Q', None)
        params_info = {
            'SEASONAL_PERIOD': eff_seasonal, 'METHOD': method,
            'THREAD_RATIO': thread_ratio, 'FORECAST_LENGTH': total_forecast,
            'FORECAST_METHOD': fc_method}
        if max_p is not None:
            params_info['MAX_P'] = int(max_p)
        if max_q is not None:
            params_info['MAX_Q'] = int(max_q)
        results['params_used']['SARIMA'] = params_info
        try:
            _drop('#ARIMA_PARAM'); _drop('#ARIMA_MODEL'); _drop('#ARIMA_FIT')
            _sql("CREATE LOCAL TEMPORARY COLUMN TABLE #ARIMA_PARAM "
                 "(PARAM_NAME NVARCHAR(256), INT_VALUE INT, DOUBLE_VALUE DOUBLE, STRING_VALUE NVARCHAR(256))")
            cursor.execute("INSERT INTO #ARIMA_PARAM VALUES (?, ?, NULL, NULL)", ('SEASONAL_PERIOD', eff_seasonal))
            cursor.execute("INSERT INTO #ARIMA_PARAM VALUES (?, ?, NULL, NULL)", ('METHOD', method))
            cursor.execute("INSERT INTO #ARIMA_PARAM VALUES (?, NULL, ?, NULL)", ('THREAD_RATIO', thread_ratio))
            if max_p is not None:
                cursor.execute("INSERT INTO #ARIMA_PARAM VALUES (?, ?, NULL, NULL)", ('MAX_P', int(max_p)))
            if max_q is not None:
                cursor.execute("INSERT INTO #ARIMA_PARAM VALUES (?, ?, NULL, NULL)", ('MAX_Q', int(max_q)))
            _sql("CREATE LOCAL TEMPORARY COLUMN TABLE #ARIMA_MODEL (KEY NVARCHAR(256), VALUE NVARCHAR(5000))")
            _sql("CREATE LOCAL TEMPORARY COLUMN TABLE #ARIMA_FIT (TIME_ID INT, FITTED DOUBLE, RESIDUALS DOUBLE)")
            cursor.execute("""
DO BEGIN
    lt_data = SELECT TIME_ID, VEHICLECOUNT FROM #PAL_DATA;
    lt_param = SELECT PARAM_NAME, INT_VALUE, DOUBLE_VALUE, STRING_VALUE FROM #ARIMA_PARAM;
    CALL _SYS_AFL.PAL_AUTOARIMA(:lt_data, :lt_param, lt_model, lt_fit);
    INSERT INTO #ARIMA_MODEL SELECT * FROM :lt_model;
    INSERT INTO #ARIMA_FIT SELECT * FROM :lt_fit;
END;
""")
            _drop('#FC_DATA'); _drop('#FC_PARAM'); _drop('#FC_OUT')
            _sql("CREATE LOCAL TEMPORARY COLUMN TABLE #FC_DATA (TIME_ID INT, VEHICLECOUNT DOUBLE)")
            _sql("CREATE LOCAL TEMPORARY COLUMN TABLE #FC_PARAM "
                 "(PARAM_NAME NVARCHAR(256), INT_VALUE INT, DOUBLE_VALUE DOUBLE, STRING_VALUE NVARCHAR(256))")
            cursor.execute("INSERT INTO #FC_PARAM VALUES (?, ?, NULL, NULL)", ('FORECAST_LENGTH', total_forecast))
            cursor.execute("INSERT INTO #FC_PARAM VALUES (?, ?, NULL, NULL)", ('FORECAST_METHOD', fc_method))
            _sql("CREATE LOCAL TEMPORARY COLUMN TABLE #FC_OUT "
                 "(TIME_ID INT, FORECAST DOUBLE, SE DOUBLE, LO80 DOUBLE, HI80 DOUBLE, LO95 DOUBLE, HI95 DOUBLE)")
            cursor.execute("""
DO BEGIN
    lt_data = SELECT TIME_ID, VEHICLECOUNT FROM #FC_DATA;
    lt_model = SELECT KEY, VALUE FROM #ARIMA_MODEL;
    lt_param = SELECT PARAM_NAME, INT_VALUE, DOUBLE_VALUE, STRING_VALUE FROM #FC_PARAM;
    CALL _SYS_AFL.PAL_ARIMA_FORECAST(:lt_data, :lt_model, :lt_param, lt_result);
    INSERT INTO #FC_OUT SELECT * FROM :lt_result;
END;
""")
            cursor.execute("SELECT TIME_ID, FORECAST FROM #FC_OUT ORDER BY TIME_ID")
            arima_rows = cursor.fetchall()
            if arima_rows:
                forecasts['SARIMA_TEST'] = [max(0.0, float(r[1])) for r in arima_rows[:eff_test_months]]
                forecasts['SARIMA_FUTURE'] = [max(0.0, float(r[1])) for r in arima_rows[eff_test_months:eff_test_months + forecast_horizon]]
        except Exception as e:
            results['SARIMA_error'] = str(e)

    # ── BSTS ──
    if 'BSTS' in models_to_run:
        burn = float(bsts_params.get('burn', 0.5))
        niter = int(bsts_params.get('niter', 2000))
        seed = int(bsts_params.get('seed', 1))
        local_linear_trend = bsts_params.get('local_linear_trend', True)
        damped = bsts_params.get('damped', False)
        results['params_used']['BSTS'] = {
            'burn': burn, 'niter': niter,
            'seasonal_period': eff_seasonal, 'seed': seed,
            'local_linear_trend': local_linear_trend, 'damped': damped}
        try:
            if train_cutoff <= eff_seasonal:
                raise ValueError(f"Only {train_cutoff} training points, need > {eff_seasonal}")
            safe_code = code.replace("'", "''")
            hana_train = conn.sql(f"""
                SELECT TIME_ID AS "TIME_STAMP", CAST(VEHICLECOUNT AS DOUBLE) AS "TARGET"
                FROM "{schema}"."ACCCODE_TIMESERIES"
                WHERE ACCCODE='{safe_code}' AND TIME_ID<={train_cutoff}
                ORDER BY TIME_ID
            """)
            bsts_model = BSTS(burn=burn, niter=niter, seasonal_period=eff_seasonal, seed=seed,
                             local_linear_trend=local_linear_trend, damped=damped)
            bsts_model.fit(data=hana_train, key='TIME_STAMP', endog='TARGET')
            bsts_result = bsts_model.predict(horizon=total_forecast)
            bsts_fc_df = bsts_result[0].collect()
            bsts_all = []
            for _, row in bsts_fc_df.iterrows():
                offset = int(row['TIME_STAMP'])
                real_tid = train_cutoff + 1 + offset
                val = max(0.0, float(row['FORECAST']))
                bsts_all.append((real_tid, val))
            bsts_all.sort(key=lambda x: x[0])
            forecasts['BSTS_TEST'] = [v for tid, v in bsts_all if tid <= eff_end][:eff_test_months]
            forecasts['BSTS_FUTURE'] = [v for tid, v in bsts_all if tid > eff_end][:forecast_horizon]
        except Exception as e:
            results['BSTS_error'] = str(e)

    # ── Seasonal post-adjustment ──
    train_data = ts_df[ts_df['TIME_ID'] <= train_cutoff]
    monthly_means = train_data.groupby('PRODMONTH')['VEHICLECOUNT'].mean()
    overall_mean = train_data['VEHICLECOUNT'].mean()
    if overall_mean > 0 and len(monthly_means) >= 6:
        seasonal_indices = (monthly_means / overall_mean).to_dict()
        test_months_list = ts_df[
            (ts_df['TIME_ID'] > train_cutoff) & (ts_df['TIME_ID'] <= eff_end)
        ]['PRODMONTH'].tolist()
        _lr = ts_df[ts_df['TIME_ID'] == eff_end]
        _fs = (_lr.iloc[0]['PROD_DATE'] + pd.DateOffset(months=1)) if len(_lr) > 0 else (ts_df['PROD_DATE'].max() + pd.DateOffset(months=1))
        future_months_list = [str((_fs + pd.DateOffset(months=i)).month).zfill(2) for i in range(forecast_horizon)]
        for mp in models_to_run:
            for tk, ml in [(f'{mp}_TEST', test_months_list), (f'{mp}_FUTURE', future_months_list)]:
                if tk in forecasts:
                    forecasts[tk] = [max(0.0, v * seasonal_indices.get(
                        ml[i] if i < len(ml) else '01', 1.0)) for i, v in enumerate(forecasts[tk])]
        results['seasonal_indices'] = {k: round(v, 4) for k, v in seasonal_indices.items()}

    # ── Compute metrics ──
    def _mape(a, f):
        a, f = np.array(a, dtype=float), np.array(f, dtype=float)
        m = a > 0
        return round(float(np.mean(np.abs((a[m] - f[m]) / a[m])) * 100), 2) if m.sum() > 0 else None

    def _rmse(a, f):
        return round(float(np.sqrt(np.mean((np.array(a, dtype=float) - np.array(f, dtype=float)) ** 2))), 2)

    model_metrics = {}
    for mk in models_to_run:
        tk = f'{mk}_TEST'
        if tk in forecasts and test_actual:
            model_metrics[mk] = {
                'mape': _mape(test_actual, forecasts[tk]),
                'rmse': _rmse(test_actual, forecasts[tk]),
                'test_forecast': [round(v, 1) for v in forecasts[tk]],
                'future_forecast': [round(v, 1) for v in forecasts.get(f'{mk}_FUTURE', [])],
            }
    results['test_actual'] = test_actual
    results['models'] = model_metrics

    if model_metrics:
        best = min(model_metrics, key=lambda m: model_metrics[m]['mape'] or float('inf'))
        results['best_model'] = best

    # Clean up
    for t in ['#PAL_DATA', '#SES_PARAM', '#SES_OUT', '#SES_STATS',
              '#ARIMA_PARAM', '#ARIMA_MODEL', '#ARIMA_FIT',
              '#FC_DATA', '#FC_PARAM', '#FC_OUT']:
        _drop(t)
    conn.close()

    return jsonify(results)


# ═══════════════════════════════════════════════════════════════════
#  COMPOSITE MODEL TRAINING API
# ═══════════════════════════════════════════════════════════════════

@app.route('/api/composite/search')
def api_composite_search():
    """Search composite keys by ACCCODE, VPC, or MODEL (partial match)."""
    q = request.args.get('q', '').strip().upper()
    if not q:
        return jsonify([])
    df = query("""
        SELECT DISTINCT COMPOSITE_KEY, ACCCODE, VPC_LOCATION, MODEL
        FROM COMPOSITE_MODEL_COMPARISON
        WHERE UPPER(COMPOSITE_KEY) LIKE ?
           OR UPPER(ACCCODE) LIKE ?
           OR CAST(VPC_LOCATION AS VARCHAR) LIKE ?
           OR UPPER(MODEL) LIKE ?
        ORDER BY COMPOSITE_KEY
    """, (f'%{q}%', f'%{q}%', f'%{q}%', f'%{q}%'))
    results = []
    for _, r in df.iterrows():
        results.append({
            'composite_key': r['COMPOSITE_KEY'],
            'acccode': r['ACCCODE'],
            'vpc_location': int(r['VPC_LOCATION']) if pd.notnull(r['VPC_LOCATION']) else None,
            'model': r['MODEL'],
        })
    return jsonify(results)


@app.route('/api/models/composite/<path:key>')
def api_composite_model_comparison(key):
    """Return stored model comparison results for a composite key."""
    df = query("""
        SELECT MODEL_NAME, MAPE, RMSE, TOTAL_VOLUME, DATA_POINTS, BEST_MODEL
        FROM COMPOSITE_MODEL_COMPARISON
        WHERE COMPOSITE_KEY = ?
        ORDER BY MODEL_NAME
    """, (key,))
    if df.empty:
        return jsonify({'error': f'No results for composite key {key}'}), 404
    rows = []
    for _, r in df.iterrows():
        rows.append({
            'model': r['MODEL_NAME'],
            'mape': round(float(r['MAPE']), 2) if pd.notnull(r['MAPE']) else None,
            'rmse': round(float(r['RMSE']), 2) if pd.notnull(r['RMSE']) else None,
            'total_volume': int(r['TOTAL_VOLUME']) if pd.notnull(r['TOTAL_VOLUME']) else None,
            'data_points': int(r['DATA_POINTS']) if pd.notnull(r['DATA_POINTS']) else None,
            'is_best': r['BEST_MODEL'] == 'Y',
        })
    parts = key.split('|', 2)
    return jsonify({
        'composite_key': key,
        'acccode': parts[0] if len(parts) > 0 else '',
        'vpc_location': parts[1] if len(parts) > 1 else '',
        'model': parts[2] if len(parts) > 2 else '',
        'models': rows,
    })


@app.route('/api/retrain/composite/<path:key>', methods=['POST'])
def api_retrain_composite(key):
    """
    Re-train forecast models for a composite key with custom parameters.

    POST JSON body (all optional — defaults used if omitted):
    {
      "models": ["SES", "SARIMA", "BSTS"],
      "FORECAST_HORIZON": 12,
      "TEST_MONTHS": 3,
      "SEASONAL_PERIOD": 12,
      "SES": {"ALPHA": 0.3},
      "SARIMA": {"METHOD": 1, "THREAD_RATIO": 1.0, "MAX_P": 5, "MAX_Q": 5},
      "BSTS": {"burn": 0.5, "niter": 2000, "seed": 1, "local_linear_trend": true, "damped": false}
    }
    """
    body = request.get_json(silent=True) or {}
    models_to_run = [m.upper() for m in body.get('models', ['SES', 'SARIMA', 'BSTS'])]
    forecast_horizon = int(body.get('FORECAST_HORIZON', 12))
    test_months_cfg = int(body.get('TEST_MONTHS', 3))
    seasonal_period = int(body.get('SEASONAL_PERIOD', 12))
    ses_params = body.get('SES', {})
    sarima_params = body.get('SARIMA', {})
    bsts_params = body.get('BSTS', {})

    conn = get_conn()
    cursor = conn.connection.cursor()
    schema = _hana_creds()['schema']
    if schema:
        cursor.execute('SET SCHEMA "{}"'.format(schema.replace('"', '""')))

    def _sql(stmt):
        cursor.execute(stmt)
        if stmt.strip().upper().startswith(('SELECT', 'CALL')):
            try:
                return cursor.fetchall()
            except:
                return []
        return []

    def _drop(name):
        try:
            cursor.execute(f"DROP TABLE {name}")
        except:
            pass

    # Load time series for this composite key
    cursor.execute(
        "SELECT TIME_ID, VEHICLECOUNT, PROD_DATE, PRODYEAR, PRODMONTH "
        "FROM COMPOSITE_TIMESERIES WHERE COMPOSITE_KEY = ? ORDER BY TIME_ID", (key,))
    rows = cursor.fetchall()
    if not rows:
        conn.close()
        return jsonify({'error': f'No timeseries data for composite key {key}'}), 404

    ts_df = pd.DataFrame(rows, columns=['TIME_ID', 'VEHICLECOUNT', 'PROD_DATE', 'PRODYEAR', 'PRODMONTH'])
    ts_df['PROD_DATE'] = pd.to_datetime(ts_df['PROD_DATE'])

    nonzero = ts_df[ts_df['VEHICLECOUNT'] > 0]['VEHICLECOUNT']
    if len(nonzero) == 0:
        conn.close()
        return jsonify({'error': f'Composite key {key} has no non-zero data'}), 400

    avg = nonzero.mean()
    threshold = max(avg * 0.10, 1)
    eff_end = int(ts_df['TIME_ID'].max())
    for _, r in ts_df.sort_values('TIME_ID', ascending=False).iterrows():
        if r['VEHICLECOUNT'] >= threshold:
            eff_end = int(r['TIME_ID'])
            break

    min_needed = 12 + test_months_cfg
    if eff_end < min_needed:
        train_cutoff = max(eff_end - 2, 10)
        eff_test_months = eff_end - train_cutoff
    else:
        train_cutoff = eff_end - test_months_cfg
        eff_test_months = test_months_cfg

    total_forecast = eff_test_months + forecast_horizon
    eff_seasonal = min(seasonal_period, train_cutoff - 1)

    test_actual = ts_df[(ts_df['TIME_ID'] > train_cutoff) &
                        (ts_df['TIME_ID'] <= eff_end)]['VEHICLECOUNT'].values.tolist()

    # Insert training data
    _drop('#PAL_DATA')
    _sql("CREATE LOCAL TEMPORARY COLUMN TABLE #PAL_DATA (TIME_ID INT, VEHICLECOUNT DOUBLE)")
    cursor.execute(
        "INSERT INTO #PAL_DATA SELECT TIME_ID, CAST(VEHICLECOUNT AS DOUBLE) "
        "FROM COMPOSITE_TIMESERIES WHERE COMPOSITE_KEY = ? AND TIME_ID <= ?",
        (key, train_cutoff))

    parts = key.split('|', 2)
    results = {
        'composite_key': key,
        'acccode': parts[0] if len(parts) > 0 else '',
        'vpc_location': parts[1] if len(parts) > 1 else '',
        'model': parts[2] if len(parts) > 2 else '',
        'train_cutoff': train_cutoff,
        'test_months': eff_test_months, 'effective_end': eff_end,
        'forecast_horizon': forecast_horizon, 'params_used': {},
    }
    forecasts = {}

    # ── SES ──
    if 'SES' in models_to_run:
        ses_alpha = ses_params.get('ALPHA', None)
        params_info = {'FORECAST_NUM': total_forecast}
        if ses_alpha is not None:
            params_info['ALPHA'] = float(ses_alpha)
        results['params_used']['SES'] = params_info
        try:
            _drop('#SES_PARAM'); _drop('#SES_OUT'); _drop('#SES_STATS')
            _sql("CREATE LOCAL TEMPORARY COLUMN TABLE #SES_PARAM "
                 "(PARAM_NAME NVARCHAR(256), INT_VALUE INT, DOUBLE_VALUE DOUBLE, STRING_VALUE NVARCHAR(256))")
            cursor.execute("INSERT INTO #SES_PARAM VALUES (?, ?, NULL, NULL)", ('FORECAST_NUM', total_forecast))
            if ses_alpha is not None:
                cursor.execute("INSERT INTO #SES_PARAM VALUES (?, NULL, ?, NULL)", ('ALPHA', float(ses_alpha)))
            _sql("CREATE LOCAL TEMPORARY COLUMN TABLE #SES_OUT (TIME_ID INT, FORECAST DOUBLE)")
            _sql("CREATE LOCAL TEMPORARY COLUMN TABLE #SES_STATS (STAT_NAME NVARCHAR(256), STAT_VALUE DOUBLE)")
            _sql("CALL _SYS_AFL.PAL_BROWN_EXPSMOOTH(#PAL_DATA, #SES_PARAM, #SES_OUT, #SES_STATS)")
            cursor.execute(f"SELECT TIME_ID, FORECAST FROM #SES_OUT WHERE TIME_ID > {train_cutoff} ORDER BY TIME_ID")
            ses_rows = cursor.fetchall()
            if ses_rows:
                forecasts['SES_TEST'] = [max(0.0, float(r[1])) for r in ses_rows[:eff_test_months]]
                forecasts['SES_FUTURE'] = [max(0.0, float(r[1])) for r in ses_rows[eff_test_months:eff_test_months + forecast_horizon]]
        except Exception as e:
            results['SES_error'] = str(e)

    # ── SARIMA ──
    if 'SARIMA' in models_to_run:
        method = int(sarima_params.get('METHOD', 1))
        thread_ratio = float(sarima_params.get('THREAD_RATIO', 1.0))
        fc_method = int(sarima_params.get('FORECAST_METHOD', 1))
        max_p = sarima_params.get('MAX_P', None)
        max_q = sarima_params.get('MAX_Q', None)
        params_info = {
            'SEASONAL_PERIOD': eff_seasonal, 'METHOD': method,
            'THREAD_RATIO': thread_ratio, 'FORECAST_LENGTH': total_forecast,
            'FORECAST_METHOD': fc_method}
        if max_p is not None:
            params_info['MAX_P'] = int(max_p)
        if max_q is not None:
            params_info['MAX_Q'] = int(max_q)
        results['params_used']['SARIMA'] = params_info
        try:
            _drop('#ARIMA_PARAM'); _drop('#ARIMA_MODEL'); _drop('#ARIMA_FIT')
            _sql("CREATE LOCAL TEMPORARY COLUMN TABLE #ARIMA_PARAM "
                 "(PARAM_NAME NVARCHAR(256), INT_VALUE INT, DOUBLE_VALUE DOUBLE, STRING_VALUE NVARCHAR(256))")
            cursor.execute("INSERT INTO #ARIMA_PARAM VALUES (?, ?, NULL, NULL)", ('SEASONAL_PERIOD', eff_seasonal))
            cursor.execute("INSERT INTO #ARIMA_PARAM VALUES (?, ?, NULL, NULL)", ('METHOD', method))
            cursor.execute("INSERT INTO #ARIMA_PARAM VALUES (?, NULL, ?, NULL)", ('THREAD_RATIO', thread_ratio))
            if max_p is not None:
                cursor.execute("INSERT INTO #ARIMA_PARAM VALUES (?, ?, NULL, NULL)", ('MAX_P', int(max_p)))
            if max_q is not None:
                cursor.execute("INSERT INTO #ARIMA_PARAM VALUES (?, ?, NULL, NULL)", ('MAX_Q', int(max_q)))
            _sql("CREATE LOCAL TEMPORARY COLUMN TABLE #ARIMA_MODEL (KEY NVARCHAR(256), VALUE NVARCHAR(5000))")
            _sql("CREATE LOCAL TEMPORARY COLUMN TABLE #ARIMA_FIT (TIME_ID INT, FITTED DOUBLE, RESIDUALS DOUBLE)")
            cursor.execute("""
DO BEGIN
    lt_data = SELECT TIME_ID, VEHICLECOUNT FROM #PAL_DATA;
    lt_param = SELECT PARAM_NAME, INT_VALUE, DOUBLE_VALUE, STRING_VALUE FROM #ARIMA_PARAM;
    CALL _SYS_AFL.PAL_AUTOARIMA(:lt_data, :lt_param, lt_model, lt_fit);
    INSERT INTO #ARIMA_MODEL SELECT * FROM :lt_model;
    INSERT INTO #ARIMA_FIT SELECT * FROM :lt_fit;
END;
""")
            _drop('#FC_DATA'); _drop('#FC_PARAM'); _drop('#FC_OUT')
            _sql("CREATE LOCAL TEMPORARY COLUMN TABLE #FC_DATA (TIME_ID INT, VEHICLECOUNT DOUBLE)")
            _sql("CREATE LOCAL TEMPORARY COLUMN TABLE #FC_PARAM "
                 "(PARAM_NAME NVARCHAR(256), INT_VALUE INT, DOUBLE_VALUE DOUBLE, STRING_VALUE NVARCHAR(256))")
            cursor.execute("INSERT INTO #FC_PARAM VALUES (?, ?, NULL, NULL)", ('FORECAST_LENGTH', total_forecast))
            cursor.execute("INSERT INTO #FC_PARAM VALUES (?, ?, NULL, NULL)", ('FORECAST_METHOD', fc_method))
            _sql("CREATE LOCAL TEMPORARY COLUMN TABLE #FC_OUT "
                 "(TIME_ID INT, FORECAST DOUBLE, SE DOUBLE, LO80 DOUBLE, HI80 DOUBLE, LO95 DOUBLE, HI95 DOUBLE)")
            cursor.execute("""
DO BEGIN
    lt_data = SELECT TIME_ID, VEHICLECOUNT FROM #FC_DATA;
    lt_model = SELECT KEY, VALUE FROM #ARIMA_MODEL;
    lt_param = SELECT PARAM_NAME, INT_VALUE, DOUBLE_VALUE, STRING_VALUE FROM #FC_PARAM;
    CALL _SYS_AFL.PAL_ARIMA_FORECAST(:lt_data, :lt_model, :lt_param, lt_result);
    INSERT INTO #FC_OUT SELECT * FROM :lt_result;
END;
""")
            cursor.execute("SELECT TIME_ID, FORECAST FROM #FC_OUT ORDER BY TIME_ID")
            arima_rows = cursor.fetchall()
            if arima_rows:
                forecasts['SARIMA_TEST'] = [max(0.0, float(r[1])) for r in arima_rows[:eff_test_months]]
                forecasts['SARIMA_FUTURE'] = [max(0.0, float(r[1])) for r in arima_rows[eff_test_months:eff_test_months + forecast_horizon]]
        except Exception as e:
            results['SARIMA_error'] = str(e)

    # ── BSTS ──
    if 'BSTS' in models_to_run:
        burn = float(bsts_params.get('burn', 0.5))
        niter = int(bsts_params.get('niter', 2000))
        seed = int(bsts_params.get('seed', 1))
        local_linear_trend = bsts_params.get('local_linear_trend', True)
        damped = bsts_params.get('damped', False)
        results['params_used']['BSTS'] = {
            'burn': burn, 'niter': niter,
            'seasonal_period': eff_seasonal, 'seed': seed,
            'local_linear_trend': local_linear_trend, 'damped': damped}
        try:
            if train_cutoff <= eff_seasonal:
                raise ValueError(f"Only {train_cutoff} training points, need > {eff_seasonal}")
            safe_key = key.replace("'", "''")
            hana_train = conn.sql(f"""
                SELECT TIME_ID AS "TIME_STAMP", CAST(VEHICLECOUNT AS DOUBLE) AS "TARGET"
                FROM "{schema}"."COMPOSITE_TIMESERIES"
                WHERE COMPOSITE_KEY='{safe_key}' AND TIME_ID<={train_cutoff}
                ORDER BY TIME_ID
            """)
            bsts_model = BSTS(burn=burn, niter=niter, seasonal_period=eff_seasonal, seed=seed,
                             local_linear_trend=local_linear_trend, damped=damped)
            bsts_model.fit(data=hana_train, key='TIME_STAMP', endog='TARGET')
            bsts_result = bsts_model.predict(horizon=total_forecast)
            bsts_fc_df = bsts_result[0].collect()
            bsts_all = []
            for _, row in bsts_fc_df.iterrows():
                offset = int(row['TIME_STAMP'])
                real_tid = train_cutoff + 1 + offset
                val = max(0.0, float(row['FORECAST']))
                bsts_all.append((real_tid, val))
            bsts_all.sort(key=lambda x: x[0])
            forecasts['BSTS_TEST'] = [v for tid, v in bsts_all if tid <= eff_end][:eff_test_months]
            forecasts['BSTS_FUTURE'] = [v for tid, v in bsts_all if tid > eff_end][:forecast_horizon]
        except Exception as e:
            results['BSTS_error'] = str(e)

    # ── Seasonal post-adjustment ──
    train_data = ts_df[ts_df['TIME_ID'] <= train_cutoff]
    monthly_means = train_data.groupby('PRODMONTH')['VEHICLECOUNT'].mean()
    overall_mean = train_data['VEHICLECOUNT'].mean()
    if overall_mean > 0 and len(monthly_means) >= 6:
        seasonal_indices = (monthly_means / overall_mean).to_dict()
        test_months_list = ts_df[
            (ts_df['TIME_ID'] > train_cutoff) & (ts_df['TIME_ID'] <= eff_end)
        ]['PRODMONTH'].tolist()
        _lr = ts_df[ts_df['TIME_ID'] == eff_end]
        _fs = (_lr.iloc[0]['PROD_DATE'] + pd.DateOffset(months=1)) if len(_lr) > 0 else (ts_df['PROD_DATE'].max() + pd.DateOffset(months=1))
        future_months_list = [str((_fs + pd.DateOffset(months=i)).month).zfill(2) for i in range(forecast_horizon)]
        for mp in models_to_run:
            for tk, ml in [(f'{mp}_TEST', test_months_list), (f'{mp}_FUTURE', future_months_list)]:
                if tk in forecasts:
                    forecasts[tk] = [max(0.0, v * seasonal_indices.get(
                        ml[i] if i < len(ml) else '01', 1.0)) for i, v in enumerate(forecasts[tk])]
        results['seasonal_indices'] = {k: round(v, 4) for k, v in seasonal_indices.items()}

    # ── Compute metrics ──
    def _mape(a, f):
        a, f = np.array(a, dtype=float), np.array(f, dtype=float)
        m = a > 0
        return round(float(np.mean(np.abs((a[m] - f[m]) / a[m])) * 100), 2) if m.sum() > 0 else None

    def _rmse(a, f):
        return round(float(np.sqrt(np.mean((np.array(a, dtype=float) - np.array(f, dtype=float)) ** 2))), 2)

    model_metrics = {}
    for mk in models_to_run:
        tk = f'{mk}_TEST'
        if tk in forecasts and test_actual:
            model_metrics[mk] = {
                'mape': _mape(test_actual, forecasts[tk]),
                'rmse': _rmse(test_actual, forecasts[tk]),
                'test_forecast': [round(v, 1) for v in forecasts[tk]],
                'future_forecast': [round(v, 1) for v in forecasts.get(f'{mk}_FUTURE', [])],
            }
    results['test_actual'] = test_actual
    results['models'] = model_metrics

    if model_metrics:
        best = min(model_metrics, key=lambda m: model_metrics[m]['mape'] or float('inf'))
        results['best_model'] = best

    # Clean up
    for t in ['#PAL_DATA', '#SES_PARAM', '#SES_OUT', '#SES_STATS',
              '#ARIMA_PARAM', '#ARIMA_MODEL', '#ARIMA_FIT',
              '#FC_DATA', '#FC_PARAM', '#FC_OUT']:
        _drop(t)
    conn.close()

    return jsonify(results)


if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    app.run(debug=os.environ.get('VCAP_SERVICES') is None, host='0.0.0.0', port=port)
