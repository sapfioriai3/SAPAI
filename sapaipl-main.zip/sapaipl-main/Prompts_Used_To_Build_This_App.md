# Prompts Used to Build This App

A record of the prompts and instructions given to  to build the Mercedes-Benz Accessory Demand Forecasting application from scratch — from raw CSV data to a deployed web app on SAP BTP.

---

## Phase 1 — Project Setup & Data Pipeline

### 1. Create the HANA schema and tables
> Set up an SAP HANA Cloud HDI container with tables for the accessory forecast data. Create the schema, design-time artifacts (.hdbtable files), and load the CSV data.

### 2. Load the CSV data into HANA
> Parse the "Accessory forecast AI feed.csv" file (33,674 rows) and batch-insert it into the ACCESSORY_FORECAST table in the HDI container.

### 3. Explore and profile the data
> Explore the data — identify how many ACCCODEs we have, the volume per code, the date range, and which codes have enough data to forecast.

### 4. Prepare per-ACCCODE monthly time series
> Build a monthly time series for each ACCCODE. Aggregate VEHICLECOUNT by ACCCODE + year + month, fill any missing months with zeros, and assign sequential TIME_IDs. Split into training (24 months) and test (5 months) sets.

### 5. Run forecast models using SAP PAL
> For each ACCCODE, run three forecasting models inside HANA using the Predictive Analysis Library (PAL): Simple Exponential Smoothing (SES), Holt-Winters (Triple Exponential Smoothing with CYCLE=12), and Seasonal ARIMA (Auto ARIMA with SEASONAL_PERIOD=12). Compute MAPE and RMSE for each, pick the best model, and store the results.

### 6. Compare models and generate predictions
> Compare the three models for each ACCCODE. Show which model wins, the MAPE for each, and generate the 6-month future forecast (Jul–Dec 2026) using the best model.

---

## Phase 2 — Flask Web Dashboard

### 7. Build a Flask dashboard
> Create a web dashboard using Flask that reads the forecast results from HANA and displays them. Include a dashboard page with summary KPIs, a models comparison page, a predictions page, and a detail page for each ACCCODE with a chart showing historical data and forecasts.

### 8. Add an upload page
> Add an upload page where users can upload a new CSV file and trigger the forecast pipeline to re-run.

---

## Phase 3 — Code Quality & Accuracy Improvements

### 9. Clean up print statements
> Remove all the print statements from the forecast pipeline scripts (04_forecast_models.py and 05_compare_and_predict.py).

### 10. Diagnose high MAPE values
> The MAPE values are too high (100%+). What's wrong? Can you diagnose why the predictions are so far off?

*Copilot diagnosed: limited data (~29 months), structural breaks, negative ARIMA predictions, and no seasonal baseline model.*

### 11. Add Seasonal Naive as a 4th model
> Add a Seasonal Naive model — just use the same month from last year as the prediction. This should be a strong baseline for seasonal data.

### 12. Clamp all predictions to zero or above
> Some SARIMA predictions are negative, which makes no sense for count data. Clamp all forecast values to be >= 0.

### 13. Fix table operations for HDI
> The HDI container user can't DROP or ALTER tables. Switch from DROP/CREATE to TRUNCATE + INSERT for storing results.

### 14. Compute Seasonal Naive on-the-fly
> Since we can't add a SNAIVE_FORECAST column to the existing HANA table (no ALTER privilege), compute the Seasonal Naive forecasts on-the-fly in the Flask app from the time series data.

*Result: Median MAPE improved from 58.3% → 45.8%. ACCCODEs with MAPE ≥ 100% dropped from 9 → 6.*

---

## Phase 4 — Deployment to Cloud Foundry

### 15. Deploy the app
> LET'S DEPLOY.

*Copilot created requirements.txt, runtime.txt, Procfile, .cfignore, updated mta.yaml and app.py for Cloud Foundry, built the MTA archive, and deployed to BTP.*

### 16. Fix data not showing on deployed app
> NOT SHOWING DATA.

*Copilot diagnosed: the MTA deployment created a new empty HDI container. The app was connecting to the wrong schema. Fixed by setting HANA_* environment variables on the CF app pointing to the original schema with data, and updating the connection logic to prefer explicit env vars over VCAP_SERVICES.*

---

## Phase 5 — UI Polish & Documentation

### 17. Remove the MAPE interpretation legend
> Remove the MAPE interpretation showing "< 5% Excellent, 5-10% Good, 10-20% Fair, > 20% Poor" — my numbers don't look good with that scale showing.

### 18. Redesign the dashboard for end users
> On the dashboard, instead of showing model win counts and the doughnut chart and all the MAPE columns — explain what this app does. Make it end-user friendly. This is for a demo. Show how we did it but keep it simple — Collect Data, AI Analyzes, Best Model Wins, Forecast Generated. Simplify the table to just show the accessory code, volume, best model, and accuracy.

### 19. Update the Prediction Guide document
> Update the Accessory Forecast Prediction Guide — write it like a developer narrative explaining what we're doing, how the predictions work, the technical details, what affects accuracy with limited data, and what can be done to improve it. Create a comprehensive document.

### 20. Delete the redundant HDI service
> sapai-pl-db is redundant — we created two different schemas. Double check it's not used and delete it.

---

## Summary

| Metric | Value |
|--------|-------|
| **Total prompts** | ~20 |
| **Build time** | 2 days (Mar 17–18, 2026) |
| **Lines of code generated** | ~2,500+ |
| **Files created** | 25+ (Python, HTML, SQL, YAML, JSON, Markdown) |
| **Models implemented** | 4 (SES, Holt-Winters, SARIMA, Seasonal Naive) |
| **ACCCODEs forecasted** | 36 |
| **Deployed to** | SAP BTP Cloud Foundry |

### Tech Stack
- **Database:** SAP HANA Cloud (HDI Container)
- **ML Engine:** SAP PAL (Predictive Analysis Library) — runs inside HANA
- **Backend:** Python, Flask, hana-ml, pandas, numpy
- **Frontend:** Jinja2 templates, Chart.js, SAP-inspired CSS
- **Deployment:** MTA build, Cloud Foundry (Python buildpack)

