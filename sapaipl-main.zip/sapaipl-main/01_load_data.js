/**
 * ============================================================================
 * STEP 01: LOAD CSV DATA INTO SAP HANA CLOUD (HDI Container)
 * ============================================================================
 *
 * WHAT THIS DOES:
 *   1. Connects to SAP HANA Cloud HDI container via hdb driver
 *   2. Truncates existing ACCESSORY_FORECAST table (created by HDI deployer)
 *   3. Parses "Accessory forecast AI feed.csv" (handles quoted fields)
 *   4. Batch-inserts all 33,674 rows into the table
 *
 * HDI CONTEXT:
 *   The ACCESSORY_FORECAST table is defined as an HDI design-time artifact
 *   (db/src/ACCESSORY_FORECAST.hdbtable) and created automatically by the
 *   HDI deployer. The hdbtabledata artifact (db/src/data/) can also auto-load
 *   the CSV on deployment. This script is useful for:
 *     - Re-loading data after updates to the CSV
 *     - Loading data in environments where HDI deploy hasn't run
 *     - Runtime data refresh
 *
 * PREREQUISITES:
 *   - .env file with HANA_HOST, HANA_PORT, HANA_USER, HANA_PASSWORD
 *     (HDI container runtime credentials from service key)
 *   - npm install hdb dotenv
 *
 * RUN:
 *   node 01_load_data.js
 * ============================================================================
 */

require('dotenv').config();
const hdb = require('hdb');
const fs = require('fs');
const path = require('path');

const connParams = {
  host: process.env.HANA_HOST,
  port: parseInt(process.env.HANA_PORT),
  user: process.env.HANA_USER,
  password: process.env.HANA_PASSWORD,
  useTLS: true
};

const client = hdb.createClient(connParams);

function execSQL(sql) {
  return new Promise((resolve, reject) => {
    client.exec(sql, (err, rows) => {
      if (err) reject(err);
      else resolve(rows);
    });
  });
}

/**
 * Parse a CSV line handling quoted fields (e.g., "1,098" stays as one field)
 */
function parseCSVLine(line) {
  const result = [];
  let current = '';
  let inQuotes = false;
  for (let i = 0; i < line.length; i++) {
    const ch = line[i];
    if (ch === '"') { inQuotes = !inQuotes; }
    else if (ch === ',' && !inQuotes) { result.push(current.trim()); current = ''; }
    else { current += ch; }
  }
  result.push(current.trim());
  return result;
}

async function run() {
  // ─── Connect ───
  await new Promise((resolve, reject) => {
    client.connect((err) => {
      if (err) { reject(err); return; }
      resolve();
    });
  });

  // Set schema to HDI container schema (RT user's default schema differs)
  if (process.env.HANA_SCHEMA) {
    await execSQL(`SET SCHEMA ${process.env.HANA_SCHEMA}`);
  }

  const info = await execSQL('SELECT CURRENT_USER, CURRENT_SCHEMA FROM DUMMY');
  console.log(`Connected to HANA Cloud (HDI Container)`);
  console.log(`  User:   ${info[0].CURRENT_USER}`);
  console.log(`  Schema: ${info[0].CURRENT_SCHEMA}\n`);

  // ─── Truncate table (created by HDI deployer) ───
  try {
    await execSQL('TRUNCATE TABLE ACCESSORY_FORECAST');
    console.log('Truncated ACCESSORY_FORECAST table');
  } catch (e) {
    // Table might not exist if HDI deploy hasn't run — create as fallback
    console.log('Table not found — creating ACCESSORY_FORECAST (HDI deploy may not have run)');
    await execSQL(`
      CREATE COLUMN TABLE ACCESSORY_FORECAST (
        CLASS        NVARCHAR(10)   NOT NULL,
        MODEL        NVARCHAR(20)   NOT NULL,
        MODEL_YEAR   INTEGER        NOT NULL,
        BAUMUSTER    NVARCHAR(10)   NOT NULL,
        VPC_LOCATION INTEGER,
        ACCCODE      NVARCHAR(10)   NOT NULL,
        PRODYEAR     INTEGER        NOT NULL,
        PRODMONTH    NVARCHAR(2)    NOT NULL,
        VEHICLECOUNT INTEGER        NOT NULL
      )
    `);
  }

  // ─── Parse CSV ───
  const csvFile = path.join(__dirname, 'Accessory forecast AI feed.csv');
  const rawText = fs.readFileSync(csvFile, 'utf8');
  const lines = rawText.split('\n');

  const dataRows = [];
  for (let i = 1; i < lines.length; i++) {
    const line = lines[i].trim();
    if (!line) continue;
    const cols = parseCSVLine(line);
    if (!cols[0]) continue;

    dataRows.push([
      cols[0],                            // CLASS
      cols[1],                            // MODEL
      parseInt(cols[2]),                   // MODEL_YEAR
      cols[3],                            // BAUMUSTER
      parseInt(cols[4]),                   // VPC_LOCATION
      cols[5],                            // ACCCODE
      parseInt(cols[6]),                   // PRODYEAR
      cols[7],                            // PRODMONTH
      parseInt(cols[8].replace(/,/g, '')) // VEHICLECOUNT (remove commas)
    ]);
  }
  console.log(`Parsed ${dataRows.length} rows from CSV`);

  // ─── Batch insert (1000 rows per batch) ───
  const BATCH_SIZE = 1000;
  let inserted = 0;

  for (let start = 0; start < dataRows.length; start += BATCH_SIZE) {
    const batch = dataRows.slice(start, start + BATCH_SIZE);
    const values = batch.map(r =>
      `('${r[0]}','${r[1]}',${r[2]},'${r[3]}',${r[4]},'${r[5]}',${r[6]},'${r[7]}',${r[8]})`
    ).join(',\n');

    await execSQL(`
      INSERT INTO ACCESSORY_FORECAST
        (CLASS, MODEL, MODEL_YEAR, BAUMUSTER, VPC_LOCATION, ACCCODE, PRODYEAR, PRODMONTH, VEHICLECOUNT)
      VALUES ${values}
    `);
    inserted += batch.length;
    process.stdout.write(`\r  Inserted ${inserted} / ${dataRows.length} rows`);
  }

  console.log('\n');

  // ─── Verify ───
  const count = await execSQL('SELECT COUNT(*) AS N FROM ACCESSORY_FORECAST');
  console.log(`Verification: ${count[0].N} rows in ACCESSORY_FORECAST`);

  const sample = await execSQL('SELECT * FROM ACCESSORY_FORECAST LIMIT 5');
  console.log('\nSample rows:');
  console.table(sample);

  console.log('\n✓ Step 01 complete. Data loaded successfully.');
  client.end();
}

run().catch(err => {
  console.error('Error:', err.message || err);
  client.end();
  process.exit(1);
});
