"""
============================================================================
STEP 03C: PREPARE COMPOSITE TIME SERIES (ACCCODE + VPC/Location + Model)
============================================================================

WHAT THIS DOES:
  1. Aggregates raw data into monthly totals PER (ACCCODE, VPC_LOCATION, MODEL)
  2. Builds a COMPOSITE_KEY = "ACCCODE|VPC_LOCATION|MODEL" for each combo
  3. Fills missing months with 0 (important for time series continuity)
  4. Assigns sequential TIME_ID per COMPOSITE_KEY
  5. Stores results in COMPOSITE_TIMESERIES table in HANA
  6. Creates PAL_COMPOSITE_TRAINING table (training subset)

WHY COMPOSITE KEY:
  Grouping by ACCCODE alone (~1200 series) may lose important patterns
  related to VPC/Location and vehicle Model. By using the composite key
  (ACCCODE + VPC_LOCATION + MODEL), we get more granular series that
  better capture location- and model-specific demand patterns.

RUN:
  python 03c_prepare_composite_timeseries.py

PREREQUISITES:
  pip install hana-ml pandas python-dotenv
============================================================================
"""

import os, json
from dotenv import load_dotenv
load_dotenv()
import pandas as pd
import numpy as np
from hana_ml.dataframe import ConnectionContext


def _hana_creds():
    if os.environ.get('HANA_HOST'):
        return {
            'host': os.environ['HANA_HOST'],
            'port': int(os.environ['HANA_PORT']),
            'user': os.environ['HANA_USER'],
            'password': os.environ['HANA_PASSWORD'],
            'schema': os.environ.get('HANA_SCHEMA', ''),
        }
    vcap = os.environ.get('VCAP_SERVICES')
    if vcap:
        svc = json.loads(vcap)
        hana = svc.get('hana', [{}])[0].get('credentials', {})
        return {
            'host': hana['host'],
            'port': int(hana['port']),
            'user': hana['user'],
            'password': hana['password'],
            'schema': hana.get('schema', ''),
        }
    raise RuntimeError('No HANA credentials found')


# ─── Connect ───
print("Connecting to HANA Cloud...")
creds = _hana_creds()
conn = ConnectionContext(
    address=creds['host'],
    port=creds['port'],
    user=creds['user'],
    password=creds['password'],
    encrypt=True
)
cursor = conn.connection.cursor()
if creds['schema']:
    cursor.execute('SET SCHEMA "{}"'.format(creds['schema'].replace('"', '""')))
print(f"Connected. Schema: {creds['schema'] or 'default'}\n")

# ─── Demo filter: only these ACCCODEs and MODELs ───
DEMO_ACCCODES = ['D10', 'D11', 'D43', 'D45', 'D56', 'D53', 'D26', 'D07', 'D49']
DEMO_MODELS = [
    'GLE350W', 'GLE350W4', 'GLE450C4', 'GLE450E4', 'GLE450W4',
    'GLE53C4', 'GLE53W4', 'GLE580W4', 'GLE63C4S', 'GLE63W4S',
    'GLS450W4', 'GLS580W4', 'GLS600Z4', 'GLS63W4',
    'C300W', 'C300W4', 'E350W', 'E350W4', 'E450S4',
]

# ─── Load raw data ───
df = conn.table('ACCESSORY_FORECAST').collect()
print(f"Raw data: {len(df):,} rows")

# ── Filter to demo ACCCODEs and MODELs ──
df['MODEL'] = df['MODEL'].fillna('UNKNOWN').astype(str).str.strip()
df = df[df['ACCCODE'].isin(DEMO_ACCCODES) & df['MODEL'].isin(DEMO_MODELS)].copy()
print(f"After demo filter (ACCCODEs={len(DEMO_ACCCODES)}, MODELs={len(DEMO_MODELS)}): {len(df):,} rows")

# ── Drop future data: only keep up to Feb 2026 ──
df['PRODMONTH'] = df['PRODMONTH'].astype(str).str.zfill(2)
df['PRODYEAR'] = df['PRODYEAR'].astype(int)
before = len(df)
df = df[~((df['PRODYEAR'] == 2026) & (df['PRODMONTH'] >= '03'))].copy()
df = df[df['PRODYEAR'] <= 2026].copy()
print(f"After dropping 2026-Mar+ data: {len(df):,} rows (removed {before - len(df):,})")

# ── Drop all 2021 data (unreliable / COVID distortion) ──
before = len(df)
df = df[df['PRODYEAR'] != 2021].copy()
print(f"After dropping 2021 data: {len(df):,} rows (removed {before - len(df):,})\n")

# ═══════════════════════════════════════════════════════════════════
# STEP 3A: AGGREGATE BY ACCCODE + VPC_LOCATION + MODEL + MONTH
# ═══════════════════════════════════════════════════════════════════
print("═" * 65)
print("  Step 3A: Aggregate by ACCCODE + VPC_LOCATION + MODEL + Month")
print("═" * 65)

# Build composite key
df['VPC_LOCATION'] = df['VPC_LOCATION'].fillna(0).astype(int)
df['MODEL'] = df['MODEL'].fillna('UNKNOWN').astype(str).str.strip()

monthly = (
    df.groupby(['ACCCODE', 'VPC_LOCATION', 'MODEL', 'PRODYEAR', 'PRODMONTH'])
    ['VEHICLECOUNT'].sum()
    .reset_index()
)
monthly['PRODMONTH'] = monthly['PRODMONTH'].str.zfill(2)
monthly['COMPOSITE_KEY'] = (
    monthly['ACCCODE'].astype(str) + '|' +
    monthly['VPC_LOCATION'].astype(str) + '|' +
    monthly['MODEL'].astype(str)
)
print(f"  Aggregated to {len(monthly):,} composite-month combinations")

# ═══════════════════════════════════════════════════════════════════
# STEP 3B: BUILD COMPLETE MONTHLY GRID (fill gaps with 0)
# ═══════════════════════════════════════════════════════════════════
print(f"\n{'═' * 65}")
print("  Step 3B: Fill missing months with zero")
print("═" * 65)

# Determine full date range from data
all_periods = sorted(monthly[['PRODYEAR', 'PRODMONTH']].drop_duplicates().values.tolist())
all_composite_keys = sorted(monthly['COMPOSITE_KEY'].unique())

# Filter: only composite keys with 12+ months of non-zero data
key_months = monthly.groupby('COMPOSITE_KEY')['PRODYEAR'].count()
forecastable_keys = key_months[key_months >= 12].index.tolist()
print(f"  Total composite keys: {len(all_composite_keys)}")
print(f"  Forecastable (12+ months of data): {len(forecastable_keys)}")
print(f"  Excluded (< 12 months): {len(all_composite_keys) - len(forecastable_keys)}")

# Build lookup for original fields from composite key
key_parts = {}
for key in forecastable_keys:
    parts = key.split('|', 2)
    key_parts[key] = {
        'ACCCODE': parts[0],
        'VPC_LOCATION': int(parts[1]),
        'MODEL': parts[2],
    }

# Build complete grid for forecastable composite keys using pivot/reindex
# Create a pivot of existing data
monthly_fcast = monthly[monthly['COMPOSITE_KEY'].isin(forecastable_keys)].copy()
monthly_fcast['PERIOD'] = monthly_fcast['PRODYEAR'].astype(str) + '-' + monthly_fcast['PRODMONTH']
period_labels = [f"{y}-{m}" for y, m in all_periods]

pivot = monthly_fcast.pivot_table(
    index='COMPOSITE_KEY', columns='PERIOD', values='VEHICLECOUNT',
    aggfunc='sum', fill_value=0
)
# Reindex to include all periods, fill missing with 0
pivot = pivot.reindex(columns=period_labels, fill_value=0)

# Melt back to long form
ts_long = pivot.reset_index().melt(
    id_vars='COMPOSITE_KEY', var_name='PERIOD', value_name='VEHICLECOUNT'
)
ts_long['PRODYEAR'] = ts_long['PERIOD'].str.split('-').str[0].astype(int)
ts_long['PRODMONTH'] = ts_long['PERIOD'].str.split('-').str[1]
ts_long['PROD_DATE'] = ts_long['PRODYEAR'].astype(str) + '-' + ts_long['PRODMONTH'] + '-01'
ts_long = ts_long.sort_values(['COMPOSITE_KEY', 'PRODYEAR', 'PRODMONTH']).reset_index(drop=True)
ts_long['TIME_ID'] = ts_long.groupby('COMPOSITE_KEY').cumcount() + 1

# Add original fields from composite key
ts_long['ACCCODE'] = ts_long['COMPOSITE_KEY'].str.split('|').str[0]
ts_long['VPC_LOCATION'] = ts_long['COMPOSITE_KEY'].str.split('|').str[1].astype(int)
ts_long['MODEL'] = ts_long['COMPOSITE_KEY'].str.split('|').str[2]

ts_df = ts_long[['ACCCODE', 'VPC_LOCATION', 'MODEL', 'COMPOSITE_KEY', 'TIME_ID',
                  'PROD_DATE', 'PRODYEAR', 'PRODMONTH', 'VEHICLECOUNT']].copy()
ts_df['VEHICLECOUNT'] = ts_df['VEHICLECOUNT'].astype(int)
print(f"\n  Complete time series grid: {len(ts_df):,} rows")
print(f"  ({len(forecastable_keys)} composite keys × {len(all_periods)} months)")

# ═══════════════════════════════════════════════════════════════════
# STEP 3B2: DROP LEADING ZERO MONTHS (per composite key)
# ═══════════════════════════════════════════════════════════════════
print(f"\n{'═' * 65}")
print("  Step 3B2: Drop Leading Zero Months (per composite key)")
print("═" * 65)
print("""
  WHY: Many composite keys have months of zero production at the start
  (before the accessory/location/model combo was active). Keeping them
  distorts the model. Drop them and re-assign sequential TIME_IDs.
""")

leading_zeros_dropped = 0
keys_with_leading_zeros = 0

for comp_key in forecastable_keys:
    key_mask = ts_df['COMPOSITE_KEY'] == comp_key
    key_data = ts_df[key_mask].sort_values('TIME_ID')
    vals = key_data['VEHICLECOUNT'].values

    n_leading = 0
    for v in vals:
        if v == 0:
            n_leading += 1
        else:
            break

    if n_leading > 0:
        drop_indices = key_data.iloc[:n_leading].index
        ts_df = ts_df.drop(drop_indices)

        remaining = ts_df[ts_df['COMPOSITE_KEY'] == comp_key].sort_values('TIME_ID').index
        for new_tid, idx in enumerate(remaining, start=1):
            ts_df.loc[idx, 'TIME_ID'] = new_tid

        leading_zeros_dropped += n_leading
        keys_with_leading_zeros += 1

print(f"  Leading zeros dropped: {leading_zeros_dropped} months across {keys_with_leading_zeros} composite keys")

# Remove composite keys that now have too few data points (< 12)
key_counts = ts_df.groupby('COMPOSITE_KEY')['TIME_ID'].count()
short_keys = key_counts[key_counts < 12].index.tolist()
if short_keys:
    ts_df = ts_df[~ts_df['COMPOSITE_KEY'].isin(short_keys)]
    forecastable_keys = [k for k in forecastable_keys if k not in short_keys]
    print(f"  Removed {len(short_keys)} composite keys now below 12 months after trimming")

print(f"  Remaining forecastable keys: {len(forecastable_keys)}")

# ═══════════════════════════════════════════════════════════════════
# STEP 3B3: EARLY-PERIOD TRIMMING (Ramp-up Removal)
# ═══════════════════════════════════════════════════════════════════
print(f"\n{'═' * 65}")
print("  Step 3B3: Early-Period Trimming (Ramp-up Removal)")
print("═" * 65)
print("""
  WHY: Initial months may have abnormally low production (ramp-up).
  Months where 3-month rolling average is < 20% of series average
  are trimmed from the start of each composite series.
""")

trimmed_keys = 0
total_months_trimmed = 0

for comp_key in forecastable_keys:
    key_mask = ts_df['COMPOSITE_KEY'] == comp_key
    key_data = ts_df[key_mask].sort_values('TIME_ID')
    nonzero_vals = key_data[key_data['VEHICLECOUNT'] > 0]['VEHICLECOUNT']

    if len(nonzero_vals) < 6:
        continue

    series_avg = nonzero_vals.mean()
    threshold = series_avg * 0.20
    vals = key_data['VEHICLECOUNT'].values

    trim_to = 0
    for i in range(len(vals) - 2):
        rolling_avg = np.mean(vals[i:i+3])
        if rolling_avg >= threshold:
            trim_to = i
            break
    else:
        trim_to = 0

    if trim_to > 0:
        trim_indices = key_data.iloc[:trim_to].index
        ts_df = ts_df.drop(trim_indices)

        remaining = ts_df[ts_df['COMPOSITE_KEY'] == comp_key].sort_values('TIME_ID').index
        for new_tid, idx in enumerate(remaining, start=1):
            ts_df.loc[idx, 'TIME_ID'] = new_tid

        trimmed_keys += 1
        total_months_trimmed += trim_to

print(f"  Composite keys trimmed: {trimmed_keys} / {len(forecastable_keys)}")
print(f"  Total months trimmed: {total_months_trimmed}")

# Remove composite keys that now have too few data points (< 12)
key_counts = ts_df.groupby('COMPOSITE_KEY')['TIME_ID'].count()
short_keys = key_counts[key_counts < 12].index.tolist()
if short_keys:
    ts_df = ts_df[~ts_df['COMPOSITE_KEY'].isin(short_keys)]
    forecastable_keys = [k for k in forecastable_keys if k not in short_keys]
    print(f"  Removed {len(short_keys)} composite keys now below 12 months after ramp-up trimming")

# ═══════════════════════════════════════════════════════════════════
# STEP 3B4: IQR-BASED OUTLIER DETECTION & SEASONAL INTERPOLATION
#   Only applied to TRAINING months (excludes last 5 per key)
# ═══════════════════════════════════════════════════════════════════
print(f"\n{'═' * 65}")
print("  Step 3B4: IQR Outlier Detection (training months only)")
print("═" * 65)
print("""
  WHY: IQR method flags statistical outliers in training data.
  Flagged values are replaced with same-month seasonal averages.
  Test period (last 5 months per key) is left untouched.
""")

iqr_total_outliers = 0
iqr_corrected_keys = 0

for comp_key in forecastable_keys:
    key_mask = ts_df['COMPOSITE_KEY'] == comp_key
    key_data = ts_df[key_mask].sort_values('TIME_ID').copy()
    max_tid = int(key_data['TIME_ID'].max())
    train_limit = max_tid - 5

    if train_limit < 6:
        continue

    train_data = key_data[key_data['TIME_ID'] <= train_limit]
    nonzero_vals = train_data[train_data['VEHICLECOUNT'] > 0]['VEHICLECOUNT']

    if len(nonzero_vals) < 4:
        continue

    avg_volume = nonzero_vals.mean()
    q1 = nonzero_vals.quantile(0.25)
    q3 = nonzero_vals.quantile(0.75)
    iqr = q3 - q1
    lower_bound = max(0, q1 - 1.5 * iqr)
    upper_bound = q3 + 1.5 * iqr

    code_outlier_count = 0

    for idx_row in train_data.index:
        row = ts_df.loc[idx_row]
        val = row['VEHICLECOUNT']
        tid = int(row['TIME_ID'])
        month = row['PRODMONTH']
        is_outlier = False

        if val == 0 and avg_volume > 50:
            is_outlier = True
        elif val < lower_bound or val > upper_bound:
            is_outlier = True

        if is_outlier:
            same_month = train_data[
                (train_data['PRODMONTH'] == month) &
                (train_data['VEHICLECOUNT'] > lower_bound) &
                (train_data['VEHICLECOUNT'] <= upper_bound)
            ]['VEHICLECOUNT']

            if len(same_month) > 0:
                replacement = int(round(same_month.mean()))
            else:
                neighbors = train_data[
                    (train_data['TIME_ID'] >= tid - 2) &
                    (train_data['TIME_ID'] <= tid + 2) &
                    (train_data['TIME_ID'] != tid) &
                    (train_data['VEHICLECOUNT'] > 0)
                ]['VEHICLECOUNT']
                replacement = int(round(neighbors.mean())) if len(neighbors) > 0 else int(round(avg_volume))

            replacement = max(0, replacement)
            ts_df.loc[idx_row, 'VEHICLECOUNT'] = replacement
            code_outlier_count += 1

    if code_outlier_count > 0:
        iqr_total_outliers += code_outlier_count
        iqr_corrected_keys += 1

print(f"  IQR outliers detected and corrected: {iqr_total_outliers}")
print(f"  Composite keys with IQR corrections: {iqr_corrected_keys} / {len(forecastable_keys)}")

print(f"\n  Final dataset: {len(ts_df):,} rows, {len(forecastable_keys)} composite keys")

# ═══════════════════════════════════════════════════════════════════
# STEP 3C: STORE IN HANA
# ═══════════════════════════════════════════════════════════════════
print(f"\n{'═' * 65}")
print("  Step 3C: Store composite time series in HANA Cloud")
print("═" * 65)

# Truncate COMPOSITE_TIMESERIES (table created by HDI deployer)
try:
    cursor.execute('TRUNCATE TABLE COMPOSITE_TIMESERIES')
except:
    cursor.execute("""
        CREATE COLUMN TABLE COMPOSITE_TIMESERIES (
            ACCCODE        NVARCHAR(10)  NOT NULL,
            VPC_LOCATION   INTEGER       NOT NULL,
            MODEL          NVARCHAR(20)  NOT NULL,
            COMPOSITE_KEY  NVARCHAR(50)  NOT NULL,
            TIME_ID        INTEGER       NOT NULL,
            PROD_DATE      DATE          NOT NULL,
            PRODYEAR       INTEGER       NOT NULL,
            PRODMONTH      NVARCHAR(2)   NOT NULL,
            VEHICLECOUNT   INTEGER       NOT NULL,
            PRIMARY KEY (COMPOSITE_KEY, TIME_ID)
        )
    """)

# Batch insert using executemany for speed
BATCH = 5000
insert_sql = "INSERT INTO COMPOSITE_TIMESERIES VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)"
for i in range(0, len(ts_df), BATCH):
    batch = ts_df.iloc[i:i+BATCH]
    rows = [(r.ACCCODE, int(r.VPC_LOCATION), r.MODEL, r.COMPOSITE_KEY,
             int(r.TIME_ID), str(r.PROD_DATE), int(r.PRODYEAR), r.PRODMONTH,
             int(r.VEHICLECOUNT)) for r in batch.itertuples()]
    cursor.executemany(insert_sql, rows)
    print(f"    Inserted {min(i+BATCH, len(ts_df)):,}/{len(ts_df):,} rows...")

print(f"  Inserted {len(ts_df):,} rows into COMPOSITE_TIMESERIES")

# ═══════════════════════════════════════════════════════════════════
# STEP 3D: CREATE TRAINING DATA (exclude last 5 months for testing)
# ═══════════════════════════════════════════════════════════════════
print(f"\n{'═' * 65}")
print("  Step 3D: Create training / test split")
print("═" * 65)

n_periods = len(all_periods)
train_cutoff = n_periods - 5
print(f"""
  CONCEPT: Train/Test Split
  ─────────────────────────────────────
  Total months:    {n_periods}
  Training months: {train_cutoff} (months 1-{train_cutoff})
  Test months:     5 (months {train_cutoff+1}-{n_periods})
""")

# Truncate PAL_COMPOSITE_TRAINING
try:
    cursor.execute('TRUNCATE TABLE PAL_COMPOSITE_TRAINING')
except:
    cursor.execute("""
        CREATE COLUMN TABLE PAL_COMPOSITE_TRAINING (
            COMPOSITE_KEY  NVARCHAR(50)  NOT NULL,
            TIME_ID        INTEGER       NOT NULL,
            VEHICLECOUNT   DOUBLE        NOT NULL,
            PRIMARY KEY (COMPOSITE_KEY, TIME_ID)
        )
    """)

cursor.execute(f"""
    INSERT INTO PAL_COMPOSITE_TRAINING
    SELECT COMPOSITE_KEY, TIME_ID, CAST(VEHICLECOUNT AS DOUBLE)
    FROM COMPOSITE_TIMESERIES
    WHERE TIME_ID <= {train_cutoff}
""")

train_count = conn.sql('SELECT COUNT(*) AS N FROM PAL_COMPOSITE_TRAINING').collect().iloc[0, 0]
print(f"  Training rows (all composite keys combined): {train_count:,}")

# ═══════════════════════════════════════════════════════════════════
# STEP 3E: PREVIEW TIME SERIES FOR TOP COMPOSITE KEYS
# ═══════════════════════════════════════════════════════════════════
print(f"\n{'═' * 65}")
print("  Step 3E: Time Series Preview (Top 5 Composite Keys)")
print("═" * 65)

top_keys = (
    ts_df.groupby('COMPOSITE_KEY')['VEHICLECOUNT'].sum()
    .sort_values(ascending=False)
    .head(5).index.tolist()
)

for comp_key in top_keys:
    key_ts = ts_df[ts_df['COMPOSITE_KEY'] == comp_key].sort_values('TIME_ID')
    total = key_ts['VEHICLECOUNT'].sum()
    avg = key_ts['VEHICLECOUNT'].mean()
    print(f"\n  Key: {comp_key}  (Total: {total:,}  Avg/month: {avg:,.0f})")

# ─── Done ───
conn.close()
print(f"\n{'═' * 65}")
print(f"  DONE: Composite time series prepared for {len(forecastable_keys)} keys")
print(f"{'═' * 65}")
