# Mercedes-Benz Accessory Demand Forecasting — Technical Reference Guide

> **Document Type:** Technical Reference  
> **Audience:** Developers, Data Engineers, SAP BTP Architects  
> **Last Updated:** March 19, 2026  
> **Live URL:** `https://daimler-ag---cpea-tst-mbusa-voisv-swt-devspace-sapai-pl-app.cfapps.us10.hana.ondemand.com`

---

## Table of Contents

1. [Executive Summary](#1-executive-summary)
2. [Architecture Overview](#2-architecture-overview)
3. [Data Pipeline — Step by Step](#3-data-pipeline--step-by-step)
4. [Forecasting Models — Technical Deep Dive](#4-forecasting-models--technical-deep-dive)
5. [AutoML Investigation & Why BSTS Was Chosen](#5-automl-investigation--why-bsts-was-chosen)
6. [Parameter Tuning Journey](#6-parameter-tuning-journey)
7. [Composite Key Forecasting](#7-composite-key-forecasting)
8. [Model Selection & Accuracy Metrics](#8-model-selection--accuracy-metrics)
9. [Web Dashboard (app.py)](#9-web-dashboard-apppy)
10. [HANA Tables Reference](#10-hana-tables-reference)
11. [Deployment Architecture](#11-deployment-architecture)
12. [Useful SQL Queries](#12-useful-sql-queries)
13. [Glossary](#13-glossary)

---

## 1. Executive Summary

This application predicts **how many of each vehicle accessory Mercedes-Benz USA will need over the next 12 months**. It answers:

> *"How many units of accessory D07 should we plan for in August 2026?"*

```
┌─────────────────────────────────────────────────────────────────────────┐
│                     WHAT THE SYSTEM DOES                                │
│                                                                         │
│   33,674 production records                                             │
│         │                                                               │
│         ▼                                                               │
│   ┌───────────────┐    ┌───────────────┐    ┌───────────────────────┐   │
│   │ 40 ACCCODE    │───▶│ 3 ML Models   │───▶│ 12-Month Predictions  │   │
│   │ Time Series   │    │ per ACCCODE   │    │ (Jun 2026–May 2027)   │   │
│   └───────────────┘    └───────────────┘    └───────────────────────┘   │
│                                                                         │
│   + 594 Composite Key series (ACCCODE + VPC + Model)                    │
│                                                                         │
│   Best model auto-selected per series based on lowest MAPE              │
└─────────────────────────────────────────────────────────────────────────┘
```

### Key Numbers

| Metric | Value |
|--------|-------|
| Raw production records | 33,674 |
| Distinct accessory codes (ACCCODEs) | 40 |
| Composite keys (ACCCODE + VPC + Model) | 594 |
| Forecast horizon | 12 months |
| Models evaluated per series | 3 (SES, SARIMA, BSTS) |
| Test holdout period | 5 months |
| Training period | ~24 months |
| Data range | Jan 2024 – May 2026 |

---

## 2. Architecture Overview

```
┌──────────────────────────────────────────────────────────────────────────────┐
│                      SAP Business Technology Platform (BTP)                   │
│                                                                              │
│  ┌─────────────────────────────┐      ┌────────────────────────────────────┐ │
│  │   Cloud Foundry App         │      │   SAP HANA Cloud                   │ │
│  │   (sapai-pl-app)            │      │   HDI Container                    │ │
│  │                             │      │   Schema: 6C713BB0896349DC...      │ │
│  │   Flask + Python 3.12       │◄────▶│                                    │ │
│  │   Memory: 512 MB            │ TLS  │   ┌──────────────────────────────┐ │ │
│  │                             │      │   │  ACCESSORY_FORECAST          │ │ │
│  │   Routes:                   │      │   │  33,674 raw records          │ │ │
│  │    /                        │      │   ├──────────────────────────────┤ │ │
│  │    /acccode/<code>          │      │   │  ACCCODE_TIMESERIES          │ │ │
│  │    /composite_predictions   │      │   │  Monthly series (40 codes)   │ │ │
│  │    /composite/<key>         │      │   ├──────────────────────────────┤ │ │
│  │    /api/search              │      │   │  ACCCODE_FORECAST_RESULTS    │ │ │
│  │    /api/debug               │      │   │  Test + future forecasts     │ │ │
│  │                             │      │   ├──────────────────────────────┤ │ │
│  │   Chart.js visualizations   │      │   │  ACCCODE_MODEL_COMPARISON    │ │ │
│  │   Jinja2 templates          │      │   │  MAPE/RMSE per model         │ │ │
│  └─────────────────────────────┘      │   ├──────────────────────────────┤ │ │
│                                       │   │  COMPOSITE_TIMESERIES        │ │ │
│  ┌─────────────────────────────┐      │   │  COMPOSITE_FORECAST_RESULTS  │ │ │
│  │   HDI Deployer              │      │   │  COMPOSITE_MODEL_COMPARISON  │ │ │
│  │   (sapai-pl-db)             │─────▶│   ├──────────────────────────────┤ │ │
│  │   Node.js + @sap/hdi-deploy│      │   │  PAL Engine (Script Server)  │ │ │
│  └─────────────────────────────┘      │   │  _SYS_AFL.PAL_*             │ │ │
│                                       │   └──────────────────────────────┘ │ │
│                                       └────────────────────────────────────┘ │
└──────────────────────────────────────────────────────────────────────────────┘
```

### How PAL Runs Inside HANA (Key Architecture Point)

**The ML models do NOT run in Python.** Python orchestrates by sending SQL to HANA. The actual training and prediction execute inside HANA's PAL engine using compiled C++ code:

```
┌──────────┐    SQL calls     ┌───────────┐    PAL C++ engine    ┌──────────┐
│  Python  │ ────────────────▶│   HANA    │ ──────────────────▶  │  Results │
│  Script  │    (hana_ml)     │  Database │    (Script Server)   │  Tables  │
└──────────┘                  └───────────┘                      └──────────┘
```

This means forecasting scales to millions of rows without moving data out of the database.

### Technology Stack

| Component | Technology | Version |
|-----------|-----------|---------|
| Database | SAP HANA Cloud (HDI Container) | — |
| ML Engine | SAP PAL (Predictive Analysis Library) | — |
| Python Runtime | Python | 3.12 |
| ML Library | hana-ml | 2.28.x |
| Web Framework | Flask | 3.x |
| Data Processing | pandas | 2.x / numpy 1.26+ |
| Charts | Chart.js | 4.x |
| Deployment | MTA → Cloud Foundry | mbt 1.2.34, cf CLI 8.7.4 |

---

## 3. Data Pipeline — Step by Step

### Pipeline Overview

```
┌──────────┐    ┌──────────┐    ┌───────────────┐    ┌──────────────┐    ┌──────────┐
│ 01_load  │    │ 02_explore│    │ 03_prepare    │    │ 04_forecast  │    │ app.py   │
│ _data.js │───▶│ _data.py  │───▶│ _timeseries.py│───▶│ _models.py   │───▶│ (Flask)  │
│          │    │           │    │               │    │              │    │          │
│ CSV→HANA │    │ Profiling │    │ Aggregate     │    │ SES+SARIMA   │    │ Dashboard│
│ 33,674   │    │ EDA       │    │ Fill gaps     │    │ +BSTS        │    │ Charts   │
│ rows     │    │           │    │ Outlier fix   │    │ Compare      │    │ Tables   │
│          │    │           │    │ Train/Test    │    │ Store results │    │          │
└──────────┘    └──────────┘    └───────────────┘    └──────────────┘    └──────────┘
                                │                    │
                                ▼                    ▼
                         ┌──────────────┐     ┌───────────────┐
                         │03c_composite │     │04c_composite  │
                         │_timeseries.py│────▶│_forecast.py   │
                         │              │     │               │
                         │ACCCODE+VPC   │     │Same 3 models  │
                         │+MODEL keys   │     │per composite  │
                         └──────────────┘     └───────────────┘
```

---

### Step 1: Data Loading (`01_load_data.js`)

**File:** `01_load_data.js` (Node.js)  
**Driver:** `hdb` (SAP HANA Node.js driver)  
**Connection:** TLS-encrypted via HDI container service key

**What it does:**
1. Connects to SAP HANA Cloud HDI container
2. Truncates existing `ACCESSORY_FORECAST` table
3. Parses `Accessory forecast AI feed.csv` (handles quoted fields, BOM characters)
4. Batch-inserts all 33,674 rows

**Input CSV Schema:**

| Column | Type | Example | Role |
|--------|------|---------|------|
| `CLASS` | NVARCHAR(10) | C, EQE, GLC, SL | Vehicle class |
| `MODEL` | NVARCHAR(20) | C300W, EQE350X4 | Specific model |
| `MODEL_YEAR` | INTEGER | 2024 | Model year |
| `BAUMUSTER` | NVARCHAR(10) | 20649 | Internal design code |
| `VPC_LOCATION` | INTEGER | 12, 22, 32, 52 | Vehicle Processing Center |
| **`ACCCODE`** | **NVARCHAR(10)** | **D07, D49, D52** | **Forecast target** |
| **`PRODYEAR`** | **INTEGER** | **2024** | **Time axis (year)** |
| **`PRODMONTH`** | **NVARCHAR(2)** | **01–12** | **Time axis (month)** |
| **`VEHICLECOUNT`** | **INTEGER** | **1,557** | **Value to predict** |

**Key SQL:**
```sql
-- Table is HDI-managed (created by deployer from .hdbtable artifact)
TRUNCATE TABLE ACCESSORY_FORECAST;

-- Batch insert (parameterized)
INSERT INTO ACCESSORY_FORECAST
  (CLASS, MODEL, MODEL_YEAR, BAUMUSTER, VPC_LOCATION, ACCCODE, PRODYEAR, PRODMONTH, VEHICLECOUNT)
VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?);
```

---

### Step 2: Data Exploration (`02_explore_data.py`)

**File:** `02_explore_data.py`  
**Purpose:** EDA (Exploratory Data Analysis) — understand data before modeling

**What it analyzes:**
- Date range: Jan 2024 – May 2026 (~29 months)
- Vehicle classes: C, EQE, GLC, SL, etc.
- ACCCODE distribution: which accessories have enough data (12+ months)
- Monthly volume patterns per ACCCODE
- VPC location distribution

---

### Step 3: Time Series Preparation (`03_prepare_timeseries.py`)

**File:** `03_prepare_timeseries.py`

This is where raw records become clean, forecastable time series.

```
┌───────────────────────────────────────────────────────────────────────────┐
│                    TIME SERIES PREPARATION FLOW                           │
│                                                                           │
│  33,674 raw records                                                       │
│       │                                                                   │
│       ▼                                                                   │
│  ┌─────────────────────────────────────────────────┐                      │
│  │ STEP 3A: Aggregate by ACCCODE + PRODYEAR +      │                      │
│  │          PRODMONTH → SUM(VEHICLECOUNT)           │                      │
│  └─────────────────────────────────────────────────┘                      │
│       │                                                                   │
│       ▼                                                                   │
│  ┌─────────────────────────────────────────────────┐                      │
│  │ STEP 3B: Fill missing months with 0             │                      │
│  │          (continuous series required by PAL)     │                      │
│  │          Filter: only ACCCODEs with 12+ months   │                      │
│  │          Result: 40 ACCCODEs × 29 months         │                      │
│  └─────────────────────────────────────────────────┘                      │
│       │                                                                   │
│       ▼                                                                   │
│  ┌─────────────────────────────────────────────────┐                      │
│  │ STEP 3B2: Outlier Detection via PAL             │                      │
│  │   CALL _SYS_AFL.PAL_OUTLIER_DETECTION_FOR_      │                      │
│  │        TIME_SERIES(...)                          │                      │
│  │   Parameters: AUTO=1, RESIDUAL_USAGE=1           │                      │
│  │   Outlier values replaced with fitted values     │                      │
│  └─────────────────────────────────────────────────┘                      │
│       │                                                                   │
│       ▼                                                                   │
│  ┌─────────────────────────────────────────────────┐                      │
│  │ STEP 3C: Store in ACCCODE_TIMESERIES            │                      │
│  └─────────────────────────────────────────────────┘                      │
│       │                                                                   │
│       ▼                                                                   │
│  ┌─────────────────────────────────────────────────┐                      │
│  │ STEP 3D: Train/Test split                       │                      │
│  │   Training: months 1–24 (Jan 2024 – Dec 2025)   │                      │
│  │   Test:     months 25–29 (Jan 2026 – May 2026)   │                      │
│  │   Stored in PAL_ACCCODE_TRAINING table           │                      │
│  └─────────────────────────────────────────────────┘                      │
└───────────────────────────────────────────────────────────────────────────┘
```

**Outlier Detection — PAL SQL Call:**
```sql
-- Input: single time series for one ACCCODE
CREATE LOCAL TEMPORARY COLUMN TABLE #OD_INPUT (TIME_STAMP INT, VALUE DOUBLE);
-- Insert ACCCODE's monthly values...

-- Parameters
CREATE LOCAL TEMPORARY COLUMN TABLE #OD_PARAM
  (PARAM_NAME NVARCHAR(256), INT_VALUE INT, DOUBLE_VALUE DOUBLE, STRING_VALUE NVARCHAR(256));
INSERT INTO #OD_PARAM VALUES ('AUTO', 1, NULL, NULL);           -- Auto-select detection method
INSERT INTO #OD_PARAM VALUES ('RESIDUAL_USAGE', 1, NULL, NULL); -- Use residuals for correction

-- Output tables
CREATE LOCAL TEMPORARY COLUMN TABLE #OD_OUT
  (TIME_STAMP INT, RAW_DATA DOUBLE, RESIDUAL DOUBLE, OUTLIER_SCORE DOUBLE, IS_OUTLIER INT);
CREATE LOCAL TEMPORARY COLUMN TABLE #OD_STATS
  (STAT_NAME NVARCHAR(256), STAT_VALUE NVARCHAR(256));

-- Execute PAL outlier detection
CALL _SYS_AFL.PAL_OUTLIER_DETECTION_FOR_TIME_SERIES(#OD_INPUT, #OD_PARAM, #OD_OUT, #OD_STATS);

-- Outlier values (IS_OUTLIER=1) replaced with: RAW_DATA - RESIDUAL = fitted value
```

| Parameter | Value | Purpose |
|-----------|-------|---------|
| `AUTO` | 1 | PAL auto-selects the best outlier detection method |
| `RESIDUAL_USAGE` | 1 | Use model residuals to compute outlier scores |

**Effective Data Range Detection:**

The pipeline detects "data cliffs" — trailing months where counts drop to near-zero because data hasn't been fully recorded. For each ACCCODE, it scans backward from the last month and finds the last month where `VEHICLECOUNT >= max(mean × 0.10, 1)`. This becomes the `effective_end`.

```python
def find_effective_end(acc_ts):
    nonzero = acc_ts[acc_ts['VEHICLECOUNT'] > 0]['VEHICLECOUNT']
    avg = nonzero.mean()
    threshold = max(avg * 0.10, 1)
    for _, row in acc_ts.sort_values('TIME_ID', ascending=False).iterrows():
        if row['VEHICLECOUNT'] >= threshold:
            return int(row['TIME_ID'])
    return 12
```

---

### Step 3C: Composite Time Series Preparation (`03c_prepare_composite_timeseries.py`)

**File:** `03c_prepare_composite_timeseries.py`

Same process as Step 3 but groups by **ACCCODE + VPC_LOCATION + MODEL**:

```
COMPOSITE_KEY = "ACCCODE|VPC_LOCATION|MODEL"
Example: "D07|12|C300W"
```

| Dimension | Example Values |
|-----------|---------------|
| ACCCODE | D07, D49, D52 |
| VPC_LOCATION | 12, 22, 32, 52 |
| MODEL | C300W, EQE350X4, GLC300X4 |

**Result:** 594 forecastable composite keys (those with 12+ months of data)

---

## 4. Forecasting Models — Technical Deep Dive

### Pipeline Configuration (`04_forecast_models.py`)

```python
FORECAST_HORIZON = 12     # Predict 12 future months
TEST_MONTHS      = 5      # Last 5 months held out for evaluation
SEASONAL_PERIOD  = 12     # Monthly data with yearly seasonality
```

### Model Execution Flow (Per ACCCODE)

```
┌──────────────────────────────────────────────────────────────────────────┐
│                  FOR EACH ACCCODE (40 total)                             │
│                                                                          │
│  ┌────────────────────────────────────────────────────────────────────┐  │
│  │ 1. Load training data into #PAL_DATA temp table                   │  │
│  │    INSERT INTO #PAL_DATA                                          │  │
│  │    SELECT TIME_ID, CAST(VEHICLECOUNT AS DOUBLE)                   │  │
│  │    FROM ACCCODE_TIMESERIES                                        │  │
│  │    WHERE ACCCODE = ? AND TIME_ID <= ?  (train_cutoff)             │  │
│  └────────────────────────────────────────────────────────────────────┘  │
│       │                                                                  │
│       ├──────────────────────┬──────────────────────┐                    │
│       ▼                      ▼                      ▼                    │
│  ┌──────────┐          ┌──────────┐          ┌──────────┐               │
│  │  MODEL 1 │          │  MODEL 2 │          │  MODEL 3 │               │
│  │   SES    │          │  SARIMA  │          │   BSTS   │               │
│  │ (PAL SQL)│          │ (PAL SQL)│          │(hana_ml) │               │
│  └────┬─────┘          └────┬─────┘          └────┬─────┘               │
│       │                      │                      │                    │
│       ▼                      ▼                      ▼                    │
│  ┌──────────────────────────────────────────────────────────────────┐    │
│  │ 2. Clamp all predictions >= 0 (count data can't be negative)    │    │
│  └──────────────────────────────────────────────────────────────────┘    │
│       │                                                                  │
│       ▼                                                                  │
│  ┌──────────────────────────────────────────────────────────────────┐    │
│  │ 3. Compute MAPE and RMSE on test period                         │    │
│  │    Pick winner = model with lowest MAPE                         │    │
│  └──────────────────────────────────────────────────────────────────┘    │
│       │                                                                  │
│       ▼                                                                  │
│  ┌──────────────────────────────────────────────────────────────────┐    │
│  │ 4. Store in ACCCODE_FORECAST_RESULTS + ACCCODE_MODEL_COMPARISON │    │
│  └──────────────────────────────────────────────────────────────────┘    │
└──────────────────────────────────────────────────────────────────────────┘
```

---

### Model 1: Simple Exponential Smoothing (SES)

**SAP PAL Function:** `_SYS_AFL.PAL_BROWN_EXPSMOOTH`

**Concept:** Maintains a single smoothed "level" — a weighted average of all past values. The forecast for every future month is this one flat number.

**Formula:**
```
F(t+1) = α × Y(t) + (1 − α) × F(t)
```

- **α (alpha):** Controls memory length. Auto-optimized by PAL.
  - α close to 0 → slow to react, long memory
  - α close to 1 → chases recent fluctuations

**Input Parameters:**

| Parameter | Value | Description |
|-----------|-------|-------------|
| `FORECAST_NUM` | `test_months + 12` (= 17) | Number of future periods to predict |

**Input Table Schema:**
```
#PAL_DATA (TIME_ID INT, VEHICLECOUNT DOUBLE)
```

**Output Table Schema:**
```
#SES_OUT   (TIME_ID INT, FORECAST DOUBLE)
#SES_STATS (STAT_NAME NVARCHAR(256), STAT_VALUE DOUBLE)
```

**Exact SQL Executed:**
```sql
-- 1. Create temp tables
CREATE LOCAL TEMPORARY COLUMN TABLE #PAL_DATA (TIME_ID INT, VEHICLECOUNT DOUBLE);
INSERT INTO #PAL_DATA
  SELECT TIME_ID, CAST(VEHICLECOUNT AS DOUBLE)
  FROM ACCCODE_TIMESERIES
  WHERE ACCCODE = 'D07' AND TIME_ID <= 24;

CREATE LOCAL TEMPORARY COLUMN TABLE #SES_PARAM
  (PARAM_NAME NVARCHAR(256), INT_VALUE INT, DOUBLE_VALUE DOUBLE, STRING_VALUE NVARCHAR(256));
INSERT INTO #SES_PARAM VALUES ('FORECAST_NUM', 17, NULL, NULL);

CREATE LOCAL TEMPORARY COLUMN TABLE #SES_OUT (TIME_ID INT, FORECAST DOUBLE);
CREATE LOCAL TEMPORARY COLUMN TABLE #SES_STATS (STAT_NAME NVARCHAR(256), STAT_VALUE DOUBLE);

-- 2. Execute PAL
CALL _SYS_AFL.PAL_BROWN_EXPSMOOTH(#PAL_DATA, #SES_PARAM, #SES_OUT, #SES_STATS);

-- 3. Read results (forecast periods only)
SELECT TIME_ID, FORECAST FROM #SES_OUT WHERE TIME_ID > 24 ORDER BY TIME_ID;
```

**Strength:** Robust baseline. Never produces wild predictions.  
**Limitation:** Flat-line forecast — cannot capture seasonality or trend.

---

### Model 2: Seasonal ARIMA (SARIMA)

**SAP PAL Functions:** `_SYS_AFL.PAL_ARIMA` (fit) + `_SYS_AFL.PAL_ARIMA_FORECAST` (predict)

**Model Specification:** SARIMA(1,1,1)(1,1,1)[12]

```
ARIMA(p=1, d=1, q=1)(P=1, D=1, Q=1)[s=12]
```

**Concept:** Combines autoregression, differencing, and moving averages with seasonal components.

| Component | Parameter | Value | What It Does |
|-----------|-----------|-------|-------------|
| AR | p | 1 | Uses 1 recent month's value to predict next |
| Differencing | d | 1 | Differences once to remove trend |
| MA | q | 1 | Corrects using 1 past forecast error |
| Seasonal AR | P | 1 | Uses same-month-last-year value |
| Seasonal Diff | D | 1 | Year-over-year differencing |
| Seasonal MA | Q | 1 | Same-month-last-year error correction |
| Season Length | s | 12 | 12-month yearly cycle |
| Method | METHOD | 1 | CSS-ML (Conditional Sum of Squares + ML) |
| Threading | THREAD_RATIO | 1.0 | Use all available threads |

**Input Parameters (ARIMA Fit):**

| Parameter | Value | Description |
|-----------|-------|-------------|
| `P` | 1 | AR order |
| `D` | 1 | Differencing order |
| `Q` | 1 | MA order |
| `SEASONAL_PERIOD` | 12 | Months per seasonal cycle |
| `SEASONAL_P` | 1 | Seasonal AR order |
| `SEASONAL_D` | 1 | Seasonal differencing order |
| `SEASONAL_Q` | 1 | Seasonal MA order |
| `METHOD` | 1 | CSS-ML estimation |
| `THREAD_RATIO` | 1.0 | Full parallelism |

**Input Parameters (ARIMA Forecast):**

| Parameter | Value | Description |
|-----------|-------|-------------|
| `FORECAST_LENGTH` | 17 | test_months + forecast_horizon |
| `FORECAST_METHOD` | 1 | Point forecast |

**Exact SQL Executed — Fit Phase:**
```sql
-- Parameter table
CREATE LOCAL TEMPORARY COLUMN TABLE #ARIMA_PARAM
  (PARAM_NAME NVARCHAR(256), INT_VALUE INT, DOUBLE_VALUE DOUBLE, STRING_VALUE NVARCHAR(256));
INSERT INTO #ARIMA_PARAM VALUES ('P', 1, NULL, NULL);
INSERT INTO #ARIMA_PARAM VALUES ('D', 1, NULL, NULL);
INSERT INTO #ARIMA_PARAM VALUES ('Q', 1, NULL, NULL);
INSERT INTO #ARIMA_PARAM VALUES ('SEASONAL_PERIOD', 12, NULL, NULL);
INSERT INTO #ARIMA_PARAM VALUES ('SEASONAL_P', 1, NULL, NULL);
INSERT INTO #ARIMA_PARAM VALUES ('SEASONAL_D', 1, NULL, NULL);
INSERT INTO #ARIMA_PARAM VALUES ('SEASONAL_Q', 1, NULL, NULL);
INSERT INTO #ARIMA_PARAM VALUES ('METHOD', 1, NULL, NULL);
INSERT INTO #ARIMA_PARAM VALUES ('THREAD_RATIO', NULL, 1.0, NULL);

-- Output tables
CREATE LOCAL TEMPORARY COLUMN TABLE #ARIMA_MODEL (KEY NVARCHAR(256), VALUE NVARCHAR(5000));
CREATE LOCAL TEMPORARY COLUMN TABLE #ARIMA_FIT (TIME_ID INT, FITTED DOUBLE, RESIDUALS DOUBLE);

-- Fit the model (runs inside HANA Script Server)
DO BEGIN
    lt_data  = SELECT TIME_ID, VEHICLECOUNT FROM #PAL_DATA;
    lt_param = SELECT PARAM_NAME, INT_VALUE, DOUBLE_VALUE, STRING_VALUE FROM #ARIMA_PARAM;
    CALL _SYS_AFL.PAL_ARIMA(:lt_data, :lt_param, lt_model, lt_fit);
    INSERT INTO #ARIMA_MODEL SELECT * FROM :lt_model;
    INSERT INTO #ARIMA_FIT   SELECT * FROM :lt_fit;
END;
```

**Exact SQL Executed — Forecast Phase:**
```sql
-- Forecast parameters
CREATE LOCAL TEMPORARY COLUMN TABLE #FC_PARAM
  (PARAM_NAME NVARCHAR(256), INT_VALUE INT, DOUBLE_VALUE DOUBLE, STRING_VALUE NVARCHAR(256));
INSERT INTO #FC_PARAM VALUES ('FORECAST_LENGTH', 17, NULL, NULL);
INSERT INTO #FC_PARAM VALUES ('FORECAST_METHOD', 1, NULL, NULL);

-- Output: point forecast + confidence intervals
CREATE LOCAL TEMPORARY COLUMN TABLE #FC_OUT
  (TIME_ID INT, FORECAST DOUBLE, SE DOUBLE, LO80 DOUBLE, HI80 DOUBLE, LO95 DOUBLE, HI95 DOUBLE);

-- Generate forecasts using stored model
DO BEGIN
    lt_data  = SELECT TIME_ID, VEHICLECOUNT FROM #FC_DATA;       -- empty table (forecast-only)
    lt_model = SELECT KEY, VALUE FROM #ARIMA_MODEL;               -- trained model
    lt_param = SELECT PARAM_NAME, INT_VALUE, DOUBLE_VALUE, STRING_VALUE FROM #FC_PARAM;
    CALL _SYS_AFL.PAL_ARIMA_FORECAST(:lt_data, :lt_model, :lt_param, lt_result);
    INSERT INTO #FC_OUT SELECT * FROM :lt_result;
END;

-- Read forecasts
SELECT TIME_ID, FORECAST FROM #FC_OUT ORDER BY TIME_ID;
```

**Strength:** Most mathematically sophisticated. Captures complex seasonal and trend patterns.  
**Limitation:** With only ~24 months of training data, seasonal components have limited data to learn from. Can produce negative forecasts (clamped to 0).

---

### Model 3: Bayesian Structural Time Series (BSTS)

**Python API:** `hana_ml.algorithms.pal.tsa.bsts.BSTS`  
**Behind the scenes:** Executes inside HANA via the hana_ml driver

**Concept:** Decomposes the time series into structural components using Bayesian inference:

```
┌─────────────────────────────────────────────────────────┐
│                    BSTS Decomposition                    │
│                                                          │
│   Observed = Trend + Seasonal + Regression + Error       │
│                                                          │
│   ┌─────────┐  ┌──────────────┐  ┌────────────────┐     │
│   │  Trend  │  │  Seasonal    │  │  Bayesian      │     │
│   │  (local │  │  (12-month   │  │  Posterior     │     │
│   │  linear)│  │   cycle)     │  │  Sampling      │     │
│   └─────────┘  └──────────────┘  │  (MCMC)        │     │
│                                   └────────────────┘     │
└─────────────────────────────────────────────────────────┘
```

**BSTS Parameters:**

| Parameter | Value | Description |
|-----------|-------|-------------|
| `burn` | 0.5 | Discard first 50% of MCMC samples (burn-in period) |
| `niter` | 1000 | Number of MCMC iterations |
| `seasonal_period` | 12 | 12-month seasonal cycle |
| `seed` | 1 | Random seed for reproducibility |

**Exact Python Code Executed:**
```python
from hana_ml.algorithms.pal.tsa.bsts import BSTS

# Query training data directly from HANA (avoids LOCAL TEMPORARY issues)
hana_train = conn.sql(f"""
    SELECT TIME_ID AS "TIME_STAMP", CAST(VEHICLECOUNT AS DOUBLE) AS "TARGET"
    FROM "{schema}"."ACCCODE_TIMESERIES"
    WHERE ACCCODE='{acccode}' AND TIME_ID<={train_cutoff}
    ORDER BY TIME_ID
""")

# Fit BSTS model
bsts_model = BSTS(burn=0.5, niter=1000, seasonal_period=12, seed=1)
bsts_model.fit(data=hana_train, key='TIME_STAMP', endog='TARGET')

# Predict test + future periods
bsts_result = bsts_model.predict(horizon=total_forecast)  # total_forecast = test_months + 12

# bsts_result[0] = forecast DataFrame (TIME_STAMP, FORECAST)
# bsts_result[1] = decomposition DataFrame
bsts_fc_df = bsts_result[0].collect()
```

**Important Technical Note — LOCAL TEMPORARY Table Issue:**

During development, we discovered that `hana_ml.dataframe.create_dataframe_from_pandas(..., table_type='LOCAL TEMPORARY')` fails on this HANA Cloud HDI container. The workaround is to query training data directly from the permanent HANA table using `conn.sql()`:

```python
# ❌ FAILS: create_dataframe_from_pandas with LOCAL TEMPORARY
# hana_train = create_dataframe_from_pandas(conn, train_pdf, 'LOCAL TEMPORARY', ...)

# ✅ WORKS: Query directly from HANA table
hana_train = conn.sql("""
    SELECT TIME_ID AS "TIME_STAMP", CAST(VEHICLECOUNT AS DOUBLE) AS "TARGET"
    FROM "schema"."ACCCODE_TIMESERIES"
    WHERE ACCCODE='D07' AND TIME_ID<=24
    ORDER BY TIME_ID
""")
```

**TIME_STAMP Offset Mapping:**

BSTS predict output uses 0-indexed offsets. Map back to real TIME_IDs:
```python
# Offset i → real TIME_ID = train_cutoff + 1 + i
for _, row in bsts_fc_df.iterrows():
    offset = int(row['TIME_STAMP'])
    real_tid = train_cutoff + 1 + offset
    val = max(0.0, float(row['FORECAST']))
```

**Composite Key Guard:**

For composite key forecasting, BSTS requires `train_cutoff > SEASONAL_PERIOD`. Some low-data composite keys skip BSTS:
```python
if train_cutoff <= SEASONAL_PERIOD:
    raise ValueError(f"Only {train_cutoff} training points, need > {SEASONAL_PERIOD}")
```

**Strength:** Bayesian framework handles uncertainty naturally. Decomposes trend/seasonality cleanly.  
**Winner for 19 out of 40 ACCCODEs** — the most frequent winner among the three models.

---

## 5. AutoML Investigation & Why BSTS Was Chosen

### The AutoML Journey

Before settling on the final three-model pipeline, we extensively investigated SAP PAL's AutoML capabilities to see if they could automatically find the best forecasting approach.

```
┌──────────────────────────────────────────────────────────────────────────┐
│                     AUTOML INVESTIGATION TIMELINE                        │
│                                                                          │
│  ┌──────────┐   ┌──────────┐   ┌──────────┐   ┌──────────┐             │
│  │ Attempt 1│   │ Attempt 2│   │ ...      │   │ Attempt 9│             │
│  │ PAL_     │   │ PAL_     │   │ Various  │   │ PAL_     │             │
│  │ AUTOML_  │   │ AUTOML_  │   │ parameter│   │ AUTOML_  │             │
│  │ FIT      │   │ FIT +    │   │ combos   │   │ FIT      │             │
│  │          │   │ PIPELINE_│   │          │   │ (final)  │             │
│  │ ✅ Fit OK │   │ PREDICT  │   │          │   │ ✅ Fit OK │             │
│  │ ❌ Predict│   │ ❌ Predict│   │ ❌ All    │   │ ❌ Predict│             │
│  │   fails  │   │   fails  │   │   fail   │   │   fails  │             │
│  └──────────┘   └──────────┘   └──────────┘   └──────────┘             │
│                                                                          │
│  FINDING: PAL_AUTOML_FIT successfully trains and recommends BSTS        │
│           as the best model. But PAL_PIPELINE_PREDICT is broken          │
│           for time series on this HANA Cloud version.                    │
│                                                                          │
│  SOLUTION: Use BSTS directly via hana_ml.algorithms.pal.tsa.bsts.BSTS  │
│            AutoML validated that BSTS is the right choice!               │
└──────────────────────────────────────────────────────────────────────────┘
```

### What We Tried (9 AutoML Iterations)

We wrote and executed 9 separate test scripts (`test_automl.py` through `test_automl9.py` plus `test_automl_predict.py`) to thoroughly investigate PAL AutoML:

| Iteration | What Was Tried | Result |
|-----------|---------------|--------|
| 1 | Basic `PAL_AUTOML_FIT` with default parameters | ✅ Fit succeeded, **AutoML recommended BSTS** |
| 2 | `PAL_AUTOML_FIT` → `PAL_PIPELINE_PREDICT` | ❌ Predict failed — internal PAL error on time series |
| 3 | Different output table schemas for predict | ❌ Same predict failure |
| 4 | Adjusted `FORECAST_NUM` parameter variations | ❌ Predict error persists |
| 5 | Changed input data structure / column types | ❌ No improvement |
| 6 | Tried `PIPELINE_TYPE='forecast'` explicitly | ❌ Unsupported parameter |
| 7 | Used fitted model ID reference with predict | ❌ ID mismatch errors |
| 8 | Minimal predict call with just model reference | ❌ Internal PAL error |
| 9 | Final attempt: exhaustive param combinations | ❌ Confirmed: predict is broken for TSA |
| predict | Direct predict-only test (no fit) | ❌ Conclusive: `PAL_PIPELINE_PREDICT` bug for time series |

### What AutoML Told Us

**PAL_AUTOML_FIT successfully completed training** and returned its model recommendation:

> **AutoML's recommended best model: BSTS (Bayesian Structural Time Series)**

AutoML evaluated multiple algorithms internally and determined BSTS best fit the accessory demand patterns. The only issue was that `PAL_PIPELINE_PREDICT` (the AutoML prediction API) was broken for time series workloads on our HANA Cloud version.

### BSTS Direct Implementation (4 iterations)

After learning that AutoML recommends BSTS, we implemented it directly:

| Iteration | What Was Tried | Result |
|-----------|---------------|--------|
| 1 (`test_bsts.py`) | BSTS via `create_dataframe_from_pandas` with LOCAL TEMP table | ❌ LOCAL TEMPORARY table creation fails on HDI container |
| 2 (`test_bsts2.py`) | BSTS with different table type parameters | ❌ Same failure |
| 3 (`test_bsts3.py`) | BSTS with training data queried via `conn.sql()` | ✅ fit() works, partial predict |
| 4 (`test_bsts4.py`) | Full BSTS pipeline with `conn.sql()` + predict + offset mapping | ✅ **Complete success** |

**Key Breakthrough:** Using `conn.sql()` to query training data directly from the permanent HANA table instead of uploading a pandas DataFrame. This bypasses the LOCAL TEMPORARY table creation bug entirely.

### Final Decision Rationale

```
┌──────────────────────────────────────────────────────────────────┐
│                 FINAL MODEL SELECTION RATIONALE                   │
│                                                                   │
│  ┌─────────────────────────────────────────────────────────────┐ │
│  │  AutoML Fit ──▶ Recommends BSTS as best algorithm          │ │
│  │  AutoML Predict ──▶ BROKEN for time series (PAL bug)       │ │
│  │  Decision: Implement BSTS directly via hana_ml Python API  │ │
│  └─────────────────────────────────────────────────────────────┘ │
│                                                                   │
│  Keep SES as stable baseline → catches cases where simple wins    │
│  Keep SARIMA for complex seasonality → strong on seasonal data    │
│  Add BSTS per AutoML recommendation → Bayesian decomposition     │
│  Let MAPE on test data decide winner per ACCCODE                 │
│                                                                   │
│  ┌─────────────────────────────────────────────────────────────┐ │
│  │  RESULTS: 3-model competition per ACCCODE                  │ │
│  │   • SES (baseline)              — wins ~8/40 ACCCODEs      │ │
│  │   • SARIMA(1,1,1)(1,1,1)[12]    — wins ~13/40 ACCCODEs    │ │
│  │   • BSTS (burn=0.5, niter=1000) — wins ~19/40 ACCCODEs    │ │
│  │                                                             │ │
│  │   BSTS: Most frequent winner — confirms AutoML's choice    │ │
│  └─────────────────────────────────────────────────────────────┘ │
└──────────────────────────────────────────────────────────────────┘
```

---

## 6. Parameter Tuning Journey

### Evolution of Key Parameters

```
┌──────────────────────────────────────────────────────────────────────────┐
│              PARAMETER TUNING ITERATIONS                                  │
│                                                                          │
│  ITERATION 1 (Initial)           ITERATION 2 (Improved)                  │
│  ─────────────────────           ─────────────────────────                │
│  Models: SES + Holt-Winters      Models: SES + HW + SARIMA              │
│  Forecast: 6 months              Forecast: 6 months                      │
│  Test: 5 months                  Test: 5 months                          │
│  HW: PAL_TRIPLE_EXPSMOOTH        SARIMA: PAL_AUTOARIMA                   │
│  No outlier detection             + Outlier detection (PAL)              │
│  No data cliff detection          + Data cliff detection                  │
│                                   + Seasonal Naive baseline              │
│                                                                          │
│  ITERATION 3 (AutoML Test)       ITERATION 4 (Final Production)          │
│  ─────────────────────           ──────────────────────────               │
│  Tried PAL_AUTOML_FIT            Models: SES + SARIMA + BSTS            │
│  9 test scripts executed         Forecast: 12 months                     │
│  AutoML recommends BSTS          SARIMA: Fixed (1,1,1)(1,1,1)[12]       │
│  PAL_PIPELINE_PREDICT broken     BSTS: burn=0.5, niter=1000, seed=1     │
│  4 BSTS test iterations          + Composite key forecasting             │
│  → conn.sql() breakthrough       + Non-negative clamping                 │
│                                   + HDI TRUNCATE (no DROP)               │
│                                                                          │
│  TOTAL: 13 experimental test scripts before final pipeline               │
└──────────────────────────────────────────────────────────────────────────┘
```

### Detailed Parameter Changes

| Parameter | Iteration 1 | Iteration 2 | Iteration 4 (Final) | Why Changed |
|-----------|-------------|-------------|---------------------|-------------|
| **Models** | SES + Holt-Winters | SES + HW + SARIMA + Seasonal Naive | SES + SARIMA + BSTS | AutoML recommended BSTS; HW and SNaive dropped |
| **Forecast Horizon** | 6 months | 6 months | **12 months** | Business needed full-year planning |
| **SARIMA Type** | — | PAL_AUTOARIMA (auto-search) | **PAL_ARIMA fixed (1,1,1)(1,1,1)[12]** | Auto-search overfits on 24 months of data |
| **SARIMA METHOD** | — | Default | **1 (CSS-ML)** | More stable estimation for short series |
| **BSTS niter** | — | — | **1000** | Sufficient MCMC samples for convergence |
| **BSTS burn** | — | — | **0.5** | Standard 50% burn-in for MCMC |
| **BSTS seed** | — | — | **1** | Reproducible results across runs |
| **Negative Clamping** | Not applied | Partial | **`max(0, forecast)` on all models** | SARIMA can produce negative counts |
| **Outlier Detection** | None | PAL_OUTLIER_DETECTION (AUTO=1) | Same | Reduces noise from production data spikes |
| **Data Cliff Detection** | None | `find_effective_end()` | Same | Exclude trailing months with incomplete data |
| **HW seasonal_type** | Auto (additive/multiplicative) | Auto | Removed (replaced by BSTS) | BSTS handles this better |
| **Table Operations** | DROP + CREATE | DROP + CREATE | **TRUNCATE only** | HDI-managed tables cannot be dropped |

### SARIMA: Why Fixed Order Instead of Auto-Search

Initially we used `PAL_AUTOARIMA` which searches across multiple (p,d,q)(P,D,Q) combinations. With only ~24 months of training data:

- Auto-search sometimes selected high-order models like ARIMA(2,1,2)(2,1,1)[12]
- These overfit on the limited training data and performed poorly on test
- Fixed (1,1,1)(1,1,1)[12] is the standard "workhorse" SARIMA — handles most monthly seasonal data well
- Requires at least 2 full seasonal cycles (24 months) — we're at the minimum

---

## 7. Composite Key Forecasting

### Why Composite Keys?

ACCCODE-level forecasting answers "How many D07 total?" But supply-chain needs more granularity:

```
┌──────────────────────────────────────────────────────────────────┐
│  ACCCODE-Level (40 series):                                       │
│    "D07 needs 1,200 units in August 2026"                        │
│                                                                   │
│  Composite-Level (594 series):                                    │
│    "D07 at VPC 12 for C300W needs 450 units in August 2026"      │
│    "D07 at VPC 22 for GLC300X4 needs 320 units in August 2026"   │
│    "D07 at VPC 32 for EQE350X4 needs 180 units in August 2026"   │
│                                                                   │
│  → More actionable for logistics and inventory planning           │
└──────────────────────────────────────────────────────────────────┘
```

### Composite Pipeline (`04c_composite_forecast_models.py`)

Identical 3-model pipeline (SES + SARIMA + BSTS) but runs for each `COMPOSITE_KEY`:

```
COMPOSITE_KEY = "ACCCODE|VPC_LOCATION|MODEL"
Total forecastable composite keys: 594
```

**BSTS Guard for Low-Data Keys:**
```python
if train_cutoff <= SEASONAL_PERIOD:
    raise ValueError(f"Only {train_cutoff} training points, need > {SEASONAL_PERIOD}")
```

This guard ensures BSTS only runs when there's enough data to estimate seasonal components. Keys that fail this check still get SES and SARIMA predictions.

---

## 8. Model Selection & Accuracy Metrics

### MAPE (Primary Metric — Used to Pick Winner)

```
MAPE = (1/n) × Σ |Actual_i − Forecast_i| / Actual_i × 100%
```

```python
def calc_mape(actual, forecast):
    actual, forecast = np.array(actual, dtype=float), np.array(forecast, dtype=float)
    mask = actual > 0  # Skip zero-actual months (avoid division by zero)
    if mask.sum() == 0:
        return float('inf')
    return float(np.mean(np.abs((actual[mask] - forecast[mask]) / actual[mask])) * 100)
```

### RMSE (Displayed in Dashboard)

```
RMSE = √( (1/n) × Σ (Actual_i − Forecast_i)² )
```

```python
def calc_rmse(actual, forecast):
    return float(np.sqrt(np.mean((np.array(actual, dtype=float) - np.array(forecast, dtype=float)) ** 2)))
```

| Metric | Used For | Units |
|--------|----------|-------|
| **MAPE** | Model selection (lowest wins) | Percentage |
| **RMSE** | Dashboard display, secondary comparison | Vehicle count |

### Winner Selection Logic

```python
mapes = {
    'SES':    forecasts.get('SES_MAPE', float('inf')),
    'SARIMA': forecasts.get('SARIMA_MAPE', float('inf')),
    'BSTS':   forecasts.get('BSTS_MAPE', float('inf')),
}
winner = min(mapes, key=mapes.get)  # Model with lowest MAPE on test set
```

### Typical Results Distribution

```
┌──────────────────────────────────────────────────────────────┐
│               MODEL WINS ACROSS 40 ACCCODEs                  │
│                                                               │
│   BSTS    ████████████████████ 19/40 (47.5%)  ← Most wins   │
│   SARIMA  █████████████ 13/40 (32.5%)                        │
│   SES     ████████ 8/40 (20.0%)                              │
│                                                               │
│   BSTS wins the most — confirming AutoML's recommendation    │
└──────────────────────────────────────────────────────────────┘
```

---

## 9. Web Dashboard (`app.py`)

### Route Architecture

| Route | Method | Template | Purpose |
|-------|--------|----------|---------|
| `/` | GET | `predictions.html` | ACCCODE landing page with search |
| `/acccode/<code>` | GET | `detail.html` | ACCCODE detail: chart + table + model explanation |
| `/composite_predictions` | GET | `composite_predictions.html` | Composite key search page |
| `/composite/<path:key>` | GET | `composite_detail.html` | Composite detail: chart + table + model explanation |
| `/api/search` | GET | JSON | API: search ACCCODEs and composite keys |
| `/api/debug` | GET | JSON | API: connection health check |

### Detail Page Features

Each detail page (`/acccode/<code>` and `/composite/<key>`) includes:

1. **Line Chart** — Actual vs Best model forecast (Chart.js)
2. **Future Predictions Table** — 12-month predictions with the best model
3. **Model Explanation Section:**
   - Data split overview tiles (training months, test months, future months)
   - Model performance comparison table (all 3 models with RMSE)
   - Best model highlighted with green checkmark
   - Methodology description explaining which model won and why
4. **Collapsible Detailed Data** — Three tabbed panels:
   - Training Data tab
   - Test Data tab (all 3 models side by side vs actual)
   - Future Predictions tab (all 3 models, best highlighted in green)

### Database Column Mapping

The `HW_FORECAST` column was originally created for Holt-Winters but now stores BSTS values. HDI-managed tables can't be altered, so:

```python
def _best_forecast_col(best_model):
    mapping = {
        'SES': 'SES_FORECAST',
        'SARIMA': 'SARIMA_FORECAST',
        'BSTS': 'HW_FORECAST',  # BSTS values stored in HW_FORECAST column
    }
    return mapping.get(best_model, 'SES_FORECAST')
```

---

## 10. HANA Tables Reference

### ACCCODE-Level Tables

| Table | Key Columns | Purpose |
|-------|-------------|---------|
| `ACCESSORY_FORECAST` | CLASS, MODEL, ACCCODE, PRODYEAR, PRODMONTH, VEHICLECOUNT | Raw CSV data (33,674 rows) |
| `ACCCODE_TIMESERIES` | ACCCODE, TIME_ID, PROD_DATE, VEHICLECOUNT | Clean monthly series (40 × 29 = 1,160 rows) |
| `PAL_ACCCODE_TRAINING` | ACCCODE, TIME_ID, VEHICLECOUNT (DOUBLE) | Training subset (TIME_ID ≤ train_cutoff) |
| `ACCCODE_FORECAST_RESULTS` | ACCCODE, PROD_DATE, ACTUAL, SES_FORECAST, HW_FORECAST*, SARIMA_FORECAST, IS_FUTURE | Test + future predictions |
| `ACCCODE_MODEL_COMPARISON` | ACCCODE, MODEL_NAME, MAPE, RMSE, TOTAL_VOLUME, DATA_POINTS, BEST_MODEL | Per-model accuracy |

> *`HW_FORECAST` stores BSTS values (column name retained from earlier Holt-Winters iteration)

### Composite-Level Tables

| Table | Extra Columns | Purpose |
|-------|---------------|---------|
| `COMPOSITE_TIMESERIES` | COMPOSITE_KEY, VPC_LOCATION, MODEL | Composite monthly series (594 keys) |
| `COMPOSITE_FORECAST_RESULTS` | COMPOSITE_KEY, ACCCODE, VPC_LOCATION, MODEL | Test + future predictions |
| `COMPOSITE_MODEL_COMPARISON` | COMPOSITE_KEY, ACCCODE, VPC_LOCATION, MODEL, MODEL_NAME | Per-model accuracy |

### HDI Management

All tables defined as `.hdbtable` artifacts in `db/src/`. **TRUNCATE only, never DROP** — schema changes require updating the artifact and redeploying.

---

## 11. Deployment Architecture

### Project Structure

```
sapai_pl/
├── mta.yaml                              ← MTA descriptor (CF deployment)
├── package.json                          ← Root Node.js dependencies
├── .env                                  ← HDI credentials (local dev only)
├── requirements.txt                      ← Python: flask, hana-ml, pandas, numpy, python-dotenv
├── runtime.txt                           ← Python 3.12 for CF buildpack
├── Procfile                              ← CF start: python app.py
│
├── app.py                                ← Flask dashboard (4 routes + 2 APIs)
├── 01_load_data.js                       ← CSV → HANA loader (Node.js)
├── 02_explore_data.py                    ← Data exploration / EDA
├── 03_prepare_timeseries.py              ← ACCCODE time series prep + outlier detection
├── 03c_prepare_composite_timeseries.py   ← Composite key time series prep
├── 04_forecast_models.py                 ← 3-model pipeline for 40 ACCCODEs
├── 04c_composite_forecast_models.py      ← 3-model pipeline for 594 composite keys
├── 05_compare_and_predict.py             ← Legacy compare script
│
├── templates/                            ← Jinja2 HTML templates
│   ├── base.html                         ← Layout: SAP shell bar, CSS, Chart.js
│   ├── predictions.html                  ← ACCCODE search landing page
│   ├── detail.html                       ← ACCCODE detail (chart + tables + model info)
│   ├── composite_predictions.html        ← Composite key search page
│   └── composite_detail.html             ← Composite detail page
│
├── db/                                   ← HDI database module
│   ├── package.json                      ← @sap/hdi-deploy
│   └── src/
│       ├── *.hdbtable                    ← Table definitions
│       └── data/
│           ├── ACCESSORY_FORECAST.csv
│           └── ACCESSORY_FORECAST.hdbtabledata
│
├── Accessory_Forecast_Prediction_Guide.md          ← This document (technical)
├── Accessory_Forecast_Functional_Demo_Guide.md     ← Functional demo guide
└── Prompts_Used_To_Build_This_App.md               ← Development prompts log
```

### Build & Deploy

```bash
mbt build                                    # Build MTA archive
cf deploy mta_archives/sapai-pl_1.0.0.mtar  # Deploy to Cloud Foundry
```

### Prerequisites for PAL

1. **Enable Script Server:** BTP Cockpit → HANA Cloud → Edit → Advanced Settings → Enable Script Server
2. **Grant PAL Execute:** `GRANT AFL__SYS_AFL_AFLPAL_EXECUTE TO <HDI_RT_USER>;`
3. **Verify:** `SELECT * FROM SYS.AFL_FUNCTIONS WHERE AREA_NAME = 'AFLPAL' LIMIT 5;`

---

## 12. Useful SQL Queries

```sql
-- Future predictions for a specific ACCCODE
SELECT ACCCODE, PROD_DATE, PRODYEAR, PRODMONTH,
       SES_FORECAST, HW_FORECAST AS BSTS_FORECAST, SARIMA_FORECAST
FROM ACCCODE_FORECAST_RESULTS
WHERE ACCCODE = 'D07' AND IS_FUTURE = 'Y'
ORDER BY PROD_DATE;

-- Best model per ACCCODE
SELECT ACCCODE, MODEL_NAME AS BEST_MODEL, ROUND(MAPE, 2) AS MAPE_PCT, ROUND(RMSE, 1) AS RMSE
FROM ACCCODE_MODEL_COMPARISON WHERE BEST_MODEL = 'Y' ORDER BY MAPE;

-- Total predicted demand (next 12 months)
SELECT ACCCODE,
       SUM(SES_FORECAST) AS SES_TOTAL,
       SUM(HW_FORECAST)  AS BSTS_TOTAL,
       SUM(SARIMA_FORECAST) AS SARIMA_TOTAL
FROM ACCCODE_FORECAST_RESULTS WHERE IS_FUTURE = 'Y'
GROUP BY ACCCODE ORDER BY BSTS_TOTAL DESC;

-- Model win count
SELECT MODEL_NAME, COUNT(*) AS WINS
FROM ACCCODE_MODEL_COMPARISON WHERE BEST_MODEL = 'Y'
GROUP BY MODEL_NAME ORDER BY WINS DESC;

-- Composite key predictions
SELECT COMPOSITE_KEY, PROD_DATE,
       SES_FORECAST, HW_FORECAST AS BSTS_FORECAST, SARIMA_FORECAST
FROM COMPOSITE_FORECAST_RESULTS
WHERE COMPOSITE_KEY = 'D07|12|C300W' AND IS_FUTURE = 'Y'
ORDER BY PROD_DATE;
```

---

## 13. Glossary

| Term | Definition |
|------|-----------|
| **ACCCODE** | Accessory code identifying a specific vehicle accessory (D07, D40, D49, etc.) |
| **AutoML** | SAP PAL's automatic model selection. We ran `PAL_AUTOML_FIT` which recommended BSTS |
| **BSTS** | Bayesian Structural Time Series — decomposes signal into trend + seasonal + noise using MCMC sampling |
| **Burn-in** | Initial MCMC samples discarded (50%) to allow chain to converge |
| **Composite Key** | ACCCODE\|VPC_LOCATION\|MODEL — granular forecasting at VPC/model level |
| **HDI** | HANA Deployment Infrastructure — container-based schema management on BTP |
| **MAPE** | Mean Absolute Percentage Error — primary model selection metric (lower = better) |
| **MCMC** | Markov Chain Monte Carlo — posterior sampling method used by BSTS |
| **MTA** | Multi-Target Application — SAP packaging format for Cloud Foundry deployment |
| **niter** | Number of MCMC iterations in BSTS (1000 in our config) |
| **PAL** | SAP Predictive Analysis Library — ML algorithms executing inside HANA engine |
| **RMSE** | Root Mean Squared Error — displayed in dashboard (in vehicle count units) |
| **SARIMA** | Seasonal ARIMA — autoregressive model with seasonal differencing |
| **SES** | Simple Exponential Smoothing — flat-line baseline forecast |
| **VPC** | Vehicle Processing Center — logistics location (12, 22, 32, 52) |
